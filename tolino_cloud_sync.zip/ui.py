import os
import tempfile
import traceback

from calibre.gui2 import error_dialog, info_dialog
from calibre.gui2.actions import InterfaceAction
try:
    from qt.core import (QCheckBox, QComboBox, QDialog,
                         QFormLayout, QGroupBox, QLabel, QLineEdit, QMessageBox,
                         QProgressBar, QPushButton, QThread,
                         QVBoxLayout, QHBoxLayout, QTableWidget,
                         QTableWidgetItem, QTextEdit, QObject, QInputDialog,
                         QFileDialog, Qt, pyqtSignal)
except ImportError:
    # Some Calibre Qt builds expose the signal type as Signal.
    from qt.core import (QCheckBox, QComboBox, QDialog,
                         QFormLayout, QGroupBox, QLabel, QLineEdit, QMessageBox,
                         QProgressBar, QPushButton, QThread,
                         QVBoxLayout, QHBoxLayout, QTableWidget,
                         QTableWidgetItem, QTextEdit, QObject, QInputDialog,
                         QFileDialog, Qt, Signal as pyqtSignal)

try:
    from .config import (account_by_name, save_account, save_settings,
                         set_active_account, settings)
    from .sync import (compare_inventory, format_error_details, iter_book_ids,
                       load_state, metadata_by_id, plan_sync, plan_metadata_updates,
                       plan_collection_updates, revert_unsynced_fingerprints,
                       remember_collection,
                       selected_book_ids,
                       selected_table_rows, series_map_from_metadata,
                       sort_comparison_rows, sync_summary,
                       normalize_formats, safe_format_path, cover_bytes,
                       unpack_plan_result, unpack_upload_record,
                       unpack_meta_update_record,
                       diagnose_preparation, format_diagnostic_report,
                       metadata_tolino_id,
                       tolino_column_active, update_tolino_ids)
    from .tolino import (PARTNERS, TolinoAuthError, TolinoClient, browser_login,
                         chromium_available, hardware_id,
                         normalize_refresh_token, sanitize_error,
                         start_token_keepalive, try_live_grab_first)
except ImportError:
    from config import (account_by_name, save_account, save_settings,
                        set_active_account, settings)
    from sync import (compare_inventory, format_error_details, iter_book_ids,
                      load_state, metadata_by_id, plan_sync, plan_metadata_updates,
                      plan_collection_updates, revert_unsynced_fingerprints,
                      remember_collection,
                      selected_book_ids,
                      selected_table_rows, series_map_from_metadata,
                      sort_comparison_rows, sync_summary,
                      normalize_formats, safe_format_path, cover_bytes,
                      unpack_plan_result, unpack_upload_record,
                      unpack_meta_update_record,
                      diagnose_preparation, format_diagnostic_report,
                      metadata_tolino_id,
                      tolino_column_active, update_tolino_ids)
    from tolino import (PARTNERS, TolinoAuthError, TolinoClient, browser_login,
                        chromium_available, hardware_id,
                        normalize_refresh_token, sanitize_error,
                        start_token_keepalive, try_live_grab_first)


def _plugin_version():
    """Plugin version string for display; safe outside Calibre."""
    try:
        from . import PLUGIN_VERSION
    except Exception:
        return "unbekannt"
    return ".".join(str(part) for part in PLUGIN_VERSION)


def _metadata_value(item, name, default=""):
    try:
        return getattr(item, name)
    except AttributeError:
        try:
            return item.get(name, default)
        except AttributeError:
            return default


def _display_value(value):
    if isinstance(value, (list, tuple, set)):
        return ", ".join(str(x) for x in value)
    if isinstance(value, dict):
        return ", ".join("%s: %s" % (key, val) for key, val in sorted(value.items()))
    return str(value or "")


def _format_signatures(database, book_id, formats):
    """size:mtime je Format-Datei -- das billige Content-Signal (0.9.45).

    Ersetzt eine Datei, ändern sich Größe und mtime; eine reine
    Metadatenänderung in Calibre berührt die Datei nicht.
    """
    signatures = {}
    for fmt in formats:
        try:
            stat = os.stat(safe_format_path(database, book_id, fmt))
        except (ValueError, OSError):
            continue
        signatures[fmt] = "%d:%d" % (stat.st_size, int(stat.st_mtime * 1000))
    return signatures


class SyncJob:
    __slots__ = ("book_id", "book_uuid", "format_name", "old_id", "path", "cover_path")

    def __init__(self, book_id, book_uuid, format_name, old_id, path, cover_path):
        self.book_id = book_id
        self.book_uuid = book_uuid
        self.format_name = format_name
        self.old_id = old_id
        self.path = path
        self.cover_path = cover_path


class InventoryDialog(QDialog):
    """Bestandsvergleich: pro Buch drei Aktionen zum Auswählen.

    Links steht, was mit dem Buch passieren soll -- **Hochladen** (die
    Buchdatei in die Cloud), **Metadaten** (nur Titel/Autor(en)/ISBN in der
    Cloud abgleichen, ohne Upload) und **Gelesen** (die Lese-Marke im
    Tolino-Konto setzen). Daneben zeigen zwei ✓-Spalten, wo das Buch liegt
    (Calibre und/oder Tolino Cloud). Alles Technische ist eingeklappt und die
    automatischen Aktionen stehen im Klartext darüber.
    """

    HEADERS = ("Hochladen", "Metadaten", "Gelesen", "In Calibre", "In der Cloud",
               "Titel", "Autor(en)", "Status", "Hinweis",
               "ISBN", "Tolino-ID")
    # Technische Spalten stehen ganz rechts und sind standardmäßig aus.
    TECHNICAL_COLUMNS = (9, 10)

    STATUS_TEXT = {
        "new_in_calibre": "Nur in Calibre",
        "only_tolino": "Nur in der Cloud",
        "identical": "In beiden, gleich",
        "changed": "In beiden, geändert",
        "duplicate_tolino": "Mehrfach in der Cloud",
        "not_matchable": "Nicht zuordenbar",
    }

    _SORT_KEYS = (
        # 0 Hochladen / 1 Metadaten: Ausgewähltes zuerst, dann Titel/Autor(en)
        lambda row: (0 if row.get("upload") else 1,
                     0 if row.get("metadata") else 1,
                     str(row.get("title") or "").casefold(),
                     str(row.get("authors") or "").casefold()),
        lambda row: (0 if row.get("metadata") else 1,
                     0 if row.get("upload") else 1,
                     str(row.get("title") or "").casefold(),
                     str(row.get("authors") or "").casefold()),
        # 2 Gelesen: markierte Bücher zuerst
        lambda row: (0 if row.get("read") else 1,
                     str(row.get("title") or "").casefold(),
                     str(row.get("authors") or "").casefold()),
        # 3 In Calibre / 4 In der Cloud
        lambda row: (0 if row.get("book_id") is not None else 1,
                     str(row.get("title") or "").casefold()),
        lambda row: (0 if row.get("tolino_id") else 1,
                     str(row.get("title") or "").casefold()),
        # 5 Titel / 6 Autor(en) (mit dem jeweils anderen als Zweitschlüssel)
        lambda row: (str(row.get("title") or "").casefold(),
                     str(row.get("authors") or "").casefold()),
        lambda row: (str(row.get("authors") or "").casefold(),
                     str(row.get("title") or "").casefold()),
        # 7 Status / 8 Hinweis
        lambda row: (str(row.get("status") or ""),
                     str(row.get("title") or "").casefold()),
        lambda row: (str(row.get("explanation") or ""),
                     str(row.get("title") or "").casefold()),
        # 9 ISBN / 10 Tolino-ID
        lambda row: (str(row.get("isbn") or ""),
                     str(row.get("title") or "").casefold()),
        lambda row: (str(row.get("tolino_id") or ""),
                     str(row.get("title") or "").casefold()),
    )

    @staticmethod
    def default_actions(row):
        """Was der Vergleich für diese Zeile vorschlägt (Hochladen, Metadaten).

        Neue Bücher werden hochgeladen. Bei geänderten Büchern entscheidet
        der Unterschied: neue Buchdatei -> Hochladen, sonst reicht der
        Metadaten-Abgleich. Ohne Cloud-Kopie gibt es nichts abzugleichen.
        Die Lese-Marke wird nie vorgeschlagen: der Lese-Status in der Cloud
        bleibt, wie er ist, bis der Nutzer ihn ausdrücklich wählt.
        """
        if row.get("book_id") is None or not row.get("tolino_id"):
            new_book = row.get("book_id") is not None
            return (new_book, False)
        if row.get("status") == "new_in_calibre":
            return (True, False)
        if row.get("status") == "changed":
            return (False, True) if not row.get("file_changed") else (True, False)
        return (False, False)

    def __init__(self, rows, parent=None, client_factory=None, options=None):
        QDialog.__init__(self, parent)
        self.client_factory = client_factory
        self.options = dict(options or {})
        self._technical_visible = False
        self.rows = []
        for row in rows:
            row = dict(row)
            if "upload" not in row or "metadata" not in row:
                row["upload"], row["metadata"] = self.default_actions(row)
            # „Gelesen“ kommt aus der Cloud: was dort schon gelesen ist, ist
            # angehakt (und gesperrt) -- nichts muss doppelt geschrieben
            # werden (0.15.0).
            row.setdefault("read", bool(row.get("read_in_cloud")))
            self.rows.append(row)
        # Ausgewählte Aktionen zuerst, dann Titel/Autor(en).
        self.rows = sort_comparison_rows(self.rows)
        self.setWindowTitle("Bestandsvergleich")
        self.setMinimumSize(1180, 540)
        layout = QVBoxLayout(self)

        intro = QLabel(
            "Ihre Calibre-Bibliothek im Vergleich zur Tolino Cloud. "
            "Pro Buch auswählen, was passieren soll: <b>Hochladen</b> lädt die "
            "Buchdatei, <b>Metadaten</b> gleicht nur Titel/Autor(en)/ISBN in "
            "der Cloud ab, <b>Gelesen</b> setzt die Lese-Marke im Tolino-Konto "
            "(angehakt = dort schon gelesen). Ohne Auswahl passiert nichts; ein "
            "Klick auf einen Spaltenkopf sortiert.")
        intro.setWordWrap(True)
        layout.addWidget(intro)

        self.summary = QLabel()
        self.summary.setWordWrap(True)
        layout.addWidget(self.summary)

        self.note = QLabel(self._automatic_note())
        self.note.setWordWrap(True)
        layout.addWidget(self.note)

        helpers = QHBoxLayout()
        self.recommend = QPushButton("Empfehlung auswählen")
        self.recommend.setToolTip(
            "Neue Bücher zum Hochladen, geänderte Bücher je nach Unterschied "
            "zum Hochladen oder für den Metadaten-Abgleich auswählen.")
        self.clear_selection = QPushButton("Auswahl aufheben")
        self.clear_selection.setToolTip("Hebt die gesamte Auswahl auf.")
        helpers.addWidget(self.recommend)
        helpers.addWidget(self.clear_selection)
        helpers.addStretch(1)
        self.read_selected = QPushButton("Gelesen für markierte Zeilen")
        self.read_selected.setToolTip(
            "Hakt die Spalte „Gelesen“ für alle in der Tabelle markierten "
            "Zeilen an. Mehrere markieren mit Strg-/Shift-Klick, alle mit "
            "Strg+A. Geschrieben wird erst mit „Auswahl übernehmen“.")
        helpers.addWidget(self.read_selected)
        layout.addLayout(helpers)

        self.table = QTableWidget(0, len(self.HEADERS))
        self.table.setHorizontalHeaderLabels(self.HEADERS)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        header_tooltips = (
            "Ausgewählt = Buchdatei in die Tolino Cloud hochladen",
            "Ausgewählt = nur Titel/Autor(en)/ISBN in der Cloud aktualisieren "
            "(kein Upload)",
            "Ausgewählt = im Tolino-Konto als gelesen markieren (nur Cloud, "
            "die Buchdatei bleibt unverändert)",
            "Buch liegt in Ihrer Calibre-Bibliothek",
            "Buch liegt in der Tolino Cloud",
            "Buchtitel", "Autor(en)",
            "Was sich zwischen Calibre und Cloud unterscheidet",
            "Erklärung dieser Zeile",
            "ISBN (technisch)",
            "Tolino-Kennung der Cloud-Kopie (technisch)",
        )
        for index, text in enumerate(header_tooltips):
            item = self.table.horizontalHeaderItem(index)
            if item is not None:
                item.setToolTip(text)
        # Spaltenkopf-Klick sortiert (QTableWidget-eigenes Sortieren würde
        # die Zell-Widgets/Auswahl nicht mit den Zeilen mitziehen -- alles
        # wird deshalb über _rebuild_table neu aufgebaut).
        self._sort_column = 0
        self._sort_descending = False
        table_header = self.table.horizontalHeader()
        try:
            table_header.setSortIndicatorShown(True)
            table_header.setSortIndicator(0, Qt.AscendingOrder)
        except Exception:
            pass  # Sortieranzeige ist nur Kosmetik
        table_header.sectionClicked.connect(self._sort_by_column)
        self._rebuild_table(self.rows)
        layout.addWidget(self.table)

        self.technical_toggle = QCheckBox(
            "Technische Spalten anzeigen (ISBN, Tolino-ID)")
        self.technical_toggle.setToolTip(
            "Für den normalen Gebrauch nicht nötig – nur zum Nachschauen.")
        self.technical_toggle.toggled.connect(self._toggle_technical_columns)
        layout.addWidget(self.technical_toggle)
        self._apply_technical_visibility()

        # Weitere Cloud-Aktionen liegen eingeklappt: der Normalfall
        # (auswählen, übernehmen) soll nicht von Nebenschauplätzen verdeckt
        # werden. Die Aktionen nutzen die Tabelle DIESES Fensters und
        # können es deshalb nicht überleben (der gelöschte-QTableWidget-
        # Absturz).
        self.more_toggle = QCheckBox(
            "Weitere Aktionen anzeigen (herunterladen, Sammlung)")
        self.more_toggle.setToolTip(
            "Wirkt nur auf das markierte Buch in der Tolino Cloud, nicht "
            "auf Ihre Calibre-Bibliothek.")
        self.more_toggle.toggled.connect(self._toggle_more_actions)
        layout.addWidget(self.more_toggle)

        self.actions = QGroupBox(
            "Wirkt nur in der Tolino Cloud, nicht in Calibre:")
        action_row = QHBoxLayout()
        self.download_btn = QPushButton("Herunterladen")
        self.download_btn.setToolTip(
            "Lädt das markierte Buch aus der Tolino Cloud als EPUB auf "
            "diesen Rechner.")
        self.collection_add_btn = QPushButton("Zur Sammlung")
        self.collection_add_btn.setToolTip(
            "Ordnet das markierte Cloud-Buch einer Sammlung („Ordner“ in "
            "der Tolino Cloud) zu -- der Name wird abgefragt.")
        self.collection_rm_btn = QPushButton("Aus Sammlung")
        self.collection_rm_btn.setToolTip(
            "Nimmt das markierte Cloud-Buch aus einer Sammlung der "
            "Tolino Cloud heraus -- der Name wird abgefragt.")
        for button in (self.download_btn, self.collection_add_btn,
                       self.collection_rm_btn):
            action_row.addWidget(button)
        self.actions.setLayout(action_row)
        self.actions.setVisible(False)
        layout.addWidget(self.actions)
        self.download_btn.clicked.connect(self.download_selected)
        self.collection_add_btn.clicked.connect(self.add_selected_to_collection)
        self.collection_rm_btn.clicked.connect(self.remove_selected_from_collection)

        buttons = QHBoxLayout()
        confirm = QPushButton("Auswahl übernehmen")
        confirm.setToolTip(
            "Führt genau die ausgewählten Aktionen aus: Buchdateien hochladen, "
            "Metadaten in der Cloud aktualisieren und/oder als gelesen "
            "markieren.")
        cancel = QPushButton("Abbrechen")
        cancel.setToolTip(
            "Schließt den Vergleich, ohne etwas zu ändern.")
        confirm.clicked.connect(self.accept)
        cancel.clicked.connect(self.reject)
        self.confirm = confirm
        buttons.addWidget(confirm)
        buttons.addStretch(1)
        buttons.addWidget(cancel)
        layout.addLayout(buttons)
        self.recommend.clicked.connect(self.apply_recommended)
        self.clear_selection.clicked.connect(self.clear_all_selection)
        self.read_selected.clicked.connect(self.mark_read_for_marked_rows)
        # Erst jetzt gibt es den Knopf: die Zusammenfassung zeigt so von
        # Anfang an die Zahl der ausgewählten Aktionen darauf.
        self._update_summary()

    def _automatic_note(self):
        """Klartext-Zeile: was über die Auswahl hinaus passiert."""
        parts = []
        if self.options.get("collections"):
            parts.append("Serien werden in der Tolino Cloud angelegt und "
                         "bereits zugeordnete Serien gemerkt")
        if self.options.get("deletions"):
            parts.append("Bücher, die nicht mehr in Calibre sind, werden "
                         "aus der Cloud gelöscht")
        if parts:
            head = ("Zusätzlich automatisch: %s. Abschaltbar unter "
                    "„Erweiterte Einstellungen“." % "; ".join(parts))
        else:
            head = ("Es passiert nur, was Sie auswählen -- außer dem Hochladen "
                    "und dem Metadaten-Abgleich wird nichts in der Cloud "
                    "geändert.")
        return (head + " Der Lese-Status in der Cloud bleibt, wie er ist; "
                "nur die Spalte „Gelesen“ ändert ihn.")

    def _toggle_technical_columns(self, visible):
        self._technical_visible = bool(visible)
        self._apply_technical_visibility()

    def _apply_technical_visibility(self):
        for column in self.TECHNICAL_COLUMNS:
            try:
                self.table.setColumnHidden(column, not self._technical_visible)
            except Exception:
                pass  # Qt-Stub ohne Spaltenverstecken

    def _toggle_more_actions(self, visible):
        try:
            self.actions.setVisible(bool(visible))
        except Exception:
            pass  # Qt-Stub oder bereits zerstörtes Fenster

    def _sync_checks_to_rows(self):
        for row, uploads, metadata, read in zip(self.rows, self.checks,
                                                self.meta_checks,
                                                self.read_checks):
            row["upload"] = bool(uploads.isChecked())
            row["metadata"] = bool(metadata.isChecked())
            row["read"] = bool(read.isChecked())

    def _set_selection(self, chooser):
        """Auswahl in einem Schritt setzen (Zeilen und Widgets synchron).

        `chooser` liefert (Hochladen, Metadaten). Die Lese-Marke ist nie Teil
        der Empfehlung: sie fällt auf den Cloud-Stand zurück -- angehakt
        bleibt, was im Konto schon gelesen ist.
        """
        for row, uploads, metadata, read in zip(self.rows, self.checks,
                                                self.meta_checks,
                                                self.read_checks):
            wanted = tuple(chooser(row))
            upload, meta = bool(wanted[0]), bool(wanted[1])
            mark_read = bool(row.get("read_in_cloud"))
            row["upload"], row["metadata"], row["read"] = upload, meta, mark_read
            for check, value in ((uploads, upload), (metadata, meta),
                                 (read, mark_read)):
                try:
                    check.setChecked(value)
                except Exception:
                    pass  # Qt-Stub ohne echtes Signal
        self._update_summary()

    def apply_recommended(self):
        """Die vorgeschlagenen Aktionen für alle Zeilen auswählen."""
        self._set_selection(self.default_actions)

    def clear_all_selection(self):
        self._set_selection(lambda _row: (False, False))

    def selected_upload_ids(self):
        """Bücher, deren Datei hochgeladen werden soll."""
        return selected_book_ids([
            dict(row, selected=check.isChecked())
            for row, check in zip(self.rows, self.checks)
        ])

    def selected_metadata_ids(self):
        """Bücher, deren Cloud-Metadaten aktualisiert werden sollen."""
        return selected_book_ids([
            dict(row, selected=check.isChecked())
            for row, check in zip(self.rows, self.meta_checks)
        ])

    def selected_read_targets(self):
        """Tolino-IDs, die JETZT als gelesen markiert werden (0.15.0).

        Schon gelesene Bücher fallen heraus -- die Cloud bekommt nur, was
        sich wirklich ändert.
        """
        return [str(row["tolino_id"]) for row, check
                in zip(self.rows, self.read_checks)
                if check.isChecked() and row.get("tolino_id")
                and not row.get("read_in_cloud")]

    def mark_read_for_marked_rows(self):
        """Spalte „Gelesen“ für alle in der Tabelle markierten Zeilen setzen.

        Feldbefund 0.15.0: Hunderte Bücher einzeln anhaken ist keine
        Zumutung -- deshalb Mehrfachauswahl in der Tabelle plus dieser Knopf.
        """
        marked = selected_table_rows(self.table)
        if not marked:
            QMessageBox.information(
                self, "Tolino Cloud Sync",
                "Bitte zuerst Zeilen in der Tabelle markieren "
                "(mehrere mit Strg- oder Shift-Klick, alle mit Strg+A).")
            return
        changed = 0
        already = 0
        without_cloud = 0
        for index in marked:
            if index >= len(self.rows):
                continue
            row = self.rows[index]
            if not row.get("tolino_id"):
                without_cloud += 1
                continue
            if row.get("read_in_cloud"):
                already += 1
                continue
            row["read"] = True
            try:
                self.read_checks[index].setChecked(True)
            except Exception:
                pass  # Qt-Stub ohne echtes Signal
            changed += 1
        self._update_summary()
        if not changed:
            QMessageBox.information(
                self, "Tolino Cloud Sync",
                "Nichts zu tun: %d markierte Zeile(n) stehen in der Cloud "
                "schon auf gelesen, %d liegen nicht in der Cloud."
                % (already, without_cloud))

    def selected_ids(self, rows=None):
        """Rückwärtskompatibel: die zum Hochladen ausgewählten Bücher."""
        rows = self.rows if rows is None else rows
        if len(rows) != len(self.checks):
            raise ValueError("Inventory table and selection controls have different row counts.")
        return selected_book_ids([
            dict(row, selected=check.isChecked()) for row, check in zip(rows, self.checks)
        ])

    def _sort_by_column(self, column):
        """Spaltenkopf anklicken: aufsteigend <-> absteigend umschalten."""
        if not 0 <= column < len(self._SORT_KEYS):
            return
        # Auswahlzustand zuerst in die Zeilen retten, sonst geht nach dem
        # Umsortieren die Auswahl verloren.
        self._sync_checks_to_rows()
        if self._sort_column == column:
            self._sort_descending = not self._sort_descending
        else:
            self._sort_column = column
            self._sort_descending = False
        ordered = sorted(self.rows, key=self._SORT_KEYS[column],
                         reverse=self._sort_descending)
        try:
            self.table.horizontalHeader().setSortIndicator(
                column,
                Qt.DescendingOrder if self._sort_descending
                else Qt.AscendingOrder)
        except Exception:
            pass  # Sortieranzeige ist nur Kosmetik
        self._rebuild_table(ordered)

    def _rebuild_table(self, rows):
        """Tabelle aus den (ggf. sortierten) Zeilen neu aufbauen."""
        self.rows = list(rows)
        self.checks = []
        self.meta_checks = []
        self.read_checks = []
        self.table.setRowCount(0)
        self.table.setRowCount(len(self.rows))
        for row_index, row in enumerate(self.rows):
            has_book = row.get("book_id") is not None
            in_cloud = bool(row.get("tolino_id"))
            checks = (
                ("upload", has_book,
                 "Buchdatei in die Tolino Cloud hochladen (ersetzt dort die "
                 "vorhandene Kopie).",
                 "Nur in der Cloud – es gibt keine Calibre-Datei zum "
                 "Hochladen."),
                ("metadata", has_book and in_cloud,
                 "Nur Titel/Autor(en)/ISBN in der Cloud aktualisieren – die "
                 "Buchdatei bleibt, wie sie ist.",
                 "Nur in Calibre – es gibt in der Cloud nichts zu "
                 "aktualisieren." if has_book else
                 "Kein Calibre-Buch – nichts zu aktualisieren."),
                ("read", in_cloud and not row.get("read_in_cloud"),
                 "Im Tolino-Konto als gelesen markieren – die Buchdatei "
                 "bleibt unverändert.",
                 "In der Cloud schon als gelesen markiert."
                 if row.get("read_in_cloud")
                 else "Geht erst, wenn das Buch in der Cloud liegt."),
            )
            for column, (key, enabled, tooltip, disabled_tooltip) in enumerate(checks):
                check = QCheckBox()
                check.setChecked(bool(row.get(key)))
                check.setEnabled(enabled)
                check.setToolTip(tooltip if enabled else disabled_tooltip)
                state_signal = getattr(check, "stateChanged", None)
                if state_signal is not None:
                    try:
                        state_signal.connect(self._update_summary)
                    except Exception:
                        pass  # Qt-Stub ohne echtes Signal
                (self.checks, self.meta_checks,
                 self.read_checks)[column].append(check)
                self.table.setCellWidget(row_index, column, check)
            values = (
                "✓" if has_book else "",
                "✓" if in_cloud else "",
                row.get("title", ""),
                row.get("authors", ""),
                self.STATUS_TEXT.get(row["status"], row["status"]),
                row.get("explanation", ""),
                row.get("isbn", ""),
                row.get("tolino_id", ""),
            )
            for column, value in enumerate(values, 3):
                self.table.setItem(
                    row_index, column, QTableWidgetItem(str(value or "")))
        self.table.resizeColumnsToContents()
        self._apply_technical_visibility()
        self._update_summary()

    def _update_summary(self, *_args):
        """Kurzzeile: wie viele Aktionen gerade ausgewählt sind."""
        try:
            uploads = len(self.selected_upload_ids())
            metadata = len(self.selected_metadata_ids())
            marked_read = len(self.selected_read_targets())
            summary = getattr(self, "summary", None)
            if summary is not None:
                summary.setText(
                    "<b>%d zum Hochladen, %d für Metadaten, %d als gelesen</b> "
                    "ausgewählt – nur das Ausgewählte wird in der Tolino Cloud "
                    "geändert." % (uploads, metadata, marked_read))
            confirm = getattr(self, "confirm", None)
            if confirm is not None:
                total = uploads + metadata + marked_read
                confirm.setText("Auswahl übernehmen (%d)" % total
                                if total else "Auswahl übernehmen")
        except Exception:
            return  # Qt-Stub oder noch nicht aufgebaute Oberfläche

    # --- Cloud actions on the currently selected table row ---------------

    def _selected_row(self):
        """The comparison row for the selection, or None with a hint."""
        selected = selected_table_rows(self.table)
        if not selected:
            QMessageBox.information(
                self, "Tolino Cloud Sync",
                "Bitte eine Zeile markieren.")
            return None
        row_index = selected[0]
        if row_index >= len(self.rows):
            return None
        return self.rows[row_index]

    def _client(self):
        if self.client_factory is None:
            QMessageBox.warning(
                self, "Tolino Cloud Sync",
                "Keine Anmeldung verfügbar.")
            return None
        try:
            return self.client_factory()
        except Exception as exc:
            error_dialog(self, "Anmeldung fehlgeschlagen",
                         sanitize_error(exc), show=True)
            return None

    def download_selected(self):
        row = self._selected_row()
        if row is None:
            return
        tolino_id = row.get("tolino_id")
        if not tolino_id:
            QMessageBox.information(
                self, "Tolino Cloud Sync",
                "Diese Zeile hat keine Tolino-ID (nur in der Cloud vorhandene "
                "Bücher können heruntergeladen werden).")
            return
        try:
            client = self._client()
            if client is None:
                return
            content, _metadata = client.download(tolino_id)
        except Exception as exc:
            error_dialog(self, "Download fehlgeschlagen",
                         sanitize_error(exc), show=True)
            return
        suggested = "%s.epub" % (row.get("title") or "tolino-book")
        path, _ = QFileDialog.getSaveFileName(
            self, "EPUB speichern", suggested, "EPUB (*.epub)")
        if not path:
            return
        with open(path, "wb") as handle:
            handle.write(content)
        info_dialog(self, "Tolino Cloud Sync",
                    "Buch gespeichert: %s" % path, show_copy_button=False)

    def _collection_action(self, action, title):
        row = self._selected_row()
        if row is None:
            return
        tolino_id = row.get("tolino_id")
        if not tolino_id:
            QMessageBox.information(
                self, "Tolino Cloud Sync",
                "Diese Zeile hat keine Tolino-ID.")
            return
        name, ok = QInputDialog.getText(
            self, title, "Sammlungsname:")
        if not ok or not str(name).strip():
            return
        try:
            client = self._client()
            if client is None:
                return
            action(client, tolino_id, str(name).strip())
        except Exception as exc:
            error_dialog(self, "Sammlung fehlgeschlagen",
                         sanitize_error(exc), show=True)
            return
        info_dialog(self, "Tolino Cloud Sync",
                    "Sammlung aktualisiert: %s" % name, show_copy_button=False)

    def add_selected_to_collection(self):
        self._collection_action(
            lambda client, book, name: client.add_to_collection(book, name),
            "Zur Sammlung hinzufügen")

    def remove_selected_from_collection(self):
        self._collection_action(
            lambda client, book, name: client.remove_from_collection(book, name),
            "Aus Sammlung entfernen")


class DiagnosticDialog(QDialog):
    def __init__(self, dashboard, report, parent=None):
        QDialog.__init__(self, parent)
        self.dashboard = dashboard
        self.setWindowTitle("Diagnose")
        self.setMinimumSize(760, 560)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(
            "Die lokale Diagnose führt keinen Login und keine Tolino-Anfrage aus. "
            "Der Tolino-Test startet Netzwerkzugriff erst nach ausdrücklichem Klick."))
        self.output = QTextEdit()
        self.output.setReadOnly(True)
        self.output.setPlainText(report)
        layout.addWidget(self.output)
        buttons = QHBoxLayout()
        copy = QPushButton("Diagnose kopieren")
        copy.clicked.connect(self.copy_report)
        test = QPushButton("Tolino-Antwort testen")
        test.clicked.connect(self.test_tolino)
        close = QPushButton("Schließen")
        close.clicked.connect(self.accept)
        buttons.addWidget(copy)
        buttons.addWidget(test)
        buttons.addWidget(close)
        layout.addLayout(buttons)

    def copy_report(self):
        self.output.selectAll()
        self.output.copy()

    @staticmethod
    def _sync_data_summary(client, secrets=()):
        """Kurzer Ueberblick ueber die sync-data-Antwort (0.15.1).

        Die Spalte „Gelesen“ und die gemerkten Serien stammen aus dieser
        Antwort. Der Bericht zeigt deshalb, OB der Server Marken liefert und
        wie viele davon Sammlungen bzw. Gelesen-Marken sind -- sonst ist
        spaeter nicht zu erkennen, ob eine leere Spalte an der Cloud oder am
        Plugin lag. Ein Fehler hier bricht den Test nicht ab.
        """
        try:
            revision, patches = client.sync_snapshot()
            categories = sorted({
                str((item.get("value") or {}).get("category") or "")
                for item in patches if isinstance(item, dict)
            })
            return {
                "revision_present": revision not in (None, "", 0),
                "patch_count": len(patches),
                "collections": len(client.collection_pairs()),
                "read_marks": len(client.read_ids()),
                "tag_categories": categories,
                "sample_paths": [
                    str(item.get("path") or "") for item in patches[:3]
                    if isinstance(item, dict)
                ],
            }
        except Exception as exc:
            return {"error_type": type(exc).__name__,
                    "error_message": sanitize_error(
                        exc, secrets + (getattr(client, "access", None),))}

    def test_tolino(self):
        values = self.dashboard.values()
        if not values["refresh_token"]:
            QMessageBox.warning(self, "Tolino-Antwort testen",
                                "Kein Refresh-Token konfiguriert.")
            return
        try:
            # Derselbe Weg wie „Synchronisieren starten“: Konto speichern,
            # Token- und Hardware-Callback, Login -- der Test darf sich
            # nicht vom Lauf unterscheiden, der ihn scheinbar heilt.
            client = self.dashboard._cloud_client()
            inventory = client.inventory()
            result = {
                "step": "Tolino-Antwort testen",
                "status": "ok",
                "value": {
                    "response_type": type(inventory).__name__,
                    "item_count": len(inventory),
                    "sample": inventory[:3],
                    "sync_data": DiagnosticDialog._sync_data_summary(
                        client, (values["refresh_token"],)),
                    "auth": client.auth_diagnostics(),
                },
            }
        except Exception as exc:
            auth = locals().get("client")
            result = {
                "step": "Tolino-Antwort testen",
                "status": "error",
                "value": auth.auth_diagnostics() if auth else {
                    "partner_id": values["partner_id"],
                    "partner_name": PARTNERS[values["partner_id"]]["name"],
                    "client_id": PARTNERS[values["partner_id"]].get("client_id"),
                    "scope": PARTNERS[values["partner_id"]].get("scope"),
                    "token_url": PARTNERS[values["partner_id"]].get("token_url"),
                    **normalize_refresh_token(values["refresh_token"])[1],
                },
                "error_type": type(exc).__name__,
                "error_message": sanitize_error(
                    exc, (values["refresh_token"], getattr(auth, "access", None))
                ),
                "traceback": sanitize_error(
                    traceback.format_exc(),
                    (values["refresh_token"], getattr(auth, "access", None)),
                ),
            }
        self.output.append("\n" + format_diagnostic_report([result]))


class SyncWorker(QObject):
    progress = pyqtSignal(int, int, str)
    completed = pyqtSignal(object, object, object)
    failed = pyqtSignal(str, str)

    def __init__(self, settings, jobs, removals, meta_updates=None,
                 series_map=None, read_marks=None):
        QObject.__init__(self)
        self.settings = settings
        self.jobs = jobs
        self.removals = removals
        self.meta_updates = list(meta_updates or ())
        self.series_map = dict(series_map or {})
        # Tolino-IDs, die in der Cloud als gelesen markiert werden sollen
        # (Spalte "Gelesen"). Leer heißt: Lese-Status bleibt unangetastet.
        self.read_marks = [str(item) for item in (read_marks or ())
                           if str(item or "").strip()]
        self.cancelled = False

    def cancel(self):
        self.cancelled = True

    def run(self):
        state = load_state(self.settings["state"])
        client = None
        updates = []
        try:
            client = TolinoClient(self.settings["partner_id"], self.settings["hardware_id"],
                                  self.settings["refresh_token"], self.settings["username"],
                                  self.settings["password"],
                                  token_callback=self.persist_refresh_token,
                                  hardware_callback=self.persist_hardware)
            client.login()
            needs_replacement_cleanup = any(job.old_id for job in self.jobs)
            remote_ids = (client.inventory_ids()
                          if self.settings["enable_deletions"] or needs_replacement_cleanup
                          else set())
            # Serien → Sammlungen: nur noch OFFENE Zuordnungen. Bereits
            # geschriebene stehen als "collections" am Buch (0.14.0).
            series_items = plan_collection_updates(self.series_map, state)
            total = (len(self.jobs) + len(self.removals)
                     + len(self.meta_updates) + len(series_items)
                     + (1 if self.read_marks else 0))
            done = 0
            # Erst die in-place Metadaten-Updates, dann die Uploads (0.9.45).
            for update in self.meta_updates:
                if self.cancelled:
                    raise RuntimeError("Synchronisierung vom Benutzer abgebrochen.")
                record = unpack_meta_update_record(update)
                self.progress.emit(done, total, "Metadaten: %s" % record["book_uuid"])
                client.update_metadata(record["tolino_id"], record["fields"])
                done += 1
            for job in self.jobs:
                if self.cancelled:
                    raise RuntimeError("Synchronisierung vom Benutzer abgebrochen.")
                self.progress.emit(done, total, "Lade hoch: %s (%s)" %
                                   (job.book_uuid, job.format_name))
                new_id = client.upload(job.path)
                # Plan-Eintrag kopieren: fingerprint/content_fp/meta_fp bleiben
                # erhalten, nur die Tolino-ID wird neu (0.9.45).
                entry = dict(state.get(job.book_uuid) or {})
                entry.update({"tolino_id": new_id, "calibre_id": job.book_id})
                # Neue Cloud-Kopie: alte Serien-Zuordnungen gelten nicht mehr.
                entry.pop("collections", None)
                state[job.book_uuid] = entry
                updates.append((job.book_id, new_id))
                if job.cover_path:
                    client.upload_cover(new_id, job.cover_path)
                if job.old_id and str(job.old_id) in remote_ids:
                    client.delete(job.old_id)
                done += 1
                self.progress.emit(done, total, "Hochgeladen: %s" % job.book_uuid)
            for book_uuid, tolino_id in self.removals:
                if self.cancelled:
                    raise RuntimeError("Synchronisierung vom Benutzer abgebrochen.")
                if str(tolino_id) in remote_ids:
                    self.progress.emit(done, total, "Lösche: %s" % book_uuid)
                    client.delete(tolino_id)
                state.pop(book_uuid, None)
                done += 1
                self.progress.emit(done, total, "Erledigt: %s" % book_uuid)
            # Lese-Marke: nur die ausdrücklich ausgewählten Bücher, und nur,
            # wenn sie in der Cloud noch nicht gesetzt ist. Sammlungen und
            # andere Marken bleiben dabei unverändert (0.14.0).
            if self.read_marks:
                if self.cancelled:
                    raise RuntimeError("Synchronisierung vom Benutzer abgebrochen.")
                self.progress.emit(done, total, "Als gelesen markieren")
                client.mark_read_many(self.read_marks)
                done += 1
                self.progress.emit(done, total, "Gelesen-Marke gesetzt")
            # Serien → Cloud-Sammlungen: nur die offenen Zuordnungen. Der
            # Cloud-Bestand wird einmal gelesen, jede geschriebene oder
            # bereits vorhandene Zuordnung aber im Zustand gemerkt -- beim
            # nächsten Sync ist hier deshalb nichts mehr zu tun (0.14.0).
            if series_items:
                known = client.collection_pairs()
                revision = None
                for book_uuid, tolino_id, series in series_items:
                    if self.cancelled:
                        raise RuntimeError("Synchronisierung vom Benutzer abgebrochen.")
                    if (tolino_id, series) not in known:
                        self.progress.emit(done, total,
                                           "Serie in der Cloud: %s" % series)
                        revision = client.add_to_collection(
                            tolino_id, series, revision=revision)
                        known.add((tolino_id, series))
                    remember_collection(state, book_uuid, series)
                    done += 1
                self.progress.emit(done, total, "Serien geprüft")
            self.completed.emit(state, client.refresh, updates)
        except Exception as exc:
            self.failed.emit(sanitize_error(
                exc, (self.settings["refresh_token"], getattr(client, "access", None))
            ), client.refresh if client else self.settings["refresh_token"])

    def persist_refresh_token(self, refresh):
        self.settings["refresh_token"] = refresh
        save_account(self.settings["account_name"], {
            "refresh_token": refresh, "hardware_id": self.settings["hardware_id"],
        }, active=self.settings["account_name"])

    def persist_hardware(self, hardware):
        """Adopted device id from the BOSH recovery (0.9.35)."""
        self.settings["hardware_id"] = hardware
        save_account(self.settings["account_name"], {
            "refresh_token": self.settings["refresh_token"],
            "hardware_id": hardware,
        }, active=self.settings["account_name"])


# Browser sign-in keeps a module-level reference to its worker thread: the
# dashboard may be closed while the flow is still polling the browser
# storages, and a parented QThread destroyed while running crashes Calibre.
_LOGIN_WORKER_THREADS = []


def _reap_login_thread(thread):
    try:
        _LOGIN_WORKER_THREADS.remove(thread)
    except ValueError:
        pass


class BrowserLoginWorker(QObject):
    """Runs browser_login off the GUI thread (it polls for minutes)."""
    completed = pyqtSignal(object, object)
    failed = pyqtSignal(str)
    # Live-Fortschrittstexte des Grabs ("Fenster offen -- anmelden",
    # "warte auf einen neu geschriebenen Token ...") direkt in die
    # Statuszeile.
    progress = pyqtSignal(str)

    def __init__(self, partner_id, hardware):
        QObject.__init__(self)
        self.partner_id = partner_id
        self.hardware = hardware

    def run(self):
        try:
            refresh, hardware = browser_login(
                self.partner_id, self.hardware,
                progress=self.progress.emit)
        except Exception as exc:
            self.failed.emit("%s: %s" % (type(exc).__name__,
                                         sanitize_error(exc)))
            return
        self.completed.emit(refresh, hardware)


class SyncDashboard(QDialog):
    def __init__(self, gui):
        QDialog.__init__(self, gui)
        self.gui = gui
        self.thread = None
        self.worker = None
        self.login_thread = None
        self.login_worker = None
        self.sync_column_enabled = False
        self.temp_files = []
        self.setWindowTitle("Tolino Cloud Sync (Plugin-Version %s)"
                            % _plugin_version())
        self.setMinimumWidth(560)
        root = QVBoxLayout(self)

        intro = QLabel(
            "So geht’s: <b>1)</b> anmelden &nbsp;→&nbsp; <b>2)</b> "
            "vergleichen und pro Buch auswählen, was in die Cloud soll. "
            "Alles Weitere ist optional und standardmäßig richtig "
            "eingestellt.")
        intro.setWordWrap(True)
        root.addWidget(intro)

        # --- Schritt 1: Anmelden -------------------------------------------
        setup = QGroupBox("1 · Anmelden")
        setup_form = QFormLayout(setup)
        self.partner = QComboBox()
        for pid, partner in sorted(PARTNERS.items()):
            self.partner.addItem("%s – %s" % (pid, partner["name"]), pid)
        self.hardware = QLineEdit()
        self.refresh = QLineEdit()
        self.refresh.setEchoMode(QLineEdit.Password)
        self.status = QLabel()
        self.browser = QPushButton("Jetzt bei Tolino anmelden")
        self.browser.setToolTip(
            "Öffnet ein Anmeldefenster. Dort im Web Reader einloggen und "
            "die Bücherliste öffnen – den Zugang holt das Plugin "
            "automatisch und schließt das Fenster wieder.")
        self.browser.clicked.connect(self.browser_login)
        self.scrape_browser = QPushButton("Zugang aus offenem Browser holen")
        self.scrape_browser.setToolTip(
            "Holt den Zugang aus einem bereits geöffneten oder neu "
            "geöffneten Anmeldefenster (benötigt Chrome, Chromium, Brave "
            "oder Edge).")
        self.scrape_browser.clicked.connect(self.scrape_browser_tokens)
        setup_form.addRow("Buchhändler", self.partner)
        setup_form.addRow("", self.browser)
        setup_form.addRow("", self.status)
        root.addWidget(setup)

        # --- Schritt 2: Synchronisieren ------------------------------------
        action = QGroupBox("2 · Synchronisieren")
        action_form = QFormLayout(action)
        self.progress_label = QLabel("Bereit")
        self.progress = QProgressBar()
        self.progress.setRange(0, 1)
        self.start = QPushButton("Vergleichen und übernehmen …")
        self.start.setToolTip(
            "Öffnet den Bestandsvergleich: pro Buch Hochladen und/oder "
            "Metadaten auswählen, dann übernehmen. Die automatischen "
            "Cloud-Aktionen aus den erweiterten Einstellungen laufen mit.")
        self.start.clicked.connect(self.start_sync)
        self.cancel = QPushButton("Abbrechen")
        self.cancel.setEnabled(False)
        self.cancel.clicked.connect(self.cancel_sync)
        self.debug = QPushButton("Diagnose")
        self.debug.setToolTip(
            "Öffnet den Prüfbericht: Calibre-Datenbank, Formate und "
            "Titelbilder werden ohne Anmeldung und ohne Tolino-Anfrage "
            "geprüft. Erst der Knopf im Bericht greift auf das Netz zu.")
        self.debug.clicked.connect(self.debug_diagnose)
        action_form.addRow("", self.start)
        action_form.addRow("", self.progress_label)
        action_form.addRow("", self.progress)
        action_form.addRow("", self.cancel)
        # Feldbefund: Der Knopf wurde seit 0.10.0 gebaut, aber nie in ein
        # Layout gehängt -- er war dadurch unsichtbar (0.14.0).
        action_form.addRow("", self.debug)
        root.addWidget(action)

        # --- Erweiterte Einstellungen (standardmäßig ausgeblendet) ---------
        self.advanced_toggle = QCheckBox("Erweiterte Einstellungen anzeigen")
        self.advanced_toggle.setToolTip(
            "Zugangsdaten, Formate, Vergleichsfelder, automatische "
            "Cloud-Aktionen und mehrere Konten – für den normalen "
            "Gebrauch nicht nötig.")
        self.advanced_toggle.toggled.connect(self._toggle_advanced)
        root.addWidget(self.advanced_toggle)

        self.advanced = QGroupBox("Erweiterte Einstellungen")
        advanced_form = QFormLayout(self.advanced)
        self.formats = QLineEdit()
        self.covers = QCheckBox("Titelbild mit hochladen")
        self.covers.setToolTip(
            "Das Titelbild des Buches (Calibre: „Titelbild“) zusätzlich in "
            "die Cloud laden.")
        self.deletions = QCheckBox("Löschungen aus der Cloud übernehmen")
        self.sync_collections = QCheckBox("Serien in der Cloud anlegen")
        self.sync_collections.setToolTip(
            "Jedes Buch einer Calibre-Serie wird in der Tolino Cloud "
            "zugeordnet; der Tolino Web Reader zeigt diese Zuordnung als "
            "„Sammlung“ an. Abschalten, wenn die Cloud unverändert "
            "bleiben soll.")
        self.tolino_column = QCheckBox(
            "Tolino-ID in eigene Spalte schreiben (nur ein Konto)")
        self.tolino_column.setToolTip(
            "Schreibt die Tolino-IDs in die Calibre-Spalte #tolino_id. "
            "Nur sinnvoll bei genau einem Konto – bei mehreren Konten "
            "merkt sich jedes Konto seine IDs selbst.")
        self.compare_authors = QCheckBox(
            "Autor(en) beim Vergleich berücksichtigen")
        self.compare_title = QCheckBox("Titel beim Vergleich berücksichtigen")
        self.compare_isbn = QCheckBox("ISBN beim Vergleich berücksichtigen")
        for field in (self.compare_authors, self.compare_title, self.compare_isbn):
            field.setChecked(True)
        advanced_form.addRow("", self.scrape_browser)
        advanced_form.addRow("Hardware-ID (automatisch erkannt)", self.hardware)
        advanced_form.addRow("Zugangsschlüssel (Refresh-Token)", self.refresh)
        advanced_form.addRow("Bevorzugte Formate", self.formats)
        advanced_form.addRow("", self.covers)
        advanced_form.addRow("", self.compare_authors)
        advanced_form.addRow("", self.compare_title)
        advanced_form.addRow("", self.compare_isbn)
        automatic_hint = QLabel("Bei jedem Synchronisieren zusätzlich "
                                "(abwählbar):")
        automatic_hint.setWordWrap(True)
        advanced_form.addRow("", automatic_hint)
        advanced_form.addRow("", self.deletions)
        advanced_form.addRow("", self.sync_collections)
        advanced_form.addRow("", self.tolino_column)
        root.addWidget(self.advanced)

        self.accounts_group = QGroupBox("Konten")
        account_form = QFormLayout(self.accounts_group)
        self.account_select = QComboBox()
        self.account_new = QPushButton("Neues Konto")
        self.account_remove = QPushButton("Konto löschen")
        account_buttons = QHBoxLayout()
        account_buttons.addWidget(self.account_new)
        account_buttons.addWidget(self.account_remove)
        self.account_select.currentIndexChanged.connect(self.account_changed)
        self.account_new.clicked.connect(self.new_account)
        self.account_remove.clicked.connect(self.remove_account)
        account_form.addRow("Aktives Konto", self.account_select)
        account_form.addRow("", account_buttons)
        root.addWidget(self.accounts_group)

        self.advanced.setVisible(False)
        self.accounts_group.setVisible(False)

        # Plain close button instead of QDialogButtonBox: immune to the Qt6
        # "Invalid ButtonRole, button not added" warning seen in the field.
        close = QPushButton("Schließen")
        close.clicked.connect(self.close)
        root.addWidget(close)
        self.load_values()

    def _toggle_advanced(self, visible):
        """Erweiterte Einstellungen ein-/ausblenden (Standard: aus)."""
        visible = bool(visible)
        self.advanced.setVisible(visible)
        self.accounts_group.setVisible(visible)

    def _save_visible_account(self):
        if not getattr(self, "account_name", None):
            return
        save_settings({
            "preferred_formats": [x.strip().upper()
                                  for x in self.formats.text().split(",") if x.strip()],
            "upload_covers": self.covers.isChecked(),
            "enable_deletions": self.deletions.isChecked(),
            "sync_collections": self.sync_collections.isChecked(),
            "use_tolino_column": self.tolino_column.isChecked(),
        })
        save_account(self.account_name, self.values(), active=self.account_name)

    def account_changed(self, index):
        if index < 0 or not getattr(self, "account_names", None):
            return
        self._save_visible_account()
        self.account_name = self.account_select.itemData(index)
        # Angezeigtes und aktives Konto sind ab jetzt IMMER dasselbe:
        # settings(), Konten-State und Keep-alive lesen sonst weiter das
        # vorherige Konto, und die Tolino-ID-Zuordnung landete beim
        # falschen Konto.
        set_active_account(self.account_name)
        account = next(item for item in settings()["accounts"]
                       if item["name"] == self.account_name)
        self.partner.setCurrentIndex(max(0, self.partner.findData(account["partner_id"])))
        self.hardware.setText(account["hardware_id"] or hardware_id())
        self.refresh.setText(account["refresh_token"])
        self.update_status()

    def new_account(self):
        self._save_visible_account()
        base, accepted = QInputDialog.getText(
            self, "Neues Konto", "Name:")
        base = str(base).strip()
        if not accepted or not base:
            return
        names = set(self.account_names)
        name, number = base, 2
        while name in names:
            name = "%s-%d" % (base, number)
            number += 1
        save_account(name, {"name": name}, active=name)
        self.load_values()
        self.account_select.setCurrentIndex(self.account_select.findData(name))

    def remove_account(self):
        if len(self.account_names) <= 1:
            return
        name = self.account_name
        remaining = [item for item in settings()["accounts"] if item["name"] != name]
        save_settings({"accounts": remaining,
                       "active_account": remaining[0]["name"]})
        self.load_values()

    def debug_diagnose(self):
        values = self.values()
        results = diagnose_preparation(
            self.gui.current_db,
            values["preferred_formats"],
            values["upload_covers"],
            load_state(values["state"]),
        )
        DiagnosticDialog(self, format_diagnostic_report(results), self).exec()

    def load_values(self):
        values = settings()
        self.account_names = [item["name"] for item in values["accounts"]]
        self.account_select.blockSignals(True)
        self.account_select.clear()
        for name in self.account_names:
            self.account_select.addItem(name, name)
        self.account_name = values["active_account"]
        self.account_select.setCurrentIndex(
            max(0, self.account_select.findData(self.account_name)))
        self.account_select.blockSignals(False)
        self.partner.setCurrentIndex(max(0, self.partner.findData(values["partner_id"])))
        self.hardware.setText(values["hardware_id"] or hardware_id())
        self.refresh.setText(values["refresh_token"])
        self.formats.setText(", ".join(values["preferred_formats"]))
        self.covers.setChecked(values["upload_covers"])
        self.deletions.setChecked(values["enable_deletions"])
        self.sync_collections.setChecked(values["sync_collections"])
        self.tolino_column.setChecked(values["use_tolino_column"])
        self.update_status()

    def update_status(self):
        logged_in = bool(self.refresh.text().strip())
        self.status.setText(
            "✓ Angemeldet – Sie können synchronisieren." if logged_in
            else "● Nicht angemeldet – bitte zuerst oben anmelden.")
        # Schritt 2 ist ohne Anmeldung nicht möglich; während eines Laufs
        # bleibt der Knopf gesperrt (start_sync/finish_thread steuern ihn).
        if self.thread is None:
            self.start.setEnabled(logged_in)

    def set_refresh_token(self, refresh):
        normalized, _ = normalize_refresh_token(refresh)
        self.refresh.setText(normalized)
        self.update_status()

    def persist_refresh_token(self, refresh):
        self.set_refresh_token(refresh)
        save_account(self.account_name, {
            "refresh_token": self.refresh.text(),
            "hardware_id": self.hardware.text().strip() or hardware_id(),
        }, active=self.account_name)

    def persist_hardware(self, hardware):
        """Adopted device id from the BOSH recovery (0.9.35)."""
        self.hardware.setText(str(hardware))
        save_account(self.account_name, {
            "refresh_token": self.refresh.text(),
            "hardware_id": str(hardware),
        }, active=self.account_name)

    def scrape_browser_tokens(self):
        """Read the current token from the plugin's own sign-in window."""
        try:
            # Ein laufendes Anmeldefenster haelt den AKTUELLEN Token.
            grabbed = try_live_grab_first(
                self.partner.currentData(), self.hardware.text().strip())
            if grabbed:
                refresh_token, hardware_id_value = grabbed
                if hardware_id_value:
                    self.hardware.setText(str(hardware_id_value))
                self.persist_refresh_token(refresh_token)
                QMessageBox.information(
                    self, "Token extrahiert",
                    "Aktueller Token live aus dem ge\u00f6ffneten Web "
                    "Reader gelesen und gespeichert (Hardware-ID: %s). "
                    "Das Anmeldefenster wurde geschlossen."
                    % (hardware_id_value or "unver\u00e4ndert"))
                return
            # Kein Fenster: selbst das eigene Chromium-Fenster oeffnen und
            # den Token live uebernehmen.
            if chromium_available():
                if (self.login_thread is not None
                        and self.login_thread.isRunning()):
                    return  # eine Anmeldung läuft bereits
                self.status.setText(
                    "Öffne ein eigenes Chromium-Fenster auf dem Web "
                    "Reader – dort anmelden, Bücherliste laden. Nur "
                    "dieses Fenster schließt sich danach.")
                self.browser_login()
                return
            QMessageBox.information(
                self, "Kein Chromium-Browser gefunden",
                "Dieser Knopf liest den Zugang aus dem eigenen "
                "Anmeldefenster und benötigt dafür Chrome, Chromium, "
                "Brave oder Edge.\n\n"
                "Entweder einen dieser Browser installieren und danach "
                "„Jetzt bei Tolino anmelden“ erneut drücken.\n\n"
                "Oder den Zugang von Hand eintragen: im Web Reader "
                "anmelden, F12 → Netzwerk → Aufnahme starten, im "
                "Netzwerk-Protokoll refresh_token und hardware_id "
                "kopieren und unter „Erweiterte Einstellungen“ in die "
                "Felder „Refresh-Token“ und „Hardware-ID“ einfügen.")
        except TolinoAuthError as exc:
            QMessageBox.warning(
                self, "Live-\u00dcbernahme",
                "%s\n\nDas Anmeldefenster ist noch offen: dort im Web "
                "Reader anmelden (Bücherliste laden) und den Knopf "
                "erneut drücken." % sanitize_error(exc))
        except Exception as exc:
            QMessageBox.critical(
                self, "Fehler",
                "Fehler beim Extrahieren der Tokens: %s" % sanitize_error(exc)
            )

    def _selected_account(self):
        """The account this dialog shows -- never a different 'active' one."""
        return account_by_name(getattr(self, "account_name", None))

    def values(self):
        refresh_token, _ = normalize_refresh_token(self.refresh.text())
        account = self._selected_account() or settings()
        return {
            "account_name": self.account_name,
            "partner_id": self.partner.currentData(),
            "hardware_id": self.hardware.text().strip() or hardware_id(),
            "refresh_token": refresh_token,
            "username": account.get("username", ""),
            "password": account.get("password", ""),
            "preferred_formats": [x.strip().upper()
                                  for x in self.formats.text().split(",") if x.strip()],
            "upload_covers": self.covers.isChecked(),
            "enable_deletions": self.deletions.isChecked(),
            "sync_collections": self.sync_collections.isChecked(),
            "use_tolino_column": self.tolino_column.isChecked(),
            "state": (account.get("state")
                      if isinstance(account.get("state"), dict) else {}),
        }

    def browser_login(self):
        """Open the private Chromium sign-in window, adopt the fresh token."""
        if self.login_thread is not None and self.login_thread.isRunning():
            return  # a sign-in attempt is already running
        partner_id = self.partner.currentData()
        self.browser.setEnabled(False)
        self.scrape_browser.setEnabled(False)
        self.status.setText(
            "Browser-Anmeldung läuft: im Anmeldefenster im Web Reader "
            "(Bibliothek) anmelden und die Bücherliste laden. Fenster "
            "offen lassen – der Token wird live übernommen.")
        thread = QThread()  # no parent: dialog may close first
        worker = BrowserLoginWorker(partner_id, self.hardware.text().strip())
        worker.moveToThread(thread)
        worker.progress.connect(self._login_progress)
        thread.started.connect(worker.run)
        worker.completed.connect(thread.quit)
        worker.failed.connect(thread.quit)
        worker.completed.connect(self.login_completed)
        worker.failed.connect(self.login_failed)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(lambda: _reap_login_thread(thread))
        _LOGIN_WORKER_THREADS.append(thread)
        self.login_thread = thread
        self.login_worker = worker
        thread.start()

    def login_completed(self, refresh, hardware):
        try:
            self._login_cleanup()
            self.set_refresh_token(refresh)
            if hardware:
                self.hardware.setText(str(hardware))
            self.persist_refresh_token(refresh)
            self.update_status()
            QMessageBox.information(
                self, "Anmeldung erfolgreich",
                "Der neue Refresh-Token wurde sofort gespeichert.")
        except RuntimeError:
            pass  # dialog already destroyed (Calibre shutdown)

    def login_failed(self, message):
        try:
            self._login_cleanup()
            QMessageBox.warning(self, "Browser-Anmeldung",
                                sanitize_error(message))
        except RuntimeError:
            pass  # dialog already destroyed (Calibre shutdown)

    def _login_progress(self, text):
        """Live-Hinweise des Browser-Grabs in der Statuszeile zeigen."""
        try:
            self.status.setText(str(text))
        except RuntimeError:
            pass  # dialog already destroyed (Calibre shutdown)

    def _login_cleanup(self):
        self.login_thread = None
        self.login_worker = None
        try:
            self.browser.setEnabled(True)
            self.scrape_browser.setEnabled(True)
            self.status.setText("Bereit")
        except RuntimeError:
            pass  # dialog already destroyed

    def _cloud_client(self):
        """Build a logged-in client from the current dialog values.

        Raises on failure; the inventory dialog turns that into an error
        dialog. The rotated refresh token is persisted immediately.
        """
        settings = self.values()
        if not settings["refresh_token"]:
            raise TolinoAuthError(
                "Bitte zuerst anmelden: „Jetzt bei Tolino anmelden“.")
        self._save_visible_account()
        client = TolinoClient(
            settings["partner_id"], settings["hardware_id"],
            settings["refresh_token"], settings["username"],
            settings["password"], token_callback=self.persist_refresh_token,
            hardware_callback=self.persist_hardware)
        client.login()
        self.set_refresh_token(client.refresh)
        return client

    def start_sync(self):
        if self.thread is not None:
            return
        settings = self.values()
        if not settings["refresh_token"]:
            QMessageBox.warning(self, "Noch nicht angemeldet",
                                "Bitte zuerst oben auf „Jetzt bei Tolino "
                                "anmelden“ drücken.")
            return
        # EINE Regel fuer Lesen UND Schreiben der Tolino-ID-Spalte
        # (tolino_column_active): nur bei genau einem Konto.
        self.sync_column_enabled = tolino_column_active(
            settings, self.gui.current_db)
        try:
            metadata = {}
            for book_id in iter_book_ids(self.gui.current_db):
                item = metadata_by_id(self.gui.current_db, book_id)
                metadata[book_id] = {
                    "uuid": _metadata_value(item, "uuid"),
                    "title": _metadata_value(item, "title"),
                    "authors": _display_value(_metadata_value(item, "authors",
                                                               _metadata_value(item, "author"))),
                    "isbn": _display_value(_metadata_value(item, "isbn",
                                                            _metadata_value(item, "identifiers"))),
                    "formats": _metadata_value(item, "formats"),
                    "last_modified": str(_metadata_value(item, "last_modified")),
                    "tolino_id": metadata_tolino_id(item) if self.sync_column_enabled else "",
                    "series": str(_metadata_value(item, "series") or "").strip(),
                }
            for book_id, item in metadata.items():
                item["formats"] = normalize_formats(item["formats"])
                item["format_signatures"] = _format_signatures(
                    self.gui.current_db, book_id, item["formats"])
            state = load_state(settings["state"])
            client = TolinoClient(settings["partner_id"], settings["hardware_id"],
                                  settings["refresh_token"], settings["username"],
                                  settings["password"],
                                  token_callback=self.persist_refresh_token,
                                  hardware_callback=self.persist_hardware)
            client.login()
            self.set_refresh_token(client.refresh)
            # CRITICAL: Ensure the new refresh token is persisted immediately
            # This prevents "reuse exceeded" errors during sync
            if client.refresh != settings["refresh_token"]:
                self.persist_refresh_token(client.refresh)
            comparison_fields = [
                name for name, checkbox in (
                    ("authors", self.compare_authors),
                    ("title", self.compare_title),
                    ("isbn", self.compare_isbn),
                ) if checkbox.isChecked()
            ]
            # Lese-Status aus der Cloud holen, damit die Spalte „Gelesen“
            # vorbelegt ist. Scheitert das (z. B. Netzfehler), läuft der
            # Vergleich ohne Vorbelegung weiter (0.15.0).
            inventory = client.inventory()
            try:
                read_ids = client.read_ids()
            except Exception:
                read_ids = set()
            comparison = compare_inventory(
                metadata, state, inventory, settings["preferred_formats"],
                comparison_fields,
                use_metadata_ids=self.sync_column_enabled,
                read_ids=read_ids,
            )
            dialog = InventoryDialog(
                comparison, self,
                client_factory=lambda: self._cloud_client(),
                options={
                    "collections": bool(settings["sync_collections"]),
                    "deletions": bool(settings["enable_deletions"]),
                })
            if dialog.exec() != QDialog.Accepted:
                return
            # Die Auswahl des bestätigten Fensters entscheidet, was
            # passiert -- jede Aktion für sich; eine leere Auswahl ändert
            # nichts.
            selected_uploads = dialog.selected_upload_ids()
            selected_metadata = dialog.selected_metadata_ids()
            selected_read = dialog.selected_read_targets()
            uploads, removals, current = unpack_plan_result(plan_sync(
                metadata, state, settings["preferred_formats"],
                settings["enable_deletions"],
                upload_book_ids=selected_uploads,
            ))
            # "Metadaten" gleicht vorhandene Cloud-Einträge in-place ab
            # (/meta) -- nur für die ausgewählten Bücher (0.13.0).
            uploads, meta_updates = plan_metadata_updates(
                metadata, state, uploads, settings["preferred_formats"],
                only_book_ids=selected_metadata)
            # Serien → Sammlungen: ohne eingeschaltete Sammlungen bleibt
            # die Zuordnung leer und die Cloud wird nicht angefasst.
            series_map = (series_map_from_metadata(metadata)
                          if settings["sync_collections"] else {})
            jobs = []
            skipped_uploads = []
            for upload in uploads:
                record = unpack_upload_record(upload)
                book_id = record["book_id"]
                book_uuid = record["book_uuid"]
                fmt = record["format_name"]
                old_id = record["old_id"]
                try:
                    path = safe_format_path(self.gui.current_db, book_id, fmt)
                    if not os.path.isfile(path):
                        raise ValueError("Pfad existiert nicht: %s" % path)
                except ValueError as exc:
                    title = metadata.get(book_id, {}).get("title") or "ohne Titel"
                    skipped_uploads.append(
                        "Buch %s (%s), Format %s: %s" % (book_id, title, fmt, exc))
                    continue
                cover_path = None
                if settings["upload_covers"]:
                    cover = cover_bytes(self.gui.current_db, book_id)
                    if cover:
                        temp = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
                        temp.write(cover)
                        temp.close()
                        cover_path = temp.name
                        self.temp_files.append(cover_path)
                jobs.append(SyncJob(book_id, book_uuid, fmt, old_id, path, cover_path))
            # Nur wirklich ausgeführte Aktionen zählen als abgeglichen:
            # alles andere behält den alten Cloud-Stand (0.13.0).
            synced = {job.book_uuid for job in jobs}
            synced.update(str(record[1]) for record in meta_updates)
            revert_unsynced_fingerprints(current, state, synced)
            settings["state"] = current
        except Exception as exc:
            error_dialog(
                self, "Vorbereitung fehlgeschlagen",
                format_error_details(exc, (settings.get("refresh_token"),)),
                show=True,
            )
            return
        if skipped_uploads:
            QMessageBox.warning(
                self, "Tolino Cloud Sync",
                "Einige Uploads wurden übersprungen:\n\n%s" %
                "\n".join(skipped_uploads))
        summary = sync_summary(len(jobs), len(removals))
        self.progress.setRange(0, summary["total"] or 1)
        self.progress.setValue(0)
        self.thread = QThread(self)
        self.worker = SyncWorker(settings, jobs, removals, meta_updates,
                                 series_map, selected_read)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self.progress_changed)
        self.worker.completed.connect(self.sync_completed)
        self.worker.failed.connect(self.sync_failed)
        self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()
        self.start.setEnabled(False)
        self.cancel.setEnabled(True)
        self.progress_label.setText("Synchronisierung läuft")
        # Ensure settings are up-to-date with the latest refresh token
        settings["refresh_token"] = self.refresh.text().strip()

    def progress_changed(self, done, total, text):
        self.progress.setRange(0, total or 1)
        self.progress.setValue(done)
        self.progress_label.setText(text)

    def cancel_sync(self):
        if self.worker:
            self.worker.cancel()
            self.progress_label.setText("Abbruch angefordert")
            self.cancel.setEnabled(False)

    def sync_completed(self, state, refresh, updates):
        # CRITICAL: Update UI with the latest refresh token from worker
        # This prevents "invalid token" errors on subsequent sync attempts
        if refresh and refresh != self.refresh.text().strip():
            self.set_refresh_token(refresh)
            self.persist_refresh_token(refresh)
        update_tolino_ids(self.gui.current_db, updates, enabled=self.sync_column_enabled)
        save_account(self.account_name, {
            "state": state, "refresh_token": refresh,
            "hardware_id": self.hardware.text().strip() or hardware_id(),
        }, active=self.account_name)
        self.finish_thread()
        info_dialog(self, "Tolino Cloud Sync", "Synchronisierung abgeschlossen.",
                    show_copy_button=False)

    def sync_failed(self, message, refresh):
        self.set_refresh_token(refresh)
        self.finish_thread()
        error_dialog(
            self, "Synchronisierung fehlgeschlagen",
            sanitize_error(message, (self.values()["refresh_token"],)),
            show=True,
        )

    def finish_thread(self):
        self._save_visible_account()
        if self.thread:
            self.thread.quit()
            self.thread.wait()
        self.thread = None
        self.worker = None
        self.start.setEnabled(True)
        self.cancel.setEnabled(False)
        self.progress_label.setText("Bereit")
        for path in self.temp_files:
            try:
                os.remove(path)
            except OSError:
                pass
        self.temp_files = []
        self.update_status()

    def closeEvent(self, event):
        if self.thread:
            self.cancel_sync()
            self.thread.quit()
            self.thread.wait()
        # A running browser sign-in is left alone on purpose: its thread is
        # unparented and self-terminates after its timeout, and joining it
        # here could freeze the close for minutes.
        self.login_thread = None
        self.login_worker = None
        self._save_visible_account()
        event.accept()


class TolinoSyncAction(InterfaceAction):
    name = "Tolino Cloud Sync"
    action_spec = ("Tolino Cloud Sync", None,
                   "Tolino-Cloud-Dashboard öffnen", None)

    def genesis(self):
        self.qaction.triggered.connect(self.show_dashboard)
        self.menu = self.qaction
        _apply_toolbar_icon(self)
        # Keycloak refresh tokens expire after ~1h idle (refresh_expires_in
        # ~3598); the keep-alive rotates the stored token every 45 minutes
        # while Calibre runs, so an adopted token survives between syncs.
        try:
            start_token_keepalive(self._keepalive_credentials,
                                  self._keepalive_persist)
        except Exception:
            pass  # keep-alive must never break plugin loading

    def _keepalive_credentials(self):
        try:
            cfg = settings()
        except Exception:
            return {}
        return {
            "partner_id": cfg.get("partner_id"),
            "hardware_id": cfg.get("hardware_id") or "",
            "refresh_token": cfg.get("refresh_token") or "",
            "username": cfg.get("username"),
            "password": cfg.get("password"),
        }

    def _keepalive_persist(self, refresh):
        try:
            cfg = settings()
            # Keep-alive-Konto = aktives Konto (settings()); das
            # Dialog-Feld "account_name" existiert in settings() nicht --
            # der rotierte Token landete dadurch nie auf der Platte.
            name = cfg.get("active_account") or cfg.get("name")
            if name and refresh:
                save_account(name, {"refresh_token": refresh}, active=name)
        except Exception:
            pass  # best-effort persistence

    def show_dashboard(self):
        dialog = SyncDashboard(self.gui)
        dialog.exec()


def _apply_toolbar_icon(action):
    """Give the toolbar action its icon via the robust fallback chain."""
    try:
        from .icons import toolbar_icon
    except ImportError:
        from icons import toolbar_icon
    except Exception:
        return
    try:
        icon = toolbar_icon()
    except Exception:
        icon = None
    if icon is None or icon.isNull():
        return
    try:
        action.qaction.setIcon(icon)
    except Exception:
        action.setIcon(icon)
