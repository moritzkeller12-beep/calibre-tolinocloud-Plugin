0                                                                    

from calibre.gui2.actions import InterfaceAction


class TolinoSyncAction(InterfaceAction):
    name = "Tolino Cloud Sync"
    action_spec = ("tolino Cloud Sync", None,
                   "tolino Cloud Sync öffnen", None)

    def genesis(self):
        self.qaction.triggered.connect(self.show_dashboard)
        icon = self._toolbar_icon()
        if icon is not None and not icon.isNull():
            self.qaction.setIcon(icon)


        try:
            from .token_vault import start_token_keepalive
            start_token_keepalive()
        except Exception as exc:


            from .tolino import log_warning
            log_warning("Tolino-Keep-alive konnte nicht gestartet werden: %s"
                        % exc)

    def shutting_down(self):
        0                                                               

                                                                            
                                                                       
           
        self._finish_session()
        parent = getattr(super(), "shutting_down", None)
        if callable(parent):
            parent()

    def _finish_session(self):
        0                                                                    
        try:
            from .token_vault import stop_token_keepalive
            stop_token_keepalive()
        except Exception as exc:

            from .tolino import log_warning
            log_warning("Tolino-Keep-alive konnte nicht beendet werden: %s"
                        % exc)

    def show_dashboard(self):
        from .ui_dashboard import SyncDashboard
        dialog = SyncDashboard(self.gui)
        dialog.exec()

    def _toolbar_icon(self):
        0                                                                  
        from qt.core import QIcon, QPixmap
        resources = self.load_resources(["images/tolino_cloud_sync.png"])
        data = resources.get("images/tolino_cloud_sync.png")
        if not data:
            return None
        pixmap = QPixmap()
        if not pixmap.loadFromData(data):
            return None
        return QIcon(pixmap)
