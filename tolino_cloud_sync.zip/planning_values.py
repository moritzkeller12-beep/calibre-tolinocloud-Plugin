0                                                 

                                                                 
                                             
   
import os
from typing import NamedTuple

from .identifiers import display_title
from .library import safe_format_path


def metadata_value(item, name, default=""):
    0                                                             
    try:
        return getattr(item, name)
    except AttributeError:
        try:
            return item.get(name, default)
        except AttributeError:
            return default


def plural(n, singular, plural_form):
    0                                                       
    return singular if int(n) == 1 else plural_form


def display_value(value):
    0                                               
    if isinstance(value, (list, tuple, set)):
        return ", ".join(str(x) for x in value)
    if isinstance(value, dict):
        return ", ".join("%s: %s" % (key, val)
                         for key, val in sorted(value.items()))
    return str(value or "")


def format_signatures(database, book_id, formats):
    0                                                          

                                                                
                                                         
       
    signatures = {}
    for fmt in formats:
        try:
            stat = os.stat(safe_format_path(database, book_id, fmt))
        except (ValueError, OSError):
            continue
        signatures[fmt] = "%d:%d" % (stat.st_size, int(stat.st_mtime * 1000))
    return signatures


class SyncJob(NamedTuple):
    0                                                                           

    book_id: object
    book_uuid: object
    format_name: object
    old_id: object
    path: object
    cover: object
    title: object

    def label(self):
        0                                                             
        return display_title(self.title, self.book_id)
