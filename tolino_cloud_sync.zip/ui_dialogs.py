"""Dialoge für den tolino-Bibliotheksvergleich."""
import re
from typing import NamedTuple

from .ui_common import (QCheckBox, QComboBox, QDialog, QFileDialog,
                        QHBoxLayout, QHeaderView, QLabel, QMessageBox,
                        QMenu, QPushButton, QTableWidget, QTableWidgetItem,
                        QVBoxLayout, QStyledItemDelegate, QStyle,
                        QStyleOptionViewItem, QEvent, Qt, _set_enabled,
                        start_call)
from .planning_values import plural
from calibre.gui2 import error_dialog, info_dialog
from .comparison import comparison_sort_key, sort_comparison_rows
from .library import TOLINO_IGNORE_COLUMN
from .tolino import report_error


def _selected_rows(table):
    """Zeilennummern der markierten Tabellenzeilen."""
    return [index.row() for index in table.selectionModel().selectedRows()]


def _by_title(row):
    return (str(row.get("title") or "").casefold(),
            str(row.get("authors") or "").casefold())


def _by_authors(row):
    return (str(row.get("authors") or "").casefold(),
            str(row.get("title") or "").casefold())


def _by_hint(row):
    return (str(row.get("explanation") or ""), _by_title(row)[0])


def _by_isbn(row):
    return (str(row.get("isbn") or ""), _by_title(row)[0])


def _by_tolino_id(row):
    return (str(row.get("tolino_id") or ""), _by_title(row)[0])


def _by_uuid(row):
    return (str(row.get("uuid") or ""), _by_title(row)[0])


def _by_calibre(row):
    return (0 if row.get("book_id") is not None else 1,) + _by_title(row)


def _by_cloud(row):
    return (0 if row.get("tolino_id") else 1,) + _by_title(row)


def _metadata_first(row):
    return ((0 if row.get("metadata") else 1,)
            + comparison_sort_key(row)[2:])


def _read_first(row):
    return ((0 if row.get("read") else 1,)
            + _by_title(row))


class _Column(NamedTuple):
    """Eine Vergleichsspalte: Titel, Tooltip, Sortierschlüssel, technisch."""

    label: str
    tooltip: str
    sort_key: object
    technical: bool = False


def row_capabilities(row):
    """Was darf diese Vergleichszeile? -- EINE Quelle für alle vier Stellen.

    Die Funktion beschreibt nur die technische Anwendbarkeit, nicht die
    Empfehlung: ein unsicher zugeordnetes Buch darf manuell hochgeladen
    werden, wird aber nicht vorgeschlagen. Export und Löschmarkierung sind
    keine Auswahlspalten und deshalb hier nicht enthalten.
    """
    has_book = row.get("book_id") is not None
    in_cloud = bool(row.get("tolino_id"))
    ignored = bool(row.get("ignored"))
    deleting = bool(row.get("delete_cloud"))
    usable = not ignored and not deleting
    return {
        "upload": bool(has_book and usable
                       and row.get("has_preferred_format", True)),
        "metadata": bool(has_book and in_cloud and usable),
        "read": bool(in_cloud and usable and row["read"].known),
        # Download ist auch für eine bereits markierte Kopie sinnvoll:
        # damit lässt sich die Datei vor dem Löschen noch retten.
        "download": in_cloud,
        "delete": bool(in_cloud and not ignored),
        "usable": usable,
    }


class _ActionCheck:
    """Sicht auf eine Check-Zelle; der Zustand liegt im QTableWidgetItem."""

    def __init__(self, item):
        self.item = item

    def isChecked(self):
        return self.item.checkState() == Qt.CheckState.Checked

    def setChecked(self, value):
        # Ohne expliziten CheckState zeichnet Qt kein leeres Kästchen.
        self.item.setCheckState(
            Qt.CheckState.Checked if value else Qt.CheckState.Unchecked)

    def setEnabled(self, enabled):
        flags = self.item.flags()
        # Checkbar bleibt das Feld auch deaktiviert: Qt zeichnet das
        # Kästchen dann grau, statt es ganz zu verstecken.
        flags |= Qt.ItemFlag.ItemIsUserCheckable
        if enabled:
            flags |= Qt.ItemFlag.ItemIsEnabled
        else:
            flags &= ~Qt.ItemFlag.ItemIsEnabled
        self.item.setFlags(flags)

    def setToolTip(self, text):
        self.item.setToolTip(str(text or ""))


class _CenteredCheckDelegate(QStyledItemDelegate):
    """Zeichnet Check-Indikatoren mittig; die ganze Zelle schaltet um."""

    def paint(self, painter, option, index):
        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        style = opt.widget.style() if opt.widget is not None else None
        if style is None:
            QStyledItemDelegate.paint(self, painter, option, index)
            return
        style.drawPrimitive(
            QStyle.PrimitiveElement.PE_PanelItemViewItem,
            opt, painter, opt.widget)
        if opt.features & QStyleOptionViewItem.ViewItemFeature.HasCheckIndicator:
            if opt.checkState == Qt.CheckState.PartiallyChecked:
                opt.state |= QStyle.StateFlag.State_NoChange
            elif opt.checkState == Qt.CheckState.Checked:
                opt.state |= QStyle.StateFlag.State_On
            else:
                opt.state |= QStyle.StateFlag.State_Off
            rect = style.subElementRect(
                QStyle.SubElement.SE_ItemViewItemCheckIndicator,
                opt, opt.widget)
            opt.rect = QStyle.alignedRect(
                opt.direction, Qt.AlignmentFlag.AlignCenter,
                rect.size(), opt.rect)
            opt.state &= ~QStyle.StateFlag.State_HasFocus
            style.drawPrimitive(
                QStyle.PrimitiveElement.PE_IndicatorItemViewItemCheck,
                opt, painter, opt.widget)
        else:
            QStyledItemDelegate.paint(self, painter, option, index)

    def editorEvent(self, event, model, option, index):
        if event.type() in (QEvent.Type.MouseButtonRelease,
                            QEvent.Type.MouseButtonDblClick):
            if event.button() != Qt.MouseButton.LeftButton:
                return False
            flags = model.flags(index)
            if not (flags & Qt.ItemFlag.ItemIsUserCheckable):
                return False
            if not (flags & Qt.ItemFlag.ItemIsEnabled):
                return False
            state = index.data(Qt.ItemDataRole.CheckStateRole)
            state = (Qt.CheckState.Unchecked
                     if state == Qt.CheckState.Checked
                     else Qt.CheckState.Checked)
            return model.setData(index, state, Qt.ItemDataRole.CheckStateRole)
        return QStyledItemDelegate.editorEvent(self, event, model, option, index)


class InventoryDialog(QDialog):
    """Bestandsvergleich: pro Buch drei Aktionen zum Auswählen.

    Links stehen **Upload** (Datei), **Metadaten** (Titel, Autor und ISBN)
    oder **Lesestatus**. Die Spalten **Calibre** und **tolino** zeigen
    den Bestand; **Hinweis** erklärt die Zeile. Technische Angaben und
    Sammelaktionen sind getrennt erreichbar.
    """

    ACTION_COLUMNS = (
        _Column("Upload", "Buchdatei in die Cloud hochladen.",
                comparison_sort_key),
        _Column("Metadaten",
                "Titel, Autor und ISBN ohne Upload aktualisieren.",
                _metadata_first),
        _Column("Gelesen",
                "Auswahl = gelesen; keine Auswahl = ungelesen. Die "
                "Calibre-Spalte #tolino_read ist nur informativ.",
                _read_first),
    )
    DATA_COLUMNS = (
        _Column("Calibre", "Buch in Calibre vorhanden.", _by_calibre),
        _Column("tolino",
                "Buch im ausgewählten tolino-Konto vorhanden.", _by_cloud),
        _Column("Buchtitel", "Buchtitel", _by_title),
        _Column("Autor(en)", "Autor(en)", _by_authors),
        _Column("Hinweis", "Grund und Unterschiede des Vergleichs.",
                _by_hint),
        _Column("ISBN", "ISBN (technisch, ausgeblendet)", _by_isbn, True),
        _Column("tolino-ID",
                "tolino-ID der Cloud-Kopie (technisch, ausgeblendet)",
                _by_tolino_id, True),
        _Column("UUID",
                "Calibre-UUID (technisch, ausgeblendet)", _by_uuid, True),
    )
    COLUMNS = ACTION_COLUMNS + DATA_COLUMNS
    HEADERS = tuple(column.label for column in COLUMNS)
    ACTION_KEYS = ("upload", "metadata", "read")
    TECHNICAL_COLUMNS = tuple(index for index, column in enumerate(COLUMNS)
                              if column.technical)
    TITLE_COLUMN = HEADERS.index("Buchtitel")
    AUTHORS_COLUMN = HEADERS.index("Autor(en)")
    HINT_COLUMN = HEADERS.index("Hinweis")
    GROUP_FILTERS = (
        ("Alle", None),
        ("Aktion nötig", "action"),
        ("Nur in tolino", "tolino_only"),
        ("Zu prüfen", "review"),
        ("Unverändert", "unchanged"),
        ("Ignoriert", "ignored"),
    )

    READ_TOOLTIP = "Ausgewählt = gelesen, nicht ausgewählt = ungelesen."
    IGNORED_TOOLTIP = ("In Calibre ignoriert (%s) – wird nicht "
                       "abgeglichen." % TOLINO_IGNORE_COLUMN)
    DELETE_TOOLTIP = ("Zum Löschen aus tolino markiert – zuerst "
                      "«Löschmarkierung aufheben».")
    INTRO_TEXT = ("Wähle pro Buch: Upload (Datei), Metadaten "
                  "(Titel, Autor, ISBN) oder Lesestatus. Geändert wird erst "
                  "mit «Synchronisierung starten».")

    # (Label, Methode, feste Argumente, Prädikat): EINE Tabelle für Menü,
    # Sichtbarkeit und Ausführung.
    ROW_ACTIONS = (
        ("Upload aktivieren", "set_column_for_marked_rows",
         ("upload", True, "haben schon diese Auswahl oder keine Datei"),
         lambda row: (row_capabilities(row)["upload"]
                      and not row.get("upload"))),
        ("Upload deaktivieren", "set_column_for_marked_rows",
         ("upload", False, "waren schon abgewählt oder haben keine Datei"),
         lambda row: bool(row.get("upload"))),
        ("Metadaten aktivieren", "set_column_for_marked_rows",
         ("metadata", True,
          "haben schon diese Auswahl oder liegen nicht in der Cloud"),
         lambda row: (row_capabilities(row)["metadata"]
                      and not row.get("metadata"))),
        ("Metadaten deaktivieren", "set_column_for_marked_rows",
         ("metadata", False,
          "waren schon abgewählt oder liegen nicht in der Cloud"),
         lambda row: bool(row.get("metadata"))),
        ("Als gelesen markieren", "set_column_for_marked_rows",
         ("read", True,
          "sind schon gelesen oder liegen nicht in der Cloud"),
         lambda row: (row_capabilities(row)["read"]
                      and not row.get("read"))),
        ("Als ungelesen markieren", "set_column_for_marked_rows",
         ("read", False,
          "sind bereits ungelesen oder liegen nicht in der Cloud"),
         lambda row: (row_capabilities(row)["read"]
                      and row.get("read"))),
        ("Aus tolino herunterladen …", "download_selected", (),
         lambda row: row_capabilities(row)["download"]),
        ("Aus der tolino Cloud löschen …", "delete_marked_from_cloud", (),
         lambda row: (row_capabilities(row)["delete"]
                      and not row.get("delete_cloud"))),
        ("Löschmarkierung aufheben", "clear_cloud_delete_for_marked_rows", (),
         lambda row: bool(row.get("delete_cloud"))),
    )

    @staticmethod
    def default_actions(row):
        """Vorschläge für Upload und Metadaten dieser Zeile.

        Unsichere Zuordnungen bleiben unverändert, da ein Upload Duplikate
        erzeugen könnte. Bücher ohne passendes Upload-Format erhalten keinen
        Upload-Vorschlag.
        """
        caps = row_capabilities(row)
        if not caps["usable"]:
            return (False, False)
        # Bei unsicheren Zuordnungen könnte ein Upload Duplikate erzeugen.
        if row.get("status") == "review":
            return (False, False)
        if row.get("book_id") is None or not row.get("tolino_id"):
            if row.get("stale_cloud_id"):
                return (False, False)
            return (caps["upload"], False)
        if row.get("status") == "new_in_calibre":
            return (caps["upload"], False)
        if row.get("status") == "changed":
            if row.get("file_changed"):
                return (caps["upload"], False)
            return (False, caps["metadata"])
        return (False, False)

    def __init__(self, rows, parent=None, client_factory=None, options=None):
        QDialog.__init__(self, parent)
        self.client_factory = client_factory
        # Eine Anmeldung fuer das ganze Fenster: jede Aktion loggte sonst neu
        # ein und rotierte dabei den Refresh-Token.
        self._cached_client = None
        self.options = dict(options or {})
        self._technical_visible = False
        self._syncing_checks = False
        self._call_thread = None
        self.rows = []
        # Der Tabellenaufbau aktualisiert die Zusammenfassung vor dem Footer.
        self.summary = None
        self.confirm = None
        self.action_feedback = None
        self._prepare_rows(rows)
        self.setAttribute(
            Qt.WidgetAttribute.WA_QuitOnClose, False)
        self.setMinimumSize(640, 460)
        self.resize(960, 560)
        layout = QVBoxLayout(self)
        self._build_header(layout)
        self._build_toolbar(layout)
        self._build_table(layout)
        self._build_footer(layout)

    def _prepare_rows(self, rows):
        """Zeilen übernehmen, Standardaktionen setzen und sortieren.

        `read` kommt aus `comparison.py` bereits als `ReadState`.
        """
        for row in rows:
            row = dict(row)
            if "upload" not in row or "metadata" not in row:
                row["upload"], row["metadata"] = self.default_actions(row)
            # Die Calibre-Spalte wird nur angezeigt. Die Auswahl folgt dem
            # Lesestatus des aktuell ausgewählten Tolino-Kontos.
            self.rows.append(row)
        self.rows = sort_comparison_rows(self.rows)

    def _build_header(self, layout):
        """Einleitung, Zusammenfassung und Hinweis zu Automatiken."""
        intro = QLabel(self.INTRO_TEXT)
        intro.setWordWrap(True)
        layout.addWidget(intro)

        self.summary = QLabel()
        self.summary.setWordWrap(True)
        layout.addWidget(self.summary)

        self.note = QLabel(self._automatic_note())
        self.note.setWordWrap(True)
        if not self.note.text() and any(
                not row["read"].known for row in self.rows):
            self.note.setText(
                "Lesestatus unbekannt: konnte nicht geladen werden und "
                "wird nicht verändert.")
        if not self.note.text() and self.options.get("ignore_column") is False:
            self.note.setText(
                "Spalte %s (Ja/Nein) anlegen: so markierte Bücher werden "
                "nicht hochgeladen." % TOLINO_IGNORE_COLUMN)
        layout.addWidget(self.note)

    def _build_toolbar(self, layout):
        """Gruppenfilter, Empfehlung/Auswahl und Zeilenaktionen."""
        helpers = QHBoxLayout()
        self.group_filter = QComboBox()
        for label, key in self.GROUP_FILTERS:
            self.group_filter.addItem(label, key)
        self.group_filter.setToolTip(
            "Filtert nach Aktion, Cloud-Bestand, Prüfung oder unverändert.")
        self.group_filter.currentIndexChanged.connect(
            self._apply_group_filter)
        self.recommend = QPushButton("Empfohlene Aktionen auswählen")
        self.recommend.setToolTip(
            "Wählt Upload oder Metadaten für eindeutig zugeordnete Bücher.")
        self.clear_selection = QPushButton("Auswahl zurücksetzen")
        self.clear_selection.setToolTip(
            "Setzt alle Auswahlen zurück. Nichts wird verändert.")
        helpers.addWidget(QLabel("Anzeigen"))
        helpers.addWidget(self.group_filter)
        helpers.addWidget(self.recommend)
        helpers.addWidget(self.clear_selection)
        helpers.addStretch(1)
        self.row_actions = QPushButton("Aktionen für markierte Bücher …")
        self.row_actions.setToolTip(
            "Zeilen mit Strg-/Shift-Klick markieren; alle mit Strg+A.")
        helpers.addWidget(self.row_actions)
        layout.addLayout(helpers)

    def _build_table(self, layout):
        """Tabelle samt Kopfzeilen-Tooltips und Sortierung aufbauen."""
        self.table = QTableWidget(0, len(self.HEADERS))
        self._check_delegate = _CenteredCheckDelegate(self.table)
        for column in range(len(self.ACTION_COLUMNS)):
            self.table.setItemDelegateForColumn(column, self._check_delegate)
        self.table.setHorizontalHeaderLabels(self.HEADERS)
        self.table.setSelectionBehavior(
            QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(
            QTableWidget.SelectionMode.ExtendedSelection)
        for index, column in enumerate(self.COLUMNS):
            self.table.horizontalHeaderItem(index).setToolTip(column.tooltip)
        # Spaltenkopf-Klick sortiert (QTableWidget-eigenes Sortieren würde
        # die Check-Zellen nicht mit den Zeilen mitziehen -- alles wird
        # deshalb über _rebuild_table neu aufgebaut).
        self._sort_column = 0
        self._sort_descending = False
        table_header = self.table.horizontalHeader()
        table_header.setSortIndicatorShown(True)
        table_header.setSortIndicator(
            0, Qt.SortOrder.AscendingOrder)
        table_header.sectionClicked.connect(self._sort_by_column)
        self.table.itemChanged.connect(self._item_changed)
        self._rebuild_table(self.rows, resize_columns=True)
        layout.addWidget(self.table)

    def _build_footer(self, layout):
        """Rueckmeldung, technische Spalten und die Abschlussknoepfe."""
        self.action_feedback = QLabel()
        self.action_feedback.setWordWrap(True)
        layout.addWidget(self.action_feedback)

        self.technical_toggle = QCheckBox(
            "Technische Details anzeigen (ISBN, tolino-ID, UUID)")
        self.technical_toggle.setToolTip(
            "Zeigt ISBN, tolino-ID und UUID.")
        self.technical_toggle.toggled.connect(self._toggle_technical_columns)
        layout.addWidget(self.technical_toggle)
        self._apply_technical_visibility()

        buttons = QHBoxLayout()
        confirm = QPushButton("Synchronisierung starten")
        confirm.setToolTip(
            "Überträgt die ausgewählten Änderungen.")
        cancel = QPushButton("Abbrechen")
        cancel.setToolTip(
            "Schließt den Vergleich, ohne Änderungen.")
        confirm.clicked.connect(self.accept)
        cancel.clicked.connect(self.reject)
        self.confirm = confirm
        self.cancel = cancel
        buttons.addWidget(confirm)
        buttons.addStretch(1)
        buttons.addWidget(cancel)
        layout.addLayout(buttons)
        self.recommend.clicked.connect(self.apply_recommended)
        self.clear_selection.clicked.connect(self.clear_all_selection)
        self.row_actions.clicked.connect(self.choose_row_action)
        self._update_summary()

    def _automatic_note(self):
        """Anzahl der automatisch geplanten Sammlungen anzeigen."""
        count = int(self.options.get("automatic") or 0)
        if count:
            return "Serien werden als Sammlungen in tolino übernommen (%d offen)." % count
        return ""

    def _toggle_technical_columns(self, visible):
        self._technical_visible = bool(visible)
        self._apply_technical_visibility()

    def _apply_technical_visibility(self):
        for column in self.TECHNICAL_COLUMNS:
            self.table.setColumnHidden(column, not self._technical_visible)

    def _check(self, row_index, column):
        """Check-Controller einer Aktionszelle; der Zustand liegt in der Zelle."""
        return _ActionCheck(self.table.item(row_index, column))

    def _choice_changed(self, row_index, column):
        """Die Zeile hält die Auswahl; die Zelle zeigt sie nur an."""
        row = self.rows[row_index]
        key = self.ACTION_KEYS[column]
        checked = bool(self._check(row_index, column).isChecked())
        if key == "read":
            row["read"].chosen = checked
        else:
            row[key] = checked
        self._update_summary()

    def _set_check_quietly(self, row_index, column, value):
        """Check-Zelle ohne Einzelaktualisierung setzen.

        Sammelaktionen setzen viele Zellen; die Zusammenfassung schreibt
        der Aufrufer danach genau einmal.
        """
        previous = self._syncing_checks
        self._syncing_checks = True
        try:
            self._check(row_index, column).setChecked(value)
        finally:
            self._syncing_checks = previous

    def _item_changed(self, item):
        """Eine Check-Zelle wurde vom Nutzer umgeschaltet."""
        if self._syncing_checks:
            return
        column = item.column()
        if column in range(len(self.ACTION_COLUMNS)):
            self._choice_changed(item.row(), column)

    def _set_selection(self, chooser, clear_deletions=False):
        """Auswahl in einem Schritt setzen (Zeilen und Zellen synchron).

        Der Lesestatus bleibt bei Empfehlungen unverändert. Zum Löschen
        markierte Zeilen bleiben unberührt; «Auswahl zurücksetzen» hebt auch
        die Löschmarkierung auf.
        """
        if clear_deletions:
            for row in self.rows:
                row.pop("delete_cloud", None)
                row["upload"] = row["metadata"] = False
                state = row["read"]
                state.chosen = state.cloud
            self._rebuild_table(self.rows)
            return
        for index, row in enumerate(self.rows):
            caps = row_capabilities(row)
            if not caps["usable"]:
                continue
            wanted = tuple(chooser(row))
            upload = bool(wanted[0]) and caps["upload"]
            metadata = bool(wanted[1]) and caps["metadata"]
            row.update(upload=upload, metadata=metadata)
            for column, checked in ((0, upload), (1, metadata)):
                self._set_check_quietly(index, column, checked)
        self._update_summary()

    def apply_recommended(self):
        """Die vorgeschlagenen Aktionen für alle Zeilen auswählen."""
        self._set_selection(self.default_actions)

    def clear_all_selection(self):
        self._set_selection(lambda _row: (False, False),
                            clear_deletions=True)

    def automatic_actions_enabled(self):
        """Tun Automatiken ohne Auswahl WIRKLICH etwas?

        Eine eingeschaltete Option ist noch keine Aktion: nur der explizite
        Plan-Zähler beschreibt offene Sammlungszuordnungen. Fehlt er, wird
        keine unbelegte automatische Arbeit angenommen.
        """
        try:
            return int(self.options.get("automatic") or 0) > 0
        except (TypeError, ValueError):
            return False

    def selected_cloud_deletions(self):
        """(UUID, tolino-ID, Titel) der zum Löschen markierten Cloud-Kopien."""
        return [(str(row.get("uuid") or ""), str(row["tolino_id"]),
                 str(row.get("title") or ""))
                for row in self.rows
                if row.get("delete_cloud") and row_capabilities(row)["delete"]]

    def _selected_book_ids(self, key):
        """Bücher, deren Aktion ``key`` (upload/metadata) gewählt ist."""
        return {row["book_id"] for row in self.rows
                if row.get(key) and row_capabilities(row).get(key)}

    def selected_read_changes(self):
        """(tolino-ID, Calibre-Nummer, gelesen?) der offenen Änderungen.

        Die Zeile kennt Cloud-Stand und Auswahl; übertragen wird nur die
        Abweichung. Die Calibre-Nummer wandert mit, damit der bestätigte
        Stand ohne zweite Suche in die Spalte #tolino_read wandert.
        """
        changes = []
        for row in self.rows:
            state = row["read"]
            if not row_capabilities(row)["read"] or not state.changed:
                continue
            changes.append((str(row["tolino_id"]), row.get("book_id"),
                            state.chosen))
        return changes

    def _marked_row_indexes(self):
        """Markierte Zeilen -- oder ein Hinweis, wenn keine markiert ist."""
        marked = _selected_rows(self.table)
        if not marked:
            QMessageBox.information(
                self, "Aktionen für markierte Bücher",
                "Markiere zuerst mindestens ein Buch in der Tabelle. "
                "Mehrere Bücher wählst du mit Strg-/Shift-Klick aus.")
        return marked

    def choose_row_action(self):
        """Eine Stelle für alle Aktionen auf markierte Zeilen.

        Aktionen für markierte Bücher sind hier zusammengefasst; auch Upload,
        Metadaten und Lesestatus sind verfügbar.
        """
        marked = self._marked_row_indexes()
        if not marked:
            return
        menu = QMenu(self)
        actions = {}
        row_indexes = [index for index in marked
                       if 0 <= index < len(self.rows)]
        for label, method, args, predicate in self.ROW_ACTIONS:
            if not any(predicate(self.rows[index]) for index in row_indexes):
                continue
            actions[menu.addAction(label)] = (method, args)
        position = self.row_actions.mapToGlobal(
            self.row_actions.rect().bottomLeft())
        chosen = menu.exec(position)
        handler = actions.get(chosen)
        if handler is None:
            return
        method, args = handler
        getattr(self, method)(*args)

    def set_column_for_marked_rows(self, key, value, summary):
        """Eine Spalte für alle markierten Zeilen setzen.

        Dieselbe Wirkung wie die Auswahl je Zeile, nur für viele auf einmal:
        passt die Spalte nicht zur Zeile, wird sie gezählt und ausgelassen.
        Geschrieben wird weiterhin erst mit «Synchronisierung starten».
        """
        marked = self._marked_row_indexes()
        if not marked:
            return
        changed = 0
        skipped = 0
        for index in marked:
            if not 0 <= index < len(self.rows):
                continue
            caps = row_capabilities(self.rows[index])
            if not caps.get(key):
                skipped += 1
                continue
            if self._set_row_choice(index, key, bool(value), caps):
                changed += 1
            else:
                skipped += 1
        self._update_summary()
        if not changed:
            self._show_action_feedback("")
            count = skipped or len(marked)
            QMessageBox.information(
                self, "Nichts geändert",
                "Nichts geändert: %d markierte %s %s."
                % (count, plural(count, "Buch", "Bücher"), summary))
            return
        feedback = "%s für %d von %d markierten Büchern" % (
            self.ACTION_LABELS.get((key, bool(value)), "Aktion ausgeführt"),
            changed, len(marked))
        if skipped:
            feedback += "; %d übersprungen" % skipped
        self._show_action_feedback(feedback + ".")

    ACTION_LABELS = {
        ("upload", True): "Upload aktiviert",
        ("upload", False): "Upload deaktiviert",
        ("metadata", True): "Metadaten aktiviert",
        ("metadata", False): "Metadaten deaktiviert",
        ("read", True): "Als gelesen markiert",
        ("read", False): "Als ungelesen markiert",
    }

    def _show_action_feedback(self, text):
        """Bilanz unter der Tabelle setzen; leerer Text entfernt sie wieder.

        Bewusst nicht modal: eine erfolgreiche Auswahlaktion soll den
        Ablauf nicht mit einem weiteren Dialog anhalten.
        """
        self.action_feedback.setText(text)

    def _set_row_choice(self, index, key, value, caps=None):
        """Zeile und Check-Zelle setzen; False = war schon so.

        Die Auswahl folgt dem Cloud-Lesestatus; übertragen wird sie beim Sync.
        """
        row = self.rows[index]
        caps = row_capabilities(row) if caps is None else caps
        if not caps.get(key):
            return False
        column = self.ACTION_KEYS.index(key)
        if key == "read":
            state = row["read"]
            if state.chosen == bool(value):
                return False
            state.chosen = bool(value)
        else:
            if bool(row.get(key)) == bool(value):
                return False
            row[key] = bool(value)
        self._set_check_quietly(index, column, bool(value))
        return True

    def _sort_by_column(self, column):
        """Spaltenkopf anklicken: aufsteigend <-> absteigend umschalten."""
        if not 0 <= column < len(self.COLUMNS):
            return
        # Die Zeilen sind die einzige Quelle der Auswahl; die Check-Zellen
        # entstehen beim Neuaufbau aus ihnen.
        if self._sort_column == column:
            self._sort_descending = not self._sort_descending
        else:
            self._sort_column = column
            self._sort_descending = False
        ordered = sorted(self.rows, key=self.COLUMNS[column].sort_key,
                         reverse=self._sort_descending)
        self.table.horizontalHeader().setSortIndicator(
            column, Qt.SortOrder.DescendingOrder if self._sort_descending
            else Qt.SortOrder.AscendingOrder)
        self._rebuild_table(ordered)

    def _build_action_items(self, row_index, row, has_book, in_cloud):
        """Die drei Check-Zellen einer Buchzeile anlegen."""
        caps = row_capabilities(row)
        ignored = bool(row.get("ignored"))
        delete_cloud = bool(row.get("delete_cloud"))
        specs = (
            ("upload", caps["upload"],
             "Buchdatei in die Cloud hochladen.",
             "Nur in tolino – es gibt keine Calibre-Datei zum Hochladen."
             if not has_book else
             "Kein Buchformat aus den Upload-Formaten vorhanden."),
            ("metadata", caps["metadata"],
             "Titel, Autor und ISBN in der Cloud aktualisieren, ohne Upload.",
             "Nur in Calibre – es gibt in tolino nichts zu aktualisieren."
             if has_book else "Kein Calibre-Buch – nichts zu aktualisieren."),
            ("read", caps["read"],
             self.READ_TOOLTIP + " Im ausgewählten tolino-Konto änderbar.",
             "Lesestatus unbekannt – nicht geladen." if in_cloud else
             "Geht erst, wenn das Buch in tolino liegt."),
        )
        for column, (key, enabled, tooltip, disabled_tooltip) in enumerate(specs):
            item = QTableWidgetItem("")
            check = _ActionCheck(item)
            check.setEnabled(enabled)
            # Eine deaktivierte Aktion nie angehakt zeigen -- sonst sähe eine
            # ignorierte oder zum Löschen markierte Zeile ausgewählt aus.
            check.setChecked(bool(row.get(key)) and enabled)
            if (key == "upload" and row.get("match_reason") in
                    ("title_only", "ambiguous")):
                tooltip = "Kann ein Duplikat erzeugen."
            check.setToolTip(
                self.IGNORED_TOOLTIP if ignored
                else tooltip if enabled
                else (self.DELETE_TOOLTIP if delete_cloud
                      else disabled_tooltip))
            self.table.setItem(row_index, column, item)

    def _row_display_values(self, row, has_book, in_cloud):
        """Render explanation and the non-action cells for one comparison row."""
        explanation = str(row.get("explanation", "") or "")
        if in_cloud and not row["read"].known:
            explanation = (explanation + " Lesestatus unbekannt.").strip()
        elif in_cloud and has_book and row.get("read_column"):
            local = row["read"].local
            note = ("Calibre-Lesestatus: leer." if local is None
                    else "Calibre-Lesestatus: %s." % (
                        "gelesen" if local else "ungelesen"))
            explanation = (explanation + " " + note).strip()
        if row.get("delete_cloud"):
            explanation = (explanation + " Wird beim Start aus tolino gelöscht.").strip()
        return (
            "✓" if has_book else "",
            "✓" if in_cloud else "",
            row.get("title", ""), row.get("authors", ""), explanation,
            row.get("isbn", ""), row.get("tolino_id", ""), row.get("uuid", ""),
        )

    def _rebuild_table(self, rows, resize_columns=False):
        """Tabelle aus den (ggf. sortierten) Zeilen neu aufbauen."""
        self.table.setUpdatesEnabled(False)
        self._syncing_checks = True
        try:
            self.rows = [dict(row) for row in rows]
            self.table.setRowCount(0)
            self.table.setRowCount(len(self.rows))
            for row_index, row in enumerate(self.rows):
                has_book = row.get("book_id") is not None
                in_cloud = bool(row.get("tolino_id"))
                self._build_action_items(row_index, row, has_book, in_cloud)
                values = self._row_display_values(row, has_book, in_cloud)
                for column, value in enumerate(
                        values, len(self.ACTION_COLUMNS)):
                    self.table.setItem(
                        row_index, column, QTableWidgetItem(str(value or "")))
            if resize_columns:
                self.table.resizeColumnsToContents()
            self._size_columns()
            self._apply_technical_visibility()
            self._apply_group_filter()
        finally:
            # Auch ein Fehler beim Aufbau darf die Tabelle nicht dauerhaft
            # unsichtbar lassen (setUpdatesEnabled bleibt sonst aus).
            self._syncing_checks = False
            self.table.setUpdatesEnabled(True)
        self._update_summary()

    def _size_columns(self):
        """Schmale Standardansicht: Textspalten wachsen, Rest bleibt kompakt.

        Ohne das erzwingen Titel und Hinweis eine sehr breite Tabelle und
        damit eine Mindestbreite weit über einem 1366x768-Fenster.
        """
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(self.HINT_COLUMN,
                                    QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(self.TITLE_COLUMN,
                                    QHeaderView.ResizeMode.Interactive)
        header.resizeSection(self.TITLE_COLUMN, 160)
        header.setSectionResizeMode(self.AUTHORS_COLUMN,
                                    QHeaderView.ResizeMode.Interactive)
        header.resizeSection(self.AUTHORS_COLUMN, 90)
        # Aktions- und Ortsmarkierungen brauchen nur das Kästchen. Lange
        # Ueberschriften machten den Titel sonst auf wenige Zeichen breit.
        for column in range(self.TITLE_COLUMN):
            header.setSectionResizeMode(
                column, QHeaderView.ResizeMode.Interactive)
            header.resizeSection(column, 60)

    def _fit_title_column(self):
        """Titelbreite an das Fenster anpassen, ohne den Autor zu ueberholen."""
        header = self.table.horizontalHeader()
        fixed = sum(header.sectionSize(column)
                    for column in range(len(self.COLUMNS))
                    if column not in (self.TITLE_COLUMN, self.HINT_COLUMN))
        available = self.table.viewport().width() - fixed
        if available > 0:
            header.resizeSection(self.TITLE_COLUMN,
                                 max(120, available * 2 // 3))

    def showEvent(self, event):
        QDialog.showEvent(self, event)
        self._fit_title_column()

    def resizeEvent(self, event):
        QDialog.resizeEvent(self, event)
        self._fit_title_column()

    def _apply_group_filter(self, *_args):
        """Gruppenfilter ohne die Zeilen/Wahlzustaende zu verlieren.

        Es werden nur Tabellenzeilen versteckt; `self.rows` bleibt die
        vollstaendige Liste, damit Auswahl und Sortierung unberuehrt bleiben.
        """
        combo = self.group_filter
        selected = combo.currentData()
        for index, row in enumerate(self.rows):
            visible = selected is None or row.get("group") == selected
            self.table.setRowHidden(index, not visible)

    def _selection_counts(self):
        """Alle Zahlen der Zusammenfassung in EINEM Durchlauf über die Zeilen.

        Frueher zaehlten vier Methoden dieselben Zeilen je sechsmal -- bei
        jedem Klick und nach jedem Neuaufbau.
        """
        uploads, metadata = set(), set()
        marked_read = marked_unread = deletions = undecided = 0
        review_groups = ("review", "duplicate_tolino", "not_matchable")
        for row in self.rows:
            if row.get("group") in review_groups:
                undecided += 1
            caps = row_capabilities(row)
            if caps["delete"] and row.get("delete_cloud"):
                deletions += 1
            if caps["upload"] and row.get("upload"):
                uploads.add(row["book_id"])
            if caps["metadata"] and row.get("metadata"):
                metadata.add(row["book_id"])
            if not caps["read"]:
                continue
            state = row["read"]
            if not state.changed:
                continue
            if state.chosen:
                marked_read += 1
            else:
                marked_unread += 1
        work = (len(uploads) + len(metadata) + marked_read
                + marked_unread + deletions)
        return {"uploads": len(uploads), "metadata": len(metadata),
                "read": marked_read, "unread": marked_unread,
                "deletions": deletions, "undecided": undecided,
                "work": work}

    def _update_summary(self, *_args):
        """Kurzzeile: wie viele Aktionen gerade ausgewählt sind."""
        counts = self._selection_counts()
        uploads = counts["uploads"]
        metadata = counts["metadata"]
        marked_read = counts["read"]
        marked_unread = counts["unread"]
        deletions = counts["deletions"]
        changes = marked_read + marked_unread
        summary = self.summary
        if summary is not None:
            summary_text = (
                "Ausgewählt: %d %s · %d Metadaten · %d Lesestatus"
                % (uploads, plural(uploads, "Upload", "Uploads"),
                   metadata, changes))
            if changes:
                summary_text += (
                    " (davon %d gelesen, %d ungelesen)"
                    % (marked_read, marked_unread))
            if deletions:
                summary_text += " · %d %s" % (
                    deletions, plural(deletions, "Löschung", "Löschungen"))
            undecided = counts["undecided"]
            if undecided:
                summary_text += (
                    " · %d %s unklar («Zu prüfen», nicht vorausgewählt)"
                    % (undecided, plural(undecided, "Buch", "Bücher")))
            summary.setText(summary_text)
        confirm = self.confirm
        if confirm is not None:
            total = counts["work"]
            confirm.setText("Synchronisierung starten (%d)" % total
                            if total else "Synchronisierung starten")
            confirm.setEnabled(total > 0 or self.automatic_actions_enabled())

    # --- Cloud actions on the currently selected table row ---------------

    def _selected_row(self):
        """The comparison row for the selection, or None with a hint.

        Download und Sammlungen arbeiten mit genau einem Buch; mehrere
        markierte Zeilen werden deshalb abgelehnt statt still nur die erste
        zu verarbeiten.
        """
        selected = _selected_rows(self.table)
        if not selected:
            QMessageBox.information(
                self, "Buch auswählen",
                "Markiere zuerst das Buch, für das du diese Aktion "
                "ausführen möchtest.")
            return None
        if len(selected) > 1:
            QMessageBox.information(
                self, "Ein Buch auswählen",
                "Diese Aktion gilt nur für ein Buch. Markiere genau ein "
                "Buch in der Tabelle.")
            return None
        row_index = selected[0]
        if row_index >= len(self.rows):
            return None
        return self.rows[row_index]

    def _cached_or_new_client(self):
        """Client holen -- im Worker-Thread, ohne Widget-Zugriff.

        Fehler werden als Exception weitergereicht; Meldungsfenster und
        Zustand bleiben Sache des GUI-Threads.
        """
        if self._cached_client is not None:
            return self._cached_client
        if self.client_factory is None:
            raise RuntimeError("Keine Anmeldung verfügbar.")
        client = self.client_factory()
        if client is not None:
            self._cached_client = client
        return client

    def _start_action(self, call, on_done, on_failed, text=""):
        """Netzaufruf auslagern; genau eine Aktion zur Zeit.

        Waehrenddessen sind Tabelle und Startknopf gesperrt, die Statuszeile
        nennt den Schritt -- kein modales Fenster, kein eingefrorenes Calibre.
        """
        if self._call_thread is not None:
            return
        self._set_action_busy(True, text)
        start_call(self, call, on_done, on_failed)

    def _end_action(self):
        self._call_thread = None
        self._set_action_busy(False)

    def _set_action_busy(self, busy, text=""):
        _set_enabled(self, ("table", "confirm"), not busy)
        if busy:
            self.summary.setText(text or "Verbindung zu tolino …")
        else:
            self._update_summary()

    def download_selected(self):
        row = self._selected_row()
        if row is None:
            return
        tolino_id = row.get("tolino_id")
        if not tolino_id:
            QMessageBox.information(
                self, "Buch nicht in tolino vorhanden",
                "Dieses Buch kann nicht aus tolino heruntergeladen werden, "
                "weil es im ausgewählten Konto nicht vorhanden ist.")
            return
        # Erst den Speicherort erfragen, dann laden: ein Abbruch im
        # Dateidialog soll keinen Download ausloesen.
        title = str(row.get("title") or "tolino-book")
        title = re.sub(r'[\\/:*?"<>|]', "_", title).strip(" .") or "tolino-book"
        extension = ".epub"
        suggested = title + extension
        path, _ = QFileDialog.getSaveFileName(
            self, "Buch speichern", suggested,
            "EPUB (*.epub);;PDF (*.pdf)")
        if not path:
            return
        self._download_path = path
        self._start_action(
            lambda: self._download_content(tolino_id),
            self._download_finished,
            self._download_failed,
            "Buchdatei wird aus tolino geladen …")

    def _download_content(self, tolino_id):
        """Buchdatei ohne Zusatzdateien im Hintergrund laden."""
        client = self._cached_or_new_client()
        return client.download(tolino_id)

    def _download_finished(self, result):
        path = self._download_path
        self._end_action()
        if result[:4] == b"%PDF" and path.casefold().endswith(".epub"):
            path = path[:-5] + ".pdf"
        try:
            with open(path, "wb") as handle:
                handle.write(result)
        except OSError as exc:
            message = report_error(exc, "Speichern")
            error_dialog(self, "Speichern fehlgeschlagen",
                         message, show=True)
            return
        info_dialog(self, "Buch gespeichert", "Gespeichert unter: %s" % path,
                    show=True, show_copy_button=False)

    def _action_failed(self, title, summary, exc, context):
        """Nach einem gescheiterten Netzaufruf: aufräumen, neu anmelden, melden."""
        self._end_action()
        self._cached_client = None
        error_dialog(self, title,
                     summary + "\n\n" + report_error(exc, context), show=True)

    def _download_failed(self, exc):
        self._action_failed(
            "Cloud-Download fehlgeschlagen",
            "Der Download ist fehlgeschlagen. Details stehen im Calibre-Log.",
            exc, "Download")

    def delete_marked_from_cloud(self):
        """Markierte Cloud-Kopien zum Löschen vormerken.

        Gelöscht wird erst mit «Synchronisierung starten»; dort werden die
        konkreten Titel noch einmal bestätigt. Die Calibre-Bücher und ihre
        Dateien bleiben unangetastet.
        """
        marked = self._marked_row_indexes()
        if not marked:
            return
        candidates = []
        for index in marked:
            if not 0 <= index < len(self.rows):
                continue
            row = self.rows[index]
            if row.get("delete_cloud") or not row_capabilities(row)["delete"]:
                continue
            candidates.append(row)
        if not candidates:
            QMessageBox.information(
                self, "Nichts zu löschen",
                "Es wurde nichts geändert: Die markierten Bücher liegen nicht "
                "in tolino oder sind bereits zum Löschen markiert.")
            return
        for row in candidates:
            row["delete_cloud"] = True
            row["upload"] = False
            row["metadata"] = False
        self._rebuild_table(self.rows)

    def clear_cloud_delete_for_marked_rows(self):
        """Löschmarkierung der markierten Zeilen wieder aufheben."""
        marked = self._marked_row_indexes()
        if not marked:
            return
        changed = 0
        for index in marked:
            if (0 <= index < len(self.rows)
                    and self.rows[index].pop("delete_cloud", None) is not None):
                changed += 1
        if not changed:
            QMessageBox.information(
                self, "Löschmarkierung aufheben",
                "Es wurde nichts geändert: Die markierten Bücher sind nicht "
                "zum Löschen vorgemerkt.")
            return
        self._rebuild_table(self.rows)
