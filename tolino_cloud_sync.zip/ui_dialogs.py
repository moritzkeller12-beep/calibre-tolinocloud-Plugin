0                                                
import re
from typing import NamedTuple

from .ui_common import (QCheckBox, QComboBox, QDialog, QFileDialog,
                        QHBoxLayout, QHeaderView, QLabel, QMessageBox,
                        QMenu, QPushButton, QTableWidget, QTableWidgetItem,
                        QVBoxLayout, QStyledItemDelegate, QStyle,
                        QStyleOptionViewItem, QEvent, Qt, _set_enabled,
                        gui_guard, start_call)
from .planning_values import plural
from calibre.gui2 import error_dialog, info_dialog
from .comparison import comparison_sort_key, sort_comparison_rows
from .library import TOLINO_IGNORE_COLUMN
from .tolino import report_error


def _selected_rows(table):
    0                                                
    return [index.row() for index in table.selectionModel().selectedRows()]


def _by_title(row):
    return (str(row.get("title") or "").casefold(),
            str(row.get("authors") or "").casefold())


def _by_authors(row):
    return (str(row.get("authors") or "").casefold(),
            str(row.get("title") or "").casefold())


def _by_field(field):
    return lambda row: (str(row.get(field) or ""), _by_title(row)[0])


_by_hint = _by_field("explanation")
_by_isbn = _by_field("isbn")
_by_tolino_id = _by_field("tolino_id")
_by_uuid = _by_field("uuid")


def _by_calibre(row):
    return (0 if row.get("book_id") is not None else 1,) + _by_title(row)


def _by_cloud(row):
    return (0 if row.get("tolino_id") else 1,) + _by_title(row)


def _metadata_first(row):
    return ((0 if row.get("metadata") else 1,)
            + comparison_sort_key(row)[2:])


def _read_first(row):
    return ((0 if row.get("read") else 1,)
            + _by_title(row))


def _by_progress(row):
    0                                                                  
    progress = row.get("progress")
    percent = (getattr(progress, "percent", None)
               if getattr(progress, "known", False) else None)
    return ((0 if percent is not None else 1,)
            + (-int(percent) if percent is not None else 0,)
            + _by_title(row))


class _Column(NamedTuple):
    0                                                                       

    label: str
    tooltip: str
    sort_key: object
    technical: bool = False


def row_capabilities(row):
    0                                                                      

                                                                       
                                                                       
                                                                          
                                                          
       
    has_book = row.get("book_id") is not None
    in_cloud = bool(row.get("tolino_id"))
    ignored = bool(row.get("ignored"))
    deleting = bool(row.get("delete_cloud"))
    usable = not ignored and not deleting
    return {
        "upload": bool(has_book and usable
                       and row.get("has_preferred_format", True)),
        "metadata": bool(has_book and in_cloud and usable),
        "read": bool(in_cloud and usable and row["read"].known),


        "download": in_cloud,
        "delete": bool(in_cloud and not ignored),
        "usable": usable,
    }


class _ActionCheck:
    0                                                                      

    def __init__(self, item):
        self.item = item

    def isChecked(self):
        return self.item.checkState() == Qt.CheckState.Checked

    def setChecked(self, value):

        self.item.setCheckState(
            Qt.CheckState.Checked if value else Qt.CheckState.Unchecked)

    def setEnabled(self, enabled):
        flags = self.item.flags()


        flags |= Qt.ItemFlag.ItemIsUserCheckable
        if enabled:
            flags |= Qt.ItemFlag.ItemIsEnabled
        else:
            flags &= ~Qt.ItemFlag.ItemIsEnabled
        self.item.setFlags(flags)

    def setToolTip(self, text):
        self.item.setToolTip(str(text or ""))


class _CenteredCheckDelegate(QStyledItemDelegate):
    0                                                                   

    def paint(self, painter, option, index):
        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        style = opt.widget.style() if opt.widget is not None else None
        if style is None:
            QStyledItemDelegate.paint(self, painter, option, index)
            return
        style.drawPrimitive(
            QStyle.PrimitiveElement.PE_PanelItemViewItem,
            opt, painter, opt.widget)
        if opt.features & QStyleOptionViewItem.ViewItemFeature.HasCheckIndicator:
            if opt.checkState == Qt.CheckState.PartiallyChecked:
                opt.state |= QStyle.StateFlag.State_NoChange
            elif opt.checkState == Qt.CheckState.Checked:
                opt.state |= QStyle.StateFlag.State_On
            else:
                opt.state |= QStyle.StateFlag.State_Off
            rect = style.subElementRect(
                QStyle.SubElement.SE_ItemViewItemCheckIndicator,
                opt, opt.widget)
            opt.rect = QStyle.alignedRect(
                opt.direction, Qt.AlignmentFlag.AlignCenter,
                rect.size(), opt.rect)
            opt.state &= ~QStyle.StateFlag.State_HasFocus
            style.drawPrimitive(
                QStyle.PrimitiveElement.PE_IndicatorItemViewItemCheck,
                opt, painter, opt.widget)
        else:
            QStyledItemDelegate.paint(self, painter, option, index)

    def editorEvent(self, event, model, option, index):
        if event.type() in (QEvent.Type.MouseButtonRelease,
                            QEvent.Type.MouseButtonDblClick):
            if event.button() != Qt.MouseButton.LeftButton:
                return False
            flags = model.flags(index)
            if not (flags & Qt.ItemFlag.ItemIsUserCheckable):
                return False
            if not (flags & Qt.ItemFlag.ItemIsEnabled):
                return False
            state = index.data(Qt.ItemDataRole.CheckStateRole)
            state = (Qt.CheckState.Unchecked
                     if state == Qt.CheckState.Checked
                     else Qt.CheckState.Checked)
            return model.setData(index, state, Qt.ItemDataRole.CheckStateRole)
        return QStyledItemDelegate.editorEvent(self, event, model, option, index)


class InventoryDialog(QDialog):
    0                                                         

                                                                          
                                                                      
                                                                      
                                            
       

    ACTION_COLUMNS = (
        _Column("Upload", "Buchdatei in die Cloud hochladen.",
                comparison_sort_key),
        _Column("Metadaten",
                "Titel, Autor und ISBN ohne Upload aktualisieren.",
                _metadata_first),
        _Column("Gelesen",
                "Auswahl = gelesen; keine Auswahl = ungelesen. Die "
                "Calibre-Spalte #tolino_read ist nur informativ.",
                _read_first),
    )
    DATA_COLUMNS = (
        _Column("Calibre", "Buch in Calibre vorhanden.", _by_calibre),
        _Column("tolino",
                "Buch im ausgewählten tolino-Konto vorhanden.", _by_cloud),
        _Column("Buchtitel", "Buchtitel", _by_title),
        _Column("Autor(en)", "Autor(en)", _by_authors),
        _Column("Hinweis", "Grund und Unterschiede des Vergleichs.",
                _by_hint),
        _Column("Fortschritt",
                "Lesefortschritt aus tolino (nur Anzeige, kein "
                "Rückschreiben).", _by_progress),
        _Column("ISBN", "ISBN (technisch, ausgeblendet)", _by_isbn, True),
        _Column("tolino-ID",
                "tolino-ID der Cloud-Kopie (technisch, ausgeblendet)",
                _by_tolino_id, True),
        _Column("UUID",
                "Calibre-UUID (technisch, ausgeblendet)", _by_uuid, True),
    )
    COLUMNS = ACTION_COLUMNS + DATA_COLUMNS
    HEADERS = tuple(column.label for column in COLUMNS)
    ACTION_KEYS = ("upload", "metadata", "read")
    TECHNICAL_COLUMNS = tuple(index for index, column in enumerate(COLUMNS)
                              if column.technical)
    TITLE_COLUMN = HEADERS.index("Buchtitel")
    AUTHORS_COLUMN = HEADERS.index("Autor(en)")
    HINT_COLUMN = HEADERS.index("Hinweis")
    GROUP_FILTERS = (
        ("Alle", None),
        ("Aktion nötig", "action"),
        ("Nur in tolino", "tolino_only"),
        ("Zu prüfen", "review"),
        ("Unverändert", "unchanged"),
        ("Ignoriert", "ignored"),
    )

    READ_TOOLTIP = "Ausgewählt = gelesen, nicht ausgewählt = ungelesen."
    IGNORED_TOOLTIP = ("In Calibre ignoriert (%s) – wird nicht "
                       "abgeglichen." % TOLINO_IGNORE_COLUMN)
    DELETE_TOOLTIP = ("Zum Löschen aus tolino markiert – zuerst "
                      "«Löschmarkierung aufheben».")
    INTRO_TEXT = ("Wähle pro Buch: Upload (Datei), Metadaten "
                  "(Titel, Autor, ISBN) oder Lesestatus. Geändert wird erst "
                  "mit «Synchronisierung starten».")



    ROW_ACTIONS = (
        ("Upload aktivieren", "set_column_for_marked_rows",
         ("upload", True, "haben schon diese Auswahl oder keine Datei"),
         lambda row: (row_capabilities(row)["upload"]
                      and not row.get("upload"))),
        ("Upload deaktivieren", "set_column_for_marked_rows",
         ("upload", False, "waren schon abgewählt oder haben keine Datei"),
         lambda row: bool(row.get("upload"))),
        ("Metadaten aktivieren", "set_column_for_marked_rows",
         ("metadata", True,
          "haben schon diese Auswahl oder liegen nicht in der Cloud"),
         lambda row: (row_capabilities(row)["metadata"]
                      and not row.get("metadata"))),
        ("Metadaten deaktivieren", "set_column_for_marked_rows",
         ("metadata", False,
          "waren schon abgewählt oder liegen nicht in der Cloud"),
         lambda row: bool(row.get("metadata"))),
        ("Als gelesen markieren", "set_column_for_marked_rows",
         ("read", True,
          "sind schon gelesen oder liegen nicht in der Cloud"),
         lambda row: (row_capabilities(row)["read"]
                      and not row.get("read"))),
        ("Als ungelesen markieren", "set_column_for_marked_rows",
         ("read", False,
          "sind bereits ungelesen oder liegen nicht in der Cloud"),
         lambda row: (row_capabilities(row)["read"]
                      and row.get("read"))),
        ("Aus tolino herunterladen …", "download_selected", (),
         lambda row: row_capabilities(row)["download"]),
        ("Aus der tolino Cloud löschen …", "delete_marked_from_cloud", (),
         lambda row: (row_capabilities(row)["delete"]
                      and not row.get("delete_cloud"))),
        ("Löschmarkierung aufheben", "clear_cloud_delete_for_marked_rows", (),
         lambda row: bool(row.get("delete_cloud"))),
    )

    @staticmethod
    def default_actions(row):
        0                                                  

                                                                          
                                                                            
                         
           
        caps = row_capabilities(row)
        if not caps["usable"]:
            return (False, False)

        if row.get("status") == "review":
            return (False, False)
        if row.get("book_id") is None or not row.get("tolino_id"):
            if row.get("stale_cloud_id"):
                return (False, False)
            return (caps["upload"], False)
        if row.get("status") == "new_in_calibre":
            return (caps["upload"], False)
        if row.get("status") == "changed":
            if row.get("file_changed"):
                return (caps["upload"], False)
            return (False, caps["metadata"])
        return (False, False)

    def __init__(self, rows, parent=None, client_factory=None, options=None):
        QDialog.__init__(self, parent)
        self.client_factory = client_factory


        self._cached_client = None
        self.options = dict(options or {})
        self._technical_visible = False
        self._syncing_checks = False
        self._call_thread = None
        self.rows = []

        self.summary = None
        self.confirm = None
        self.action_feedback = None
        self._prepare_rows(rows)
        self.setAttribute(
            Qt.WidgetAttribute.WA_QuitOnClose, False)
        self.setMinimumSize(640, 460)
        self.resize(960, 560)
        layout = QVBoxLayout(self)
        self._build_header(layout)
        self._build_toolbar(layout)
        self._build_table(layout)
        self._build_footer(layout)

    def _prepare_rows(self, rows):
        0                                                          

                                                                 
           
        for row in rows:
            row = dict(row)
            if "upload" not in row or "metadata" not in row:
                row["upload"], row["metadata"] = self.default_actions(row)


            self.rows.append(row)
        self.rows = sort_comparison_rows(self.rows)

    def _build_header(self, layout):
        0                                                           
        intro = QLabel(self.INTRO_TEXT)
        intro.setWordWrap(True)
        layout.addWidget(intro)

        self.summary = QLabel()
        self.summary.setWordWrap(True)
        layout.addWidget(self.summary)

        self.note = QLabel(self._automatic_note())
        self.note.setWordWrap(True)
        if not self.note.text() and any(
                not row["read"].known for row in self.rows):
            self.note.setText(
                "Lesestatus unbekannt: konnte nicht geladen werden und "
                "wird nicht verändert.")
        if not self.note.text() and self.options.get("ignore_column") is False:
            self.note.setText(
                "Spalte %s (Ja/Nein) anlegen: so markierte Bücher werden "
                "nicht hochgeladen." % TOLINO_IGNORE_COLUMN)
        layout.addWidget(self.note)

    def _build_toolbar(self, layout):
        0                                                         
        helpers = QHBoxLayout()
        self.group_filter = QComboBox()
        for label, key in self.GROUP_FILTERS:
            self.group_filter.addItem(label, key)
        self.group_filter.setToolTip(
            "Filtert nach Aktion, Cloud-Bestand, Prüfung oder unverändert.")
        self.group_filter.currentIndexChanged.connect(
            self._apply_group_filter)
        self.recommend = QPushButton("Empfohlene Aktionen auswählen")
        self.recommend.setToolTip(
            "Wählt Upload oder Metadaten für eindeutig zugeordnete Bücher.")
        self.clear_selection = QPushButton("Auswahl zurücksetzen")
        self.clear_selection.setToolTip(
            "Setzt alle Auswahlen zurück. Nichts wird verändert.")
        helpers.addWidget(QLabel("Anzeigen"))
        helpers.addWidget(self.group_filter)
        helpers.addWidget(self.recommend)
        helpers.addWidget(self.clear_selection)
        helpers.addStretch(1)
        self.row_actions = QPushButton("Aktionen für markierte Bücher …")
        self.row_actions.setToolTip(
            "Zeilen mit Strg-/Shift-Klick markieren; alle mit Strg+A.")
        helpers.addWidget(self.row_actions)
        layout.addLayout(helpers)

    def _build_table(self, layout):
        0                                                             
        self.table = QTableWidget(0, len(self.HEADERS))
        self._check_delegate = _CenteredCheckDelegate(self.table)
        for column in range(len(self.ACTION_COLUMNS)):
            self.table.setItemDelegateForColumn(column, self._check_delegate)
        self.table.setHorizontalHeaderLabels(self.HEADERS)
        self.table.setSelectionBehavior(
            QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(
            QTableWidget.SelectionMode.ExtendedSelection)
        for index, column in enumerate(self.COLUMNS):
            self.table.horizontalHeaderItem(index).setToolTip(column.tooltip)



        self._sort_column = 0
        self._sort_descending = False
        table_header = self.table.horizontalHeader()
        table_header.setSortIndicatorShown(True)
        table_header.setSortIndicator(
            0, Qt.SortOrder.AscendingOrder)
        table_header.sectionClicked.connect(self._sort_by_column)
        self.table.itemChanged.connect(self._item_changed)
        self._rebuild_table(self.rows, resize_columns=True)
        layout.addWidget(self.table)

    def _build_footer(self, layout):
        0                                                              
        self.action_feedback = QLabel()
        self.action_feedback.setWordWrap(True)
        layout.addWidget(self.action_feedback)

        self.technical_toggle = QCheckBox(
            "Technische Details anzeigen (ISBN, tolino-ID, UUID)")
        self.technical_toggle.setToolTip(
            "Zeigt ISBN, tolino-ID und UUID.")
        self.technical_toggle.toggled.connect(self._toggle_technical_columns)
        layout.addWidget(self.technical_toggle)
        self._apply_technical_visibility()

        buttons = QHBoxLayout()
        confirm = QPushButton("Synchronisierung starten")
        confirm.setToolTip(
            "Überträgt die ausgewählten Änderungen.")
        cancel = QPushButton("Abbrechen")
        cancel.setToolTip(
            "Schließt den Vergleich, ohne Änderungen.")
        confirm.clicked.connect(self.accept)
        cancel.clicked.connect(self.reject)
        self.confirm = confirm
        self.cancel = cancel
        buttons.addWidget(confirm)
        buttons.addStretch(1)
        buttons.addWidget(cancel)
        layout.addLayout(buttons)
        self.recommend.clicked.connect(self.apply_recommended)
        self.clear_selection.clicked.connect(self.clear_all_selection)
        self.row_actions.clicked.connect(self.choose_row_action)
        self._update_summary()

    def _automatic_note(self):
        0                                                         
        count = int(self.options.get("automatic") or 0)
        if count:
            return "Serien werden als Sammlungen in tolino übernommen (%d offen)." % count
        return ""

    def _toggle_technical_columns(self, visible):
        self._technical_visible = bool(visible)
        self._apply_technical_visibility()

    def _apply_technical_visibility(self):
        for column in self.TECHNICAL_COLUMNS:
            self.table.setColumnHidden(column, not self._technical_visible)

    def _check(self, row_index, column):
        0                                                                        
        return _ActionCheck(self.table.item(row_index, column))

    def _choice_changed(self, row_index, column):
        0                                                           
        row = self.rows[row_index]
        key = self.ACTION_KEYS[column]
        checked = bool(self._check(row_index, column).isChecked())
        if key == "read":
            row["read"].chosen = checked
        else:
            row[key] = checked
        self._update_summary()

    def _set_check_quietly(self, row_index, column, value):
        0                                              

                                                                        
                                         
           
        previous = self._syncing_checks
        self._syncing_checks = True
        try:
            self._check(row_index, column).setChecked(value)
        finally:
            self._syncing_checks = previous

    def _item_changed(self, item):
        0                                                   
        if self._syncing_checks:
            return
        column = item.column()
        if column in range(len(self.ACTION_COLUMNS)):
            self._choice_changed(item.row(), column)

    def _set_selection(self, chooser, clear_deletions=False):
        0                                                              

                                                                       
                                                                            
                                
           
        if clear_deletions:
            for row in self.rows:
                row.pop("delete_cloud", None)
                row["upload"] = row["metadata"] = False
                state = row["read"]
                state.chosen = state.cloud
            self._rebuild_table(self.rows)
            return
        for index, row in enumerate(self.rows):
            caps = row_capabilities(row)
            if not caps["usable"]:
                continue
            wanted = tuple(chooser(row))
            upload = bool(wanted[0]) and caps["upload"]
            metadata = bool(wanted[1]) and caps["metadata"]
            row.update(upload=upload, metadata=metadata)
            for column, checked in ((0, upload), (1, metadata)):
                self._set_check_quietly(index, column, checked)
        self._update_summary()

    def apply_recommended(self):
        0                                                           
        self._set_selection(self.default_actions)

    def clear_all_selection(self):
        self._set_selection(lambda _row: (False, False),
                            clear_deletions=True)

    def automatic_actions_enabled(self):
        0                                             

                                                                           
                                                                          
                                                       
           
        try:
            return int(self.options.get("automatic") or 0) > 0
        except (TypeError, ValueError):
            return False

    def selected_cloud_deletions(self):
        0                                                                     
        return [(str(row.get("uuid") or ""), str(row["tolino_id"]),
                 str(row.get("title") or ""))
                for row in self.rows
                if row.get("delete_cloud") and row_capabilities(row)["delete"]]

    def _selected_book_ids(self, key):
        0                                                               
        return {row["book_id"] for row in self.rows
                if row.get(key) and row_capabilities(row).get(key)}

    def selected_read_changes(self):
        0                                                              

                                                                        
                                                                        
                                                                   
           
        changes = []
        for row in self.rows:
            state = row["read"]
            if not row_capabilities(row)["read"] or not state.changed:
                continue
            changes.append((str(row["tolino_id"]), row.get("book_id"),
                            state.chosen))
        return changes

    def _marked_row_indexes(self):
        0                                                                  
        marked = _selected_rows(self.table)
        if not marked:
            QMessageBox.information(
                self, "Aktionen für markierte Bücher",
                "Markiere zuerst mindestens ein Buch in der Tabelle. "
                "Mehrere Bücher wählst du mit Strg-/Shift-Klick aus.")
        return marked

    def choose_row_action(self):
        0                                                    

                                                                             
                                                
           
        marked = self._marked_row_indexes()
        if not marked:
            return
        menu = QMenu(self)
        actions = {}
        row_indexes = [index for index in marked
                       if 0 <= index < len(self.rows)]
        for label, method, args, predicate in self.ROW_ACTIONS:
            if not any(predicate(self.rows[index]) for index in row_indexes):
                continue
            actions[menu.addAction(label)] = (method, args)
        position = self.row_actions.mapToGlobal(
            self.row_actions.rect().bottomLeft())
        chosen = menu.exec(position)
        handler = actions.get(chosen)
        if handler is None:
            return
        method, args = handler
        getattr(self, method)(*args)

    def set_column_for_marked_rows(self, key, value, summary):
        0                                               

                                                                            
                                                                           
                                                                       
           
        marked = self._marked_row_indexes()
        if not marked:
            return
        changed = 0
        skipped = 0
        for index in marked:
            if not 0 <= index < len(self.rows):
                continue
            caps = row_capabilities(self.rows[index])
            if not caps.get(key):
                skipped += 1
                continue
            if self._set_row_choice(index, key, bool(value), caps):
                changed += 1
            else:
                skipped += 1
        self._update_summary()
        if not changed:
            self._show_action_feedback("")
            count = skipped or len(marked)
            QMessageBox.information(
                self, "Nichts geändert",
                "Nichts geändert: %d markierte %s %s."
                % (count, plural(count, "Buch", "Bücher"), summary))
            return
        feedback = "%s für %d von %d markierten Büchern" % (
            self.ACTION_LABELS.get((key, bool(value)), "Aktion ausgeführt"),
            changed, len(marked))
        if skipped:
            feedback += "; %d übersprungen" % skipped
        self._show_action_feedback(feedback + ".")

    ACTION_LABELS = {
        ("upload", True): "Upload aktiviert",
        ("upload", False): "Upload deaktiviert",
        ("metadata", True): "Metadaten aktiviert",
        ("metadata", False): "Metadaten deaktiviert",
        ("read", True): "Als gelesen markiert",
        ("read", False): "Als ungelesen markiert",
    }

    def _show_action_feedback(self, text):
        0                                                                  

                                                                     
                                                        
           
        self.action_feedback.setText(text)

    def _set_row_choice(self, index, key, value, caps=None):
        0                                                    

                                                                              
           
        row = self.rows[index]
        caps = row_capabilities(row) if caps is None else caps
        if not caps.get(key):
            return False
        column = self.ACTION_KEYS.index(key)
        if key == "read":
            state = row["read"]
            if state.chosen == bool(value):
                return False
            state.chosen = bool(value)
        else:
            if bool(row.get(key)) == bool(value):
                return False
            row[key] = bool(value)
        self._set_check_quietly(index, column, bool(value))
        return True

    def _sort_by_column(self, column):
        0                                                                 
        if not 0 <= column < len(self.COLUMNS):
            return


        if self._sort_column == column:
            self._sort_descending = not self._sort_descending
        else:
            self._sort_column = column
            self._sort_descending = False
        ordered = sorted(self.rows, key=self.COLUMNS[column].sort_key,
                         reverse=self._sort_descending)
        self.table.horizontalHeader().setSortIndicator(
            column, Qt.SortOrder.DescendingOrder if self._sort_descending
            else Qt.SortOrder.AscendingOrder)
        self._rebuild_table(ordered)

    def _build_action_items(self, row_index, row, has_book, in_cloud):
        0                                                  
        caps = row_capabilities(row)
        ignored = bool(row.get("ignored"))
        delete_cloud = bool(row.get("delete_cloud"))
        specs = (
            ("upload", caps["upload"],
             "Buchdatei in die Cloud hochladen.",
             "Nur in tolino – es gibt keine Calibre-Datei zum Hochladen."
             if not has_book else
             "Kein Buchformat aus den Upload-Formaten vorhanden."),
            ("metadata", caps["metadata"],
             "Titel, Autor und ISBN in der Cloud aktualisieren, ohne Upload.",
             "Nur in Calibre – es gibt in tolino nichts zu aktualisieren."
             if has_book else "Kein Calibre-Buch – nichts zu aktualisieren."),
            ("read", caps["read"],
             self.READ_TOOLTIP + " Im ausgewählten tolino-Konto änderbar.",
             "Lesestatus unbekannt – nicht geladen." if in_cloud else
             "Geht erst, wenn das Buch in tolino liegt."),
        )
        for column, (key, enabled, tooltip, disabled_tooltip) in enumerate(specs):
            item = QTableWidgetItem("")
            check = _ActionCheck(item)
            check.setEnabled(enabled)


            check.setChecked(bool(row.get(key)) and enabled)
            if (key == "upload" and row.get("match_reason") in
                    ("title_only", "ambiguous")):
                tooltip = "Kann ein Duplikat erzeugen."
            check.setToolTip(
                self.IGNORED_TOOLTIP if ignored
                else tooltip if enabled
                else (self.DELETE_TOOLTIP if delete_cloud
                      else disabled_tooltip))
            self.table.setItem(row_index, column, item)

    def _row_display_values(self, row, has_book, in_cloud):
        0                                                                       
        explanation = str(row.get("explanation", "") or "")
        if in_cloud and not row["read"].known:
            explanation = (explanation + " Lesestatus unbekannt.").strip()
        elif in_cloud and has_book and row.get("read_column"):
            local = row["read"].local
            note = ("Calibre-Lesestatus: leer." if local is None
                    else "Calibre-Lesestatus: %s." % (
                        "gelesen" if local else "ungelesen"))
            explanation = (explanation + " " + note).strip()
        if row.get("delete_cloud"):
            explanation = (explanation + " Wird beim Start aus tolino gelöscht.").strip()
        progress = row.get("progress")
        progress_text = (progress.text if progress is not None
                         else "")
        return (
            "✓" if has_book else "",
            "✓" if in_cloud else "",
            row.get("title", ""), row.get("authors", ""), explanation,
            progress_text,
            row.get("isbn", ""), row.get("tolino_id", ""), row.get("uuid", ""),
        )

    def _rebuild_table(self, rows, resize_columns=False):
        0                                                          
        self.table.setUpdatesEnabled(False)
        self._syncing_checks = True
        try:
            self.rows = list(rows)
            self.table.setRowCount(0)
            self.table.setRowCount(len(self.rows))
            for row_index, row in enumerate(self.rows):
                has_book = row.get("book_id") is not None
                in_cloud = bool(row.get("tolino_id"))
                self._build_action_items(row_index, row, has_book, in_cloud)
                values = self._row_display_values(row, has_book, in_cloud)
                for column, value in enumerate(
                        values, len(self.ACTION_COLUMNS)):
                    self.table.setItem(
                        row_index, column, QTableWidgetItem(str(value or "")))
            if resize_columns:
                self.table.resizeColumnsToContents()
            self._size_columns()
            self._apply_technical_visibility()
            self._apply_group_filter()
        finally:


            self._syncing_checks = False
            self.table.setUpdatesEnabled(True)
        self._update_summary()

    def _size_columns(self):
        0                                                                   

                                                                         
                                                                  
           
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(self.HINT_COLUMN,
                                    QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(self.TITLE_COLUMN,
                                    QHeaderView.ResizeMode.Interactive)
        header.resizeSection(self.TITLE_COLUMN, 160)
        header.setSectionResizeMode(self.AUTHORS_COLUMN,
                                    QHeaderView.ResizeMode.Interactive)
        header.resizeSection(self.AUTHORS_COLUMN, 90)


        for column in range(self.TITLE_COLUMN):
            header.setSectionResizeMode(
                column, QHeaderView.ResizeMode.Interactive)
            header.resizeSection(column, 60)

    def _fit_title_column(self):
        0                                                                      
        header = self.table.horizontalHeader()
        fixed = sum(header.sectionSize(column)
                    for column in range(len(self.COLUMNS))
                    if column not in (self.TITLE_COLUMN, self.HINT_COLUMN))
        available = self.table.viewport().width() - fixed
        if available > 0:
            header.resizeSection(self.TITLE_COLUMN,
                                 max(120, available * 2 // 3))

    def showEvent(self, event):
        QDialog.showEvent(self, event)
        self._fit_title_column()

    def resizeEvent(self, event):
        QDialog.resizeEvent(self, event)
        self._fit_title_column()

    def _apply_group_filter(self, *_args):
        0                                                          

                                                                      
                                                                             
           
        combo = self.group_filter
        selected = combo.currentData()
        for index, row in enumerate(self.rows):
            visible = selected is None or row.get("group") == selected
            self.table.setRowHidden(index, not visible)

    def _selection_counts(self):
        0                                                                    

                                                                          
                                             
           
        uploads, metadata = set(), set()
        marked_read = marked_unread = deletions = undecided = 0
        review_groups = ("review", "duplicate_tolino", "not_matchable")
        for row in self.rows:
            if row.get("group") in review_groups:
                undecided += 1
            caps = row_capabilities(row)
            if caps["delete"] and row.get("delete_cloud"):
                deletions += 1
            if caps["upload"] and row.get("upload"):
                uploads.add(row["book_id"])
            if caps["metadata"] and row.get("metadata"):
                metadata.add(row["book_id"])
            if not caps["read"]:
                continue
            state = row["read"]
            if not state.changed:
                continue
            if state.chosen:
                marked_read += 1
            else:
                marked_unread += 1
        work = (len(uploads) + len(metadata) + marked_read
                + marked_unread + deletions)
        return {"uploads": len(uploads), "metadata": len(metadata),
                "read": marked_read, "unread": marked_unread,
                "deletions": deletions, "undecided": undecided,
                "work": work}

    def _update_summary(self, *_args):
        0                                                         
        counts = self._selection_counts()
        uploads = counts["uploads"]
        metadata = counts["metadata"]
        marked_read = counts["read"]
        marked_unread = counts["unread"]
        deletions = counts["deletions"]
        changes = marked_read + marked_unread
        summary = self.summary
        if summary is not None:
            summary_text = (
                "Ausgewählt: %d %s · %d Metadaten · %d Lesestatus"
                % (uploads, plural(uploads, "Upload", "Uploads"),
                   metadata, changes))
            if changes:
                summary_text += (
                    " (davon %d gelesen, %d ungelesen)"
                    % (marked_read, marked_unread))
            if deletions:
                summary_text += " · %d %s" % (
                    deletions, plural(deletions, "Löschung", "Löschungen"))
            undecided = counts["undecided"]
            if undecided:
                summary_text += (
                    " · %d %s unklar («Zu prüfen», nicht vorausgewählt)"
                    % (undecided, plural(undecided, "Buch", "Bücher")))
            summary.setText(summary_text)
        confirm = self.confirm
        if confirm is not None:
            total = counts["work"]
            confirm.setText("Synchronisierung starten (%d)" % total
                            if total else "Synchronisierung starten")
            confirm.setEnabled(total > 0 or self.automatic_actions_enabled())



    def _selected_row(self):
        0                                                           

                                                                      
                                                                           
                       
           
        selected = _selected_rows(self.table)
        if not selected:
            QMessageBox.information(
                self, "Buch auswählen",
                "Markiere zuerst das Buch, für das du diese Aktion "
                "ausführen möchtest.")
            return None
        if len(selected) > 1:
            QMessageBox.information(
                self, "Ein Buch auswählen",
                "Diese Aktion gilt nur für ein Buch. Markiere genau ein "
                "Buch in der Tabelle.")
            return None
        row_index = selected[0]
        if row_index >= len(self.rows):
            return None
        return self.rows[row_index]

    def _cached_or_new_client(self):
        0                                                       

                                                                       
                                              
           
        if self._cached_client is not None:
            return self._cached_client
        if self.client_factory is None:
            raise RuntimeError("Keine Anmeldung verfügbar.")
        client = self.client_factory()
        if client is not None:
            self._cached_client = client
        return client

    def _start_action(self, call, on_done, on_failed, text=""):
        0                                                  

                                                                            
                                                                              
           
        if self._call_thread is not None:
            return
        self._set_action_busy(True, text)
        start_call(self, call, on_done, on_failed)

    def _end_action(self):
        self._call_thread = None
        self._set_action_busy(False)

    def _set_action_busy(self, busy, text=""):
        _set_enabled(self, ("table", "confirm"), not busy)
        if busy:
            self.summary.setText(text or "Verbindung zu tolino …")
        else:
            self._update_summary()

    def download_selected(self):
        row = self._selected_row()
        if row is None:
            return
        tolino_id = row.get("tolino_id")
        if not tolino_id:
            QMessageBox.information(
                self, "Buch nicht in tolino vorhanden",
                "Dieses Buch kann nicht aus tolino heruntergeladen werden, "
                "weil es im ausgewählten Konto nicht vorhanden ist.")
            return


        title = str(row.get("title") or "tolino-book")
        title = re.sub(r'[\\/:*?"<>|]', "_", title).strip(" .") or "tolino-book"
        extension = ".epub"
        suggested = title + extension
        path, _ = QFileDialog.getSaveFileName(
            self, "Buch speichern", suggested,
            "EPUB (*.epub);;PDF (*.pdf)")
        if not path:
            return
        self._download_path = path
        self._start_action(
            lambda: self._download_content(tolino_id),
            self._download_finished,
            self._download_failed,
            "Buchdatei wird aus tolino geladen …")

    def _download_content(self, tolino_id):
        0                                                      
        client = self._cached_or_new_client()
        return client.download(tolino_id)

    @gui_guard
    def _download_finished(self, result):
        path = self._download_path
        self._end_action()
        data = bytes(result or b"")
        is_pdf = data[:4] == b"%PDF"
        is_epub = data[:4] == b"PK\x03\x04"
        if path.casefold().endswith(".epub") and is_pdf:
            path = path[:-5] + ".pdf"
        elif path.casefold().endswith(".pdf") and is_epub:
            path = path[:-4] + ".epub"
        if not (is_pdf or is_epub):

            error_dialog(
                self, "Download ungültig",
                "Die Cloud-Antwort ist keine EPUB- oder PDF-Datei. "
                "Gespeichert wurde nichts.", show=True)
            return
        try:
            with open(path, "wb") as handle:
                handle.write(data)
        except OSError as exc:
            message = report_error(exc, "Speichern")
            error_dialog(self, "Speichern fehlgeschlagen",
                         message, show=True)
            return
        info_dialog(self, "Buch gespeichert", "Gespeichert unter: %s" % path,
                    show=True, show_copy_button=False)

    def _action_failed(self, title, summary, exc, context):
        0                                                                         
        self._end_action()
        self._cached_client = None
        error_dialog(self, title,
                     summary + "\n\n" + report_error(exc, context), show=True)

    @gui_guard
    def _download_failed(self, exc):
        self._action_failed(
            "Cloud-Download fehlgeschlagen",
            "Der Download ist fehlgeschlagen. Details stehen im Calibre-Log.",
            exc, "Download")

    def delete_marked_from_cloud(self):
        0                                              

                                                                          
                                                                          
                                     
           
        marked = self._marked_row_indexes()
        if not marked:
            return
        candidates = []
        for index in marked:
            if not 0 <= index < len(self.rows):
                continue
            row = self.rows[index]
            if row.get("delete_cloud") or not row_capabilities(row)["delete"]:
                continue
            candidates.append(row)
        if not candidates:
            QMessageBox.information(
                self, "Nichts zu löschen",
                "Es wurde nichts geändert: Die markierten Bücher liegen nicht "
                "in tolino oder sind bereits zum Löschen markiert.")
            return
        for row in candidates:
            row["delete_cloud"] = True
            row["upload"] = False
            row["metadata"] = False
        self._rebuild_table(self.rows)

    def clear_cloud_delete_for_marked_rows(self):
        0                                                          
        marked = self._marked_row_indexes()
        if not marked:
            return
        changed = 0
        for index in marked:
            if (0 <= index < len(self.rows)
                    and self.rows[index].pop("delete_cloud", None) is not None):
                changed += 1
        if not changed:
            QMessageBox.information(
                self, "Löschmarkierung aufheben",
                "Es wurde nichts geändert: Die markierten Bücher sind nicht "
                "zum Löschen vorgemerkt.")
            return
        self._rebuild_table(self.rows)
