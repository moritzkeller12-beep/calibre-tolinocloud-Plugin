# tolino Cloud Sync für Calibre

Synchronisiert Bücher, Metadaten, Lesestatus und Fortschritt zwischen Calibre und der tolino Cloud.

Aktuelle Version: **0.1.09** (Details im [CHANGELOG](CHANGELOG.md)).

## Installation

1. [Plugin-ZIP für 0.1.09 herunterladen](https://github.com/moritzkeller12-beep/calibre-tolinocloud-Plugin/raw/0.1.09/tolino_cloud_sync.zip).
2. In Calibre: **Einstellungen → Plugins → Plugin aus Datei laden** und die ZIP auswählen.
3. Calibre neu starten.

Voraussetzung: Calibre 6 oder neuer. Die automatische Anmeldung benötigt Chrome, Chromium, Brave oder Edge; verschlüsselte Web-Reader-Tokens zusätzlich PyCryptodome.

## Benutzung

Plugin öffnen und **Bei tolino anmelden**. Ohne Browser lassen sich Zugangstoken und Geräte-ID in den Einstellungen eintragen. Danach **Bibliothek vergleichen …** wählen, gewünschte Aktionen markieren und **Synchronisierung starten**.

Die Calibre-Spalten (`#tolino_id`, `#tolino_read`, `#tolino_progress`, `#tolino_ignore`) sind optional; in **Einstellungen …** legt jeder Knopf nur seine eigene Spalte an – danach Calibre neu starten.

Ohne geöffnetes Calibre erneuert `python3 tools/token_refresh.py` fällige Konten; `--help` nennt die Optionen.

Fehlermeldungen enthalten einen Code; die Abhilfe steht in der [Fehlercodeliste](docs/fehlercodes.md).

## Entwicklung

Tests: `python3 -X dev -m unittest calibre_plugin.test_sync`. Die Qt-Tests benötigen PyQt6, die Token-Tests PyCryptodome; ohne PyQt6 werden die UI-Tests übersprungen. Release-ZIP: `python3 build_plugin.py`.

Lizenz: [GPL-3.0-or-later](LICENSE). Änderungen: [CHANGELOG](CHANGELOG.md).
