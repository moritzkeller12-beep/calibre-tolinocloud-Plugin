0
from qt.core import QDialog, QInputDialog, QMessageBox, QThread, Qt
from .ui_common import (CANCEL_MESSAGE, COMPARE_BUTTON_TEXT, COMPARE_BUTTON_TIP,
                        LOGIN_BUTTON_TEXT, LOGIN_BUTTON_TIP,
                        LOGIN_NEXT_STEP, _active_work_thread, _apply_busy,
                        _dialog_busy, _login_failure_guidance, _stop_thread,
                        gui_guard, start_worker, sync_result_detail,
                        sync_result_text)
from calibre.gui2 import error_dialog, info_dialog
from .token_vault import TOKEN_VAULT
from .config import (PREFERRED_FORMATS, account_by_name, account_summary,
                     load_state, remove_account as remove_saved_account,
                     save_account, save_credentials,
                     set_active_account, settings)
from .run_context import RunContext
from .comparison import (comparison_progress_updates,
                         comparison_read_updates)
from .identifiers import book_uuid, calibre_key
from .library import (TOLINO_IGNORE_COLUMN, column_state, library_scope,
                      bool_column_available, normalize_formats,
                      update_progress_status, update_read_status,
                      update_tolino_ids)

from . import planning as _planning
from .errors import needs_new_login
from .partners import UNKNOWN_SHOP, partner_from_token
from .tolino import (BUSY_MESSAGE, RELOGIN, TolinoError, hardware_id, log_info,
                     log_warning, normalize_hardware_id,
                     normalize_refresh_token, report_error, sanitize_error)
from .ui_auth_workers import BrowserLoginWorker, SessionCheckWorker
from .ui_dashboard_parts import (DashboardParts, confirm_deletions,
                                 confirm_replacements, offer_next_step,
                                 report_skipped_uploads)
from .ui_dialogs import InventoryDialog
from .ui_workers import LocalMetadataWorker, PrepareWorker, SyncWorker



NEEDS_LOGIN_STATUS = "Anmeldung abgelehnt – bitte neu anmelden."


def _window_gone(dialog):
    0










    visible = getattr(dialog, "isVisible", None)
    return visible is not None and not visible()


def _book_key_index(dashboard):
    0





    database = getattr(getattr(dashboard, "gui", None), "current_db", None)
    api = getattr(database, "new_api", None)
    if api is None:
        return [], {}
    book_ids = list(api.all_book_ids())
    uuids = api.all_field_for("uuid", book_ids) or {}
    scope = library_scope(database)
    mapping = {}
    for book_id in book_ids:
        key = book_uuid(uuids.get(book_id))
        if key:
            mapping[key] = book_id
        else:
            mapping.setdefault(calibre_key(book_id, scope), book_id)
    return book_ids, mapping


def _write_reading_updates(dashboard, read_updates, progress_updates,
                           error_label):
    0




    if not (read_updates or progress_updates):
        return 0
    try:
        database = dashboard.gui.current_db
    except Exception as exc:
        log_warning("%s: %s" % (error_label, sanitize_error(exc)))
        return 0
    written = 0
    for write, updates in ((update_read_status, read_updates),
                           (update_progress_status, progress_updates)):
        if not updates:
            continue
        try:
            written += write(database, updates)
        except Exception as exc:
            log_warning("%s: %s" % (error_label, sanitize_error(exc)))
    if written:
        book_ids = {book_id for book_id, _value
                    in read_updates + progress_updates}
        _refresh_library_view(dashboard, book_ids)
    return written


def _mirror_account_reading(dashboard, account_name=None):
    0
    try:
        account = account_by_name(
            account_name or getattr(dashboard, "account_name", "")) or {}
        state = load_state(account.get("state"))
        book_ids, book_ids_by_key = _book_key_index(dashboard)
        if not book_ids:
            return 0


        read_updates = dict.fromkeys(book_ids)
        progress_updates = dict.fromkeys(book_ids)
        for key, entry in state.items():
            if not isinstance(entry, dict):
                continue
            book_id = book_ids_by_key.get(str(key))
            reading = entry.get("reading")
            if book_id is None or not isinstance(reading, dict):
                continue
            if isinstance(reading.get("read"), bool):
                read_updates[book_id] = reading["read"]
            progress = reading.get("progress")
            if isinstance(progress, dict) and "percent" in progress:
                progress_updates[book_id] = progress.get("percent")
        return _write_reading_updates(
            dashboard, list(read_updates.items()),
            list(progress_updates.items()),
            "Lese-Spalten konnten nicht aktualisiert werden")
    except Exception as exc:
        log_warning("Lese-Spalten konnten nicht aktualisiert werden: %s"
                    % sanitize_error(exc))
        return 0


def _mirror_comparison_reading(dashboard, comparison):
    0





    return _write_reading_updates(
        dashboard, comparison_read_updates(comparison),
        comparison_progress_updates(comparison),
        "Lesewerte konnten nicht nach Calibre gespiegelt werden")


def _persist_sync_result(dialog, state, updates):
    0





    worker = getattr(dialog, "worker", None)
    dialog_account = str(getattr(dialog, "account_name", "") or "")
    account_name = str(getattr(worker, "account_name", None) or dialog_account)
    columns = getattr(getattr(worker, "context", None), "columns", {}) or {}
    failures = []
    try:
        if account_name:
            save_account(account_name, {"state": state}, create=False)
    except Exception as exc:
        failures.append("Sync-Zustand")
        log_warning("Ergebnis der Synchronisierung konnte nicht "
                    "gespeichert werden: %s" % sanitize_error(exc))
    writers = [
        ("id", "tolino-IDs",
         lambda db: update_tolino_ids(
             db, updates, account_name=account_name)),
    ]
    if account_name and account_name == dialog_account:
        writers.extend([
            ("read", "Lesestatus",
             lambda db: update_read_status(
                 db, list(getattr(worker, "read_updates", ()) or ()))),
            ("progress", "Lesefortschritt",
             lambda db: update_progress_status(
                 db, list(getattr(worker, "progress_updates", ()) or ()))),
        ])
    for key, label, write in writers:
        if not columns.get(key):
            continue
        try:
            write(dialog.gui.current_db)
        except Exception as exc:
            failures.append(label)
            log_warning("%s: Schreiben in Calibre fehlgeschlagen: %s"
                        % (label, sanitize_error(exc)))
    return failures


def _finish_sync(dialog, state, updates):
    0
    outcome = dict(getattr(dialog.worker, "outcome", None) or {})
    try:
        return outcome, _persist_sync_result(dialog, state, updates)
    finally:


        dialog.finish_thread()


def _refresh_library_view(dashboard, book_ids):
    0
    view = getattr(getattr(dashboard, "gui", None), "library_view", None)
    model = getattr(view, "model", None)
    if callable(model):
        model = model()
    refresh = getattr(model, "refresh_ids", None)
    if callable(refresh):
        try:
            refresh(tuple(book_ids))
        except Exception as exc:
            log_warning("Calibre-Ansicht konnte nicht aktualisiert werden: %s"
                        % sanitize_error(exc))


def _sync_cancelled_text(outcome):
    0
    result = sync_result_text(outcome, "")
    if result:
        return "Abgebrochen. " + result
    return "Abgebrochen. Es wurde nichts übertragen."


def _sync_failure_heading(outcome):
    0





    succeeded = sum(int(outcome.get(key) or 0) for key in (
        "uploaded", "metadata", "read_marked", "read_unmarked",
        "collections", "deleted"))
    if succeeded:
        return "Teilweise fehlgeschlagen", "Teilweise abgeschlossen: "
    return "Fehlgeschlagen", "Fehlgeschlagen: "


class SyncDashboard(DashboardParts, QDialog):
    def __init__(self, gui):
        QDialog.__init__(self, gui)
        self.gui = gui

        self.setAttribute(Qt.WidgetAttribute.WA_QuitOnClose, False)
        self.thread = None
        self.worker = None
        self.login_thread = None
        self.login_worker = None
        self.prepare_thread = None
        self.prepare_worker = None
        self.snapshot_thread = None
        self.snapshot_worker = None
        self.account_name = ""
        self.setWindowTitle("tolino Cloud Sync")
        self.setMinimumWidth(560)
        self._build_ui()
        self._hardware_edited = False
        self.hardware.textEdited.connect(self._mark_hardware_edited)
        self.load_values()

    def _save_visible_account(self, values=None):
        0






        if not self.account_name:
            return
        values = dict(values or self.values())
        name = str(values.get("account_name") or "")
        if not name:

            log_warning("Das sichtbare Konto existiert nicht mehr; "
                        "Änderungen wurden nicht gespeichert.")
            return


        if not self._hardware_edited:
            values.pop("hardware_id", None)
        save_account(name, values, active=name,
                     preferred_formats=values[PREFERRED_FORMATS])
        self._hardware_edited = False

    def _mark_hardware_edited(self, _text=""):
        0
        self._hardware_edited = True

    def _account_selected(self, index, combo):
        0
        if index < 0 or not self.account_names:
            return
        self.switch_account(combo.itemData(index))

    def switch_account(self, name):
        0







        name = str(name or "")
        if not name or name == self.account_name:
            return False
        if name not in self.account_names:
            return False

        login = self.login_thread
        if login is not None and login.isRunning():
            try:
                self.load_values()
            except Exception:
                pass
            return False
        self._save_visible_account()
        set_active_account(name)
        self.load_values()
        return True

    def new_account(self):
        self._save_visible_account()
        base, accepted = QInputDialog.getText(
            self, "Neues Konto", "Name:")
        base = str(base).strip()
        if not accepted or not base:
            return
        names = set(self.account_names)
        name, number = base, 2
        while name in names:
            name = "%s-%d" % (base, number)
            number += 1
        save_account(name, {"name": name}, active=name)
        self.load_values()
        self.account_select.setCurrentIndex(self.account_select.findData(name))

    def remove_account(self):
        if len(self.account_names) <= 1:
            return
        name = self.account_name
        yes = QMessageBox.StandardButton.Yes
        no = QMessageBox.StandardButton.No
        answer = QMessageBox.question(
            self, "Konto entfernen",
            "Konto «%s» entfernen? Anmeldung und Sync-Stand dieses Kontos "
            "werden gelöscht. Bücher in tolino und Calibre bleiben." % name,
            yes | no, no)
        if answer != yes:
            return
        if not remove_saved_account(name):
            return
        self.load_values()

    def load_values(self):
        values = settings()
        self.account_names = [item["name"] for item in values["accounts"]]
        self.account_name = values["active_account"]
        for combo in (self.account_select, self.account_quick):
            combo.blockSignals(True)
            combo.clear()
            for name in self.account_names:
                combo.addItem(name, name)
            combo.setCurrentIndex(max(0, combo.findData(self.account_name)))
            combo.blockSignals(False)

        multiple = len(self.account_names) > 1
        self.account_quick.setVisible(multiple)
        self.account_quick_label.setVisible(multiple)


        self.partner.blockSignals(True)
        self.partner.setCurrentIndex(
            max(0, self.partner.findData(values["partner_id"])))
        self.partner.blockSignals(False)
        self._partner_chosen = False
        self.hardware.setText(values["hardware_id"] or hardware_id())
        self._hardware_edited = False

        self.refresh.setText("")
        self.formats.setText(", ".join(values["preferred_formats"]))
        self.update_status()
        _mirror_account_reading(self, self.account_name)

    def open_settings(self):
        0
        self.settings_dialog.exec()

    def close_settings(self):
        typed = self._typed_refresh()
        self._save_visible_account()
        if typed:


            self.store_refresh(typed)
        self.settings_dialog.accept()

    def primary_action(self):
        0




        if _active_work_thread(self):
            self.cancel_sync()
        else:
            self.start_sync()

    def update_status(self):
        logged_in = bool(self._effective_refresh())
        running = _dialog_busy(self)
        if running:
            _apply_busy(self, True)
            if self.thread is not None:
                running_text = "Synchronisierung läuft …"
            elif self.prepare_thread is not None:
                running_text = "Vergleich läuft …"
            elif self.snapshot_thread is not None:
                running_text = "Bibliothek wird gelesen …"
            else:
                running_text = "Anmeldung wird geprüft …"
            self.status.setText(running_text)
        elif logged_in:
            self.status.setText("Angemeldet.")
        else:
            self.status.setText("Nicht angemeldet.")
        self.progress.setVisible(running)
        self.progress_label.setVisible(running)
        login_button = self.login_button
        if login_button is not None:
            if logged_in:
                login_button.setText("Anmeldung prüfen")
                login_button.setToolTip(
                    "Prüft die gespeicherte Anmeldung. Öffnet den Browser nur bei Bedarf.")
            else:
                login_button.setText(LOGIN_BUTTON_TEXT)
                login_button.setToolTip(LOGIN_BUTTON_TIP)
        if running:
            self.primary.setText("Abbrechen")
            self.primary.setToolTip(
                "Bereits übertragene Änderungen bleiben bestehen.")
            self.primary.setEnabled(True)
        else:
            _apply_busy(self, False)
            self.primary.setText(COMPARE_BUTTON_TEXT)
            self.primary.setEnabled(logged_in)
            self.primary.setToolTip(
                COMPARE_BUTTON_TIP if logged_in
                else "Noch nicht angemeldet. " + RELOGIN)

    def _stored_refresh(self):
        0
        account = self._selected_account() or {}
        return normalize_refresh_token(account.get("refresh_token") or "")

    def _typed_refresh(self):
        0
        refresh = self.refresh
        return normalize_refresh_token(refresh.text()) if refresh is not None else ""

    def _effective_refresh(self):
        0
        return self._typed_refresh() or self._stored_refresh()

    def _partner_selected(self, _index=None):
        0
        self._partner_chosen = True
        partner_id = self.partner.currentData()
        if self.account_name and partner_id:
            save_account(self.account_name, {"partner_id": partner_id})

    def store_refresh(self, refresh):
        0





        token = normalize_refresh_token(refresh)
        if not token or not self.account_name:
            return False
        partner_id = partner_from_token(token) or (
            self.partner.currentData()
            if self._partner_chosen else None)
        if not partner_id:
            error_dialog(self, "Buchhändler nicht erkannt", UNKNOWN_SHOP,
                         show=True)
            return False
        hardware = ""
        if not self._hardware_edited:
            account = account_summary(self.account_name) or {}
            hardware = str(account.get("hardware_id") or "")
        save_credentials(
            self.account_name, token,
            hardware or normalize_hardware_id(self.hardware.text())
            or hardware_id(),
            partner_id)
        self.refresh.setText("")
        self.update_status()
        return True

    def logout(self):
        0
        if not self.account_name:
            return
        save_account(self.account_name, {"refresh_token": ""},
                     active=self.account_name)
        self.refresh.setText("")
        self.update_status()

    def _selected_account(self):
        0
        return account_summary(self.account_name)

    def values(self):
        0









        account = self._selected_account()
        if not isinstance(account, dict):
            account = {}


        hardware = normalize_hardware_id(self.hardware.text()) or hardware_id()
        formats = [fmt for fmt in normalize_formats(self.formats.text())
                   if fmt in ("EPUB", "PDF")]
        return {
            "account_name": str(account.get("name") or ""),
            "hardware_id": hardware,
            "preferred_formats": formats or ["EPUB"],
        }

    def _login_running(self):
        0
        return self.login_thread is not None and self.login_thread.isRunning()

    def browser_login(self):
        0






        if self._login_running():
            return
        typed = self._typed_refresh()
        values = self.values()
        if typed:

            if not self.store_refresh(typed):
                return
            values = self.values()
        context = RunContext.from_values(values)
        if typed or self._stored_refresh():
            self._check_stored_login(context)
            return
        self._start_login_window(context)

    def _check_stored_login(self, context):
        0
        _apply_busy(self, True)
        self.primary.setEnabled(False)
        self.status.setText("Anmeldung wird geprüft …")
        worker = SessionCheckWorker(context)
        worker.valid.connect(self.login_still_valid)
        worker.invalid.connect(self.login_rejected)
        worker.busy.connect(self.login_check_busy)
        start_worker(self, worker, QThread(), "login_thread", "login_worker",
                     (worker.valid, worker.invalid, worker.busy))

    @gui_guard
    def login_still_valid(self):
        0
        self._login_cleanup()
        self.status.setText("Angemeldet.")
        offer_next_step(self)

    @gui_guard
    def login_rejected(self, message=""):
        0




        self._login_cleanup()
        context = RunContext.from_values(self.values())
        log_warning("Anmeldung abgelehnt: " + str(message))
        self.status.setText("Anmeldung abgelaufen – bitte neu anmelden.")
        self._start_login_window(context)

    @gui_guard
    def login_check_busy(self, _reason=""):
        0
        self._login_cleanup()
        self.status.setText(BUSY_MESSAGE)

    def _start_login_window(self, context):
        0
        if self._login_running():
            return
        _apply_busy(self, True)
        self.primary.setEnabled(False)
        self.status.setText(
            "Bitte im Browserfenster anmelden, bis die Bücherliste lädt.")
        worker = BrowserLoginWorker(
            context.account_name, self.hardware.text().strip())
        worker.progress.connect(self._login_progress)
        worker.completed.connect(self.login_completed)
        worker.failed.connect(self.login_failed)
        start_worker(self, worker, QThread(), "login_thread", "login_worker",
                     (worker.completed, worker.failed))

    @gui_guard
    def login_completed(self, hardware):
        0
        self._login_cleanup()
        if hardware:
            self.hardware.setText(str(hardware))
        self.refresh.setText("")
        self.status.setText("Angemeldet.")
        offer_next_step(self)

    @gui_guard
    def login_failed(self, error):
        0
        self._login_cleanup()

        secrets = tuple(token for token in
                        (self._stored_refresh(), self._typed_refresh()) if token)
        detail = report_error(error, "Anmeldefenster", secrets)
        log_warning("Anmeldung nicht abgeschlossen: " + detail)
        code = error.code if isinstance(error, TolinoError) else "E99"
        title = "%s (Code %s)" % (_login_failure_guidance(error), code)
        self.status.setText("Anmeldung fehlgeschlagen.")
        if not _window_gone(self):
            QMessageBox.warning(self, title, LOGIN_NEXT_STEP)

    @gui_guard
    def _login_progress(self, text):
        0
        self.status.setText(str(text))

    @gui_guard
    def _login_cleanup(self):
        self.login_thread = None
        self.login_worker = None
        self.update_status()

    @staticmethod
    def _worker_client(context):
        0
        return TOKEN_VAULT.login(context.account_name)

    def _show_prepare_error(self, exc, context):
        0
        secrets = context.secrets()
        message = report_error(exc, "Vorbereitung", secrets)
        if _window_gone(self):
            return
        error_dialog(self, "Vergleich fehlgeschlagen",
                     message + " Es wurde nichts geändert.", show=True)

    def start_sync(self):
        0





        if _active_work_thread(self):
            return
        values = self.values()
        if not self._effective_refresh():
            self.status.setText("Nicht angemeldet.")
            return
        self._save_visible_account(values)
        database = self.gui.current_db
        context = RunContext.from_values(
            values, column_state(database),
            library_scope=library_scope(database))
        account = account_by_name(context.account_name) or {}
        state = load_state(account.get("state"))
        self._start_local_snapshot(database, context, state)

    def _begin_progress(self, status, label):
        0
        _apply_busy(self, True)
        self.status.setText(status)
        self.progress.setRange(0, 0)
        self.progress.setVisible(True)
        self.progress_label.setVisible(True)
        self.progress_label.setText(label)

    def _start_local_snapshot(self, database, context, state):
        0
        self._begin_progress("Bibliothek wird gelesen …",
                             "Lese Calibre-Bibliothek …")
        worker = LocalMetadataWorker(database, context, state)
        worker.ready.connect(self._snapshot_ready)
        worker.failed.connect(self._snapshot_failed)
        start_worker(self, worker, QThread(self), "snapshot_thread",
                     "snapshot_worker", (worker.ready, worker.failed))
        self.update_status()

    def _finish_progress_thread(self, thread_name, worker_name):
        0
        thread = getattr(self, thread_name, None)
        setattr(self, thread_name, None)
        setattr(self, worker_name, None)
        self.progress.setRange(0, 1)
        self.progress.setVisible(False)
        self.progress_label.setText("Bereit")
        self.progress_label.setVisible(False)
        _stop_thread(thread, timeout_ms=2000)
        self.update_status()

    def _finish_snapshot(self):
        0
        self._finish_progress_thread("snapshot_thread", "snapshot_worker")

    @gui_guard
    def _snapshot_ready(self, payload):
        0
        self._finish_snapshot()
        self._start_prepare_worker(payload["context"], payload["metadata"],
                                   payload["state"])

    def _failed(self, message, worker_name, finish, log_text):
        0
        worker = getattr(self, worker_name, None)
        cancelled = bool(getattr(worker, "cancelled", False))
        finish()
        if _window_gone(self):
            log_warning("Fenster geschlossen; Ergebnis nur im Log: %s"
                        % sanitize_error(message))
            return
        if cancelled or str(message) == CANCEL_MESSAGE:
            info_dialog(
                self, "Abgebrochen", "Abgebrochen. Es wurde nichts geändert.",
                show=True, show_copy_button=False)
            return
        log_warning(log_text + sanitize_error(message))
        error_dialog(self, "Vergleich fehlgeschlagen", str(message), show=True)
        if needs_new_login(message):



            self.status.setText(NEEDS_LOGIN_STATUS)

    @gui_guard
    def _snapshot_failed(self, message):
        self._failed(message, "snapshot_worker", self._finish_snapshot,
                     "Bibliothek konnte nicht gelesen werden: ")

    def _start_prepare_worker(self, context, metadata, state):
        0
        self._begin_progress("Vergleich läuft …",
                             "Verbinde mit tolino …")
        worker = PrepareWorker(context, metadata, state)
        worker.progress.connect(self._prepare_progress)
        worker.ready.connect(self._prepare_ready)
        worker.failed.connect(self._prepare_failed)
        start_worker(self, worker, QThread(self), "prepare_thread",
                     "prepare_worker", (worker.ready, worker.failed))
        self.update_status()

    @gui_guard
    def _prepare_progress(self, text):
        self.progress_label.setText(str(text))

    def _finish_prepare(self):
        0
        self._finish_progress_thread("prepare_thread", "prepare_worker")

    @gui_guard
    def _prepare_failed(self, message):
        self._failed(message, "prepare_worker", self._finish_prepare,
                     "Vergleich fehlgeschlagen: ")

    @gui_guard
    def _prepare_ready(self, payload):
        0
        context = payload["context"]
        account_name = context.account_name
        metadata = payload["metadata"]
        state = payload["state"]
        self._finish_prepare()
        active_name = str(self.account_name or "")
        is_active = active_name == account_name
        if is_active:
            _mirror_account_reading(self, account_name)
            _mirror_comparison_reading(self, payload.get("comparison"))


        hardware = self.hardware
        if payload.get("hardware") and hardware is not None and is_active:
            hardware.setText(str(payload["hardware"]))
        if payload.get("read_status_known") is False:
            log_warning("Lesestatus unbekannt – er bleibt unverändert.")
        if payload.get("progress_status_known") is False:
            log_warning("Lesefortschritt unbekannt – die Spalte bleibt "
                        "unverändert.")
        if not is_active:
            note = ("Vergleich für Konto «%s» abgeschlossen. Angezeigt "
                    "wird «%s»." % (account_name, active_name))
            log_warning(note)
            self.status.setText(note)
            return
        series_map = _planning.series_map_from_metadata(
            _planning.syncable_metadata(metadata))
        try:
            selection = self._confirm_comparison(
                payload["comparison"], context,
                client_factory=lambda: self._worker_client(context),
                automatic=len(_planning.plan_collection_updates(
                    series_map, state)))
            if selection is None:
                return
            preparation = _planning.plan_actions(
                self, context, metadata, state, selection,
                series_map=series_map)
            if preparation["removals"] and not confirm_deletions(
                    self, preparation["removals"],
                    preparation.get("removal_titles")):
                return


            self._start_sync_worker(context, preparation, state)
        except Exception as exc:



            self._show_prepare_error(exc, context)

    def _confirm_comparison(self, comparison, context, client_factory=None,
                            automatic=0):
        0
        dialog = InventoryDialog(
            comparison, self,
            client_factory=(client_factory or
                            (lambda: self._worker_client(context))),
            options={
                "automatic": int(automatic or 0),


                "ignore_column": bool_column_available(
                    getattr(self.gui, "current_db", None),
                    TOLINO_IGNORE_COLUMN),
            })
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return None
        return {
            "uploads": dialog._selected_book_ids("upload"),
            "metadata": dialog._selected_book_ids("metadata"),
            "read_changes": dialog.selected_read_changes(),
            "cloud_deletions": dialog.selected_cloud_deletions(),
        }

    def _start_sync_worker(self, context, preparation, state):
        0
        skipped_uploads = preparation["skipped_uploads"]
        jobs = preparation["jobs"]

        counts = _planning.PlanCounts(preparation, len(jobs))
        total = counts.steps
        replacements = [job for job in jobs
                        if job.old_id]
        if replacements and not confirm_replacements(self, replacements):
            self.status.setText(
                "Abgebrochen. Die Cloud-Kopie bleibt unverändert.")
            return
        if not total and not skipped_uploads:

            info_dialog(self, "Nichts zu tun",
                        _planning.nothing_to_do_text(preparation),
                        show=True, show_copy_button=False)
            return
        if skipped_uploads and report_skipped_uploads(
                self, skipped_uploads, nothing_else=not total):
            return
        plan = counts.text()
        log_info("Sync geplant: %s" % plan)
        _apply_busy(self, True)
        self.progress.setRange(0, total)
        self.progress.setValue(0)
        worker = SyncWorker(context, jobs, preparation["removals"],
                            preparation["meta_updates"],
                            preparation["series_map"],
                            read_changes=preparation.get("read_changes"),
                            titles=preparation.get("titles"),
                            metadata=preparation.get("metadata", {}),
                            state=state)
        worker.progress.connect(self.progress_changed)
        worker.completed.connect(self.sync_completed)
        worker.failed.connect(self.sync_failed)
        start_worker(self, worker, QThread(self), "thread", "worker")
        self.progress.setValue(0)
        self.progress_label.setText(plan)
        self.update_status()

    @gui_guard
    def progress_changed(self, done, total, text):
        self.progress.setRange(0, total or 1)
        self.progress.setValue(done)
        if text:
            self.progress_label.setText(text)
        elif total:
            self.progress_label.setText(
            "Synchronisierung läuft: %d von %d Aktionen abgeschlossen."
            % (done, total))
        else:
            self.progress_label.setText("Synchronisierung läuft …")

    def cancel_sync(self):
        snapshot = self.snapshot_worker
        if snapshot is not None:
            snapshot.cancel()
        prepare = self.prepare_worker
        if prepare is not None:
            prepare.cancel()
        if self.worker:
            self.worker.cancel()
        self.progress_label.setText("Abbruch angefordert …")
        self.primary.setEnabled(False)

    @gui_guard
    def sync_completed(self, state, updates):
        0




        outcome, failures = _finish_sync(self, state, updates)
        if _window_gone(self):
            log_warning("Fenster geschlossen; Lauf beendet: %s"
                        % sync_result_text(outcome, ""))
            if failures:
                log_warning("Nicht gespeichert: %s" % ", ".join(failures))
            return
        if failures:
            error_dialog(self, "Speichern fehlgeschlagen",
                         "Nicht gespeichert: %s. Cloud-Änderungen bleiben "
                         "bestehen; bitte den Bestand prüfen.\n\n%s"
                         % (", ".join(failures), sync_result_text(outcome, "")),
                         show=True)
            return
        if outcome.get("cancelled"):
            info_dialog(self, "Abgebrochen", _sync_cancelled_text(outcome),
                        show=True, show_copy_button=False)
            return
        if outcome.get("failed"):
            title, prefix = _sync_failure_heading(outcome)
            error_dialog(self, title, prefix + sync_result_text(outcome, ""),
                         det_msg=sync_result_detail(outcome), show=True)
            return
        info_dialog(self, "Fertig",
                    sync_result_text(outcome, "Fertig"), show=True,
                    show_copy_button=False)

    @gui_guard
    def sync_failed(self, message):
        worker = self.worker
        cancelled = bool(getattr(worker, "cancelled", False)) or \
            str(message) == CANCEL_MESSAGE


        outcome, failures = _finish_sync(
            self, getattr(worker, "state", {}),
            getattr(worker, "updates", ()))
        if _window_gone(self):
            log_warning("Fenster geschlossen; Sync beendet: %s"
                        % sync_result_text(outcome, ""))
            if failures:
                log_warning("Nicht gespeichert: %s" % ", ".join(failures))
            return
        if cancelled and not failures:
            info_dialog(self, "Abgebrochen", _sync_cancelled_text(outcome),
                        show=True, show_copy_button=False)
            return
        result = sync_result_text(outcome, "")
        text = str(message or "Synchronisierung fehlgeschlagen.")
        if failures:
            text += ("\n\nNicht gespeichert: %s. Cloud-Änderungen bleiben "
                     "bestehen; bitte den Bestand prüfen." % ", ".join(failures))
        if outcome.get("failed") and result:
            text += "\n\n" + result

        error_dialog(
            self, _sync_failure_heading(outcome)[0], text,
            det_msg=sync_result_detail(outcome), show=True)

    def finish_thread(self):
        thread = self.thread
        self.thread = None
        self.worker = None
        if thread is not None:
            _stop_thread(thread)
        self.progress_label.setText("Bereit")
        self.update_status()

    def closeEvent(self, event):
        0
        if _active_work_thread(self):
            self.cancel_sync()
        for thread_name, worker_name in (
                ("thread", "worker"),
                ("prepare_thread", "prepare_worker"),
                ("snapshot_thread", "snapshot_worker")):
            _stop_thread(getattr(self, thread_name, None))
            setattr(self, thread_name, None)
            setattr(self, worker_name, None)



        self.login_thread = None
        self.login_worker = None
        self._save_visible_account()
        event.accept()
