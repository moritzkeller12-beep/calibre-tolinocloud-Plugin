0                                  
import copy
import re

_UUID_TEXT = re.compile(
    r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")


_SCOPED_CALIBRE_KEY = re.compile(r"calibre-[0-9a-f]{12}-\d+")
_LEGACY_CALIBRE_KEY = re.compile(r"calibre-\d+")

LEGACY_MIGRATION_KEY = "__legacy_calibre_migration__"

_UUID_PLACEHOLDERS = frozenset(("none", "null", "undefined", "dummy"))
def normalize_uuid_text(value):
    0                                                                        
    return str(value or "").strip().casefold()


def valid_book_uuid(value):
    0                                                                      
    text = normalize_uuid_text(value)
    if not text or text in _UUID_PLACEHOLDERS:
        return ""
    if len(text) > 128 or any(character.isspace() for character in text):
        return ""
    if _UUID_TEXT.fullmatch(text) or _SCOPED_CALIBRE_KEY.fullmatch(text):
        return text
    return ""


def _scope_text(scope):
    return str(scope or "").strip().casefold()


def _book_number(book_id):
    return str(book_id if book_id is not None else "").strip()


def calibre_key(book_id, library_scope=""):
    0                                                                  
    number = _book_number(book_id)
    scope = _scope_text(library_scope)
    if not number or not scope:
        return ""
    return "calibre-%s-%s" % (scope, number)


def legacy_calibre_key(book_id):
    0                                                        
    number = _book_number(book_id)
    return "calibre-%s" % number if number else ""


def _legacy_marker(state):
    marker = state.get(LEGACY_MIGRATION_KEY) if isinstance(state, dict) else None
    return marker if isinstance(marker, dict) else {}


def is_legacy_calibre_key(value):
    0                                                             
    return bool(_LEGACY_CALIBRE_KEY.fullmatch(normalize_uuid_text(value)))


def legacy_calibre_keys(state):
    0                                                     
    if not isinstance(state, dict):
        return []
    return [key for key, value in state.items()
            if isinstance(value, dict) and is_legacy_calibre_key(key)]


def needs_legacy_migration(state, library_scope):
    0                                                                  
    scope = _scope_text(library_scope)
    if not scope or not legacy_calibre_keys(state):
        return False
    marker = _legacy_marker(state)
    marked_scope = _scope_text(marker.get("scope"))
    if marked_scope == scope:
        return False
    if marked_scope and not marker.get("declined"):
        return False
    return True


def decline_legacy_migration(state, library_scope):
    0                                                                     
    scope = _scope_text(library_scope)
    if (not scope or not isinstance(state, dict)
            or not legacy_calibre_keys(state)):
        return False
    marker = _legacy_marker(state)
    marked_scope = _scope_text(marker.get("scope"))
    if marked_scope and marked_scope != scope and not marker.get("declined"):
        return False
    state[LEGACY_MIGRATION_KEY] = {
        "scope": scope, "declined": True, "ids": [],
    }
    return True


def migrate_legacy_calibre_keys(state, metadata, library_scope="",
                                allow_legacy=True):
    0                                                                       

                                                                        
                                                                        
                                                                         
                                                                           
                                                                            
                                                                         
                                                                      
       
    scope = _scope_text(library_scope)
    if (not allow_legacy or not scope or not isinstance(state, dict)
            or not isinstance(metadata, dict)
            or not legacy_calibre_keys(state)):
        return False
    marker = _legacy_marker(state)
    marked_scope = _scope_text(marker.get("scope"))
    if marked_scope and marked_scope != scope and not marker.get("declined"):
        return False
    if marked_scope == scope and marker.get("declined"):
        return False
    claimed = ({str(value) for value in (marker.get("ids") or ())}
               if marked_scope == scope else set())
    changed = False
    for book_id, item in metadata.items():
        if not isinstance(item, dict):
            continue
        key = valid_book_uuid(item.get("uuid"))
        legacy = legacy_calibre_key(book_id)
        if not key or not key.startswith("calibre-") or key == legacy:
            continue
        if str(book_id) in claimed:
            continue
        old = state.get(legacy)
        if not isinstance(old, dict):
            continue
        recorded = old.get("calibre_id")
        if recorded is not None and str(recorded) != str(book_id):
            continue
        if key not in state:
            state[key] = copy.deepcopy(old)
        claimed.add(str(book_id))
        changed = True
    state[LEGACY_MIGRATION_KEY] = {
        "scope": scope, "declined": False,
        "ids": sorted(claimed),
    }
    return changed


def is_real_uuid(value):
    0                                                                      
    return bool(_UUID_TEXT.fullmatch(normalize_uuid_text(value)))


def display_title(title, number=None):
    0                                                                        
    text = str(title or "").strip()
    if text:
        return text
    value = str(number if number is not None else "").strip()
    if value.isdigit():
        return "Buch %s" % value
    return "Buch ohne Titel"


def book_uuid(item):
    0                                                              
    raw = (item.get("uuid") if isinstance(item, dict)
           else getattr(item, "uuid", None))
    value = normalize_uuid_text(raw)
    return value if value and is_real_uuid(value) else ""


def state_entry(state, key):
    0                                                                 
    entry = state.get(key) if key and isinstance(state, dict) else None
    return entry if isinstance(entry, dict) else {}
