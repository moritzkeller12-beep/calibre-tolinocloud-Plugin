0                                                               
import re

_UUID_TEXT = re.compile(
    r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")

_UUID_PLACEHOLDERS = frozenset(("none", "null", "undefined", "dummy"))
def normalize_uuid_text(value):
    0                                                                        
    return str(value or "").strip().casefold()


def valid_book_uuid(value):
    0                                                                        
    text = normalize_uuid_text(value)
    if not text or text in _UUID_PLACEHOLDERS:
        return ""
    if len(text) > 128 or any(character.isspace() for character in text):
        return ""
    return text


def is_real_uuid(value):
    0                                                                      
    return bool(_UUID_TEXT.fullmatch(normalize_uuid_text(value)))


def display_title(title, number=None):
    0                                                                        
    text = str(title or "").strip()
    if text:
        return text
    value = str(number if number is not None else "").strip()
    if value.isdigit():
        return "Buch %s" % value
    return "Buch ohne Titel"


def book_uuid(item):
    0                                                              
    raw = (item.get("uuid") if isinstance(item, dict)
           else getattr(item, "uuid", None))
    value = normalize_uuid_text(raw)
    return value if value and is_real_uuid(value) else ""


def migrate_state_keys(metadata_by_id, state):
    0                                                                          
    if not isinstance(metadata_by_id, dict) or not isinstance(state, dict):
        return 0

    keys = state_keys_by_book_id(state)
    migrated = 0
    for book_id, metadata in metadata_by_id.items():
        if not isinstance(metadata, dict):
            continue
        key = valid_book_uuid(metadata.get("uuid"))
        if not key or key in state:
            continue
        try:
            old_key = keys.get(int(book_id), "")
        except (TypeError, ValueError):
            continue
        if not old_key or old_key == key or old_key not in state:
            continue
        entry = state.pop(old_key)
        if isinstance(entry, dict):
            entry["calibre_id"] = book_id
        state[key] = entry
        migrated += 1
    return migrated


def state_entry(state, key):
    0                                                                 
    entry = state.get(key) if key and isinstance(state, dict) else None
    return entry if isinstance(entry, dict) else {}


def state_keys_by_book_id(state):
    0                                                                     

                                                    
       
    keys = {}
    if not isinstance(state, dict):
        return keys
    for key, entry in state.items():
        if not isinstance(entry, dict):
            continue
        recorded = entry.get("calibre_id")
        try:
            keys[int(recorded)] = str(key)
        except (TypeError, ValueError):
            continue
    return keys
