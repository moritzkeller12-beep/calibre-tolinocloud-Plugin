0                                  
import re

_UUID_TEXT = re.compile(
    r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")

_SCOPED_CALIBRE_KEY = re.compile(r"calibre-[0-9a-f]{12}-\d+")

_UUID_PLACEHOLDERS = frozenset(("none", "null", "undefined", "dummy"))
def normalize_uuid_text(value):
    0                                                                        
    return str(value or "").strip().casefold()


def valid_book_uuid(value):
    0                                                                      
    text = normalize_uuid_text(value)
    if not text or text in _UUID_PLACEHOLDERS:
        return ""
    if len(text) > 128 or any(character.isspace() for character in text):
        return ""
    if _UUID_TEXT.fullmatch(text) or _SCOPED_CALIBRE_KEY.fullmatch(text):
        return text
    return ""


def _scope_text(scope):
    return str(scope or "").strip().casefold()


def _book_number(book_id):
    return str(book_id if book_id is not None else "").strip()


def calibre_key(book_id, library_scope=""):
    0                                                                  
    number = _book_number(book_id)
    scope = _scope_text(library_scope)
    if not number or not scope:
        return ""
    return "calibre-%s-%s" % (scope, number)


def is_real_uuid(value):
    0                                                                      
    return bool(_UUID_TEXT.fullmatch(normalize_uuid_text(value)))


def display_title(title, number=None):
    0                                                                        
    text = str(title or "").strip()
    if text:
        return text
    value = str(number if number is not None else "").strip()
    if value.isdigit():
        return "Buch %s" % value
    return "Buch ohne Titel"


def book_uuid(item):
    0                                                              
    raw = (item.get("uuid") if isinstance(item, dict)
           else getattr(item, "uuid", None))
    value = normalize_uuid_text(raw)
    return value if value and is_real_uuid(value) else ""


def state_entry(state, key):
    0                                                                 
    entry = state.get(key) if key and isinstance(state, dict) else None
    return entry if isinstance(entry, dict) else {}


def adopt_column_tolino_ids(metadata_by_id, state):
    0                                                             

                                                                           
                                                                         
                                                                             
                                               
       
    if not isinstance(metadata_by_id, dict) or not isinstance(state, dict):
        return False
    changed = False
    for book_id, item in metadata_by_id.items():
        if not isinstance(item, dict):
            continue
        key = valid_book_uuid(item.get("uuid"))
        column_id = str(item.get("tolino_id") or "").strip()
        if not key or not column_id or key in state:
            continue
        state[key] = {"tolino_id": column_id, "calibre_id": book_id}
        changed = True
    return changed
