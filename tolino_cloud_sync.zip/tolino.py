import base64
import json
import mimetypes
import os
import re
import sys
import threading
import time
import traceback
import uuid
from urllib.error import HTTPError
from urllib.parse import urlencode, quote as _url_quote, urlsplit
from urllib.request import Request, urlopen

from .errors import TolinoApiError, TolinoAuthError, TolinoError
from .inventory import parse_inventory
from .partners import (PARTNERS, WEBREADER_CLIENT_TYPE,
                       WEBREADER_CLIENT_VERSION, WEBREADER_TOKEN_HEADERS)
from . import sync_data as _sync_data

CHROME_MAJOR = "153"

_FIXED_MIME_TYPES = {".epub": "application/epub+zip",
                     ".pdf": "application/pdf"}
_BROWSER_PLATFORM = {
    "win32": ("Windows NT 10.0; Win64; x64", '"Windows"'),
    "darwin": ("Macintosh; Intel Mac OS X 10_15_7", '"macOS"'),
}.get(sys.platform, ("X11; Linux x86_64", '"Linux"'))
BROWSER_USER_AGENT = (
    "Mozilla/5.0 (%s) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/%s.0.0.0 Safari/537.36"
    % (_BROWSER_PLATFORM[0], CHROME_MAJOR)
)


def _browser_sec_headers():
    0                                                          
    return {
        "Accept": "*/*",
        "Accept-Language": "de-DE,de;q=0.8",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
        "Priority": "u=1, i",
        "Sec-CH-UA": '"Chromium";v="%s", "Not_A Brand";v="8"' % CHROME_MAJOR,
        "Sec-CH-UA-Mobile": "?0",
        "Sec-CH-UA-Platform": _BROWSER_PLATFORM[1],
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "cross-site",
        "Sec-GPC": "1",
    }


RELOGIN = "Bitte bei tolino anmelden."

BUSY_MESSAGE = "Die Anmeldung wird gerade erneuert, bitte kurz warten."
RELOGIN_THEN = "Danach bei tolino anmelden."
def _trace_text(exc):
    0                                                                      

                                                                           
                                                                           
                             
       
    if (exc.__traceback__ is None and exc.__cause__ is None
            and exc.__context__ is None):
        return ""
    return "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))


def report_error(exc, context="", secrets=()):
    0                                                                         

                                                                         
                                                                            
                         
       
    if isinstance(exc, TolinoError):
        code, shown = exc.code, exc.short or str(exc)
        detail = " | ".join(x for x in (str(exc) if exc.short else "",
                                        exc.detail) if x)
    else:
        code = "E99"
        shown = "Unerwarteter Fehler: %s" % str(exc)[:150]
        detail = type(exc).__name__
    shown = sanitize_error(shown, secrets)
    line = "[%s] %s" % (code, shown)
    if detail:
        line += " | " + sanitize_error(detail, secrets)
    if context:
        line += " (%s)" % context
    log_warning("tolino-Fehler " + line)
    trace = _trace_text(exc)
    if trace:
        log_warning("Tolino-Details " + sanitize_error(trace, secrets))
    return "%s (Code %s)" % (shown, code)


def _log(message, method):
    0                                                          

                                                                           
                                                                          
                                     
       
    try:
        from calibre.utils.logging import default_log
        getattr(default_log, method)(str(message))
    except Exception:
        pass


def log_info(message):
    0                                                                    
    _log(message, "info")


def log_warning(message):
    0                            
    _log(message, "warn")


BASE_URL = "https://bosh.pageplace.de/bosh/rest"


def _download_token(deliverable_id):
    0                                                           

                                                                         
                                                                       
                                                             
       
    raw = str(deliverable_id).encode("utf-8")
    return _url_quote(base64.b64encode(raw).decode("ascii"), safe="")

_REGISTER_SETTLE_SECONDS = 1.5

_WAF_RETRY_SECONDS = (2.0, 5.0)
_BOT_CHECK_MARKERS = (
    "zugriff geblockt", "access denied", "captcha", "cloudfront",
    "request blocked", "<!doctype html",
)


def _raise_transport_error(exc, secrets):
    0                                                                
    if (isinstance(exc, TimeoutError)
            or isinstance(getattr(exc, "reason", None), TimeoutError)):
        raise TolinoApiError(
            "Zeitüberschreitung bei der Verbindung zu tolino.", code="N01",
            short="Zeitüberschreitung bei der Verbindung.") from exc
    raise TolinoApiError(
        "Übertragung an tolino fehlgeschlagen: %s"
        % sanitize_error(exc, secrets), code="N01",
        short="Die Verbindung zu tolino ist fehlgeschlagen.") from exc


_JWT_PATTERN = re.compile(
    r"\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*"
)
_BEARER_PATTERN = re.compile(
    r"(?i)\bBearer\s+[A-Za-z0-9._~+/=-]+"
)


_CREDENTIAL_ASSIGNMENT = re.compile(
    r"(?i)\b(access[_-]?token|refresh[_-]?token|authorization|"
    r"t_auth_token|password|secret)\b\s*[:=]\s*"
    r"(?:Bearer\s+)?(?:\"[^\"]*\"|'[^']*'|[^,\s;}&]+)"
)


def sanitize_error(value, secrets=()):
    0                                                                        
    text = str(value)
    candidates = set()
    for secret in secrets:
        if secret is None:
            continue
        raw = str(secret)
        trimmed = raw.strip()
        if trimmed:
            candidates.update((raw, trimmed, '"' + trimmed + '"', "'" + trimmed + "'"))
            if len(trimmed) >= 2 and trimmed[0] == trimmed[-1] and trimmed[0] in "\"'":
                normalized = trimmed[1:-1].strip()
                candidates.update((normalized, '"' + normalized + '"',
                                   "'" + normalized + "'"))
    for secret in sorted(candidates, key=len, reverse=True):
        text = text.replace(secret, "[REDACTED]")
    text = _CREDENTIAL_ASSIGNMENT.sub(
        lambda match: "%s=[REDACTED]" % match.group(1), text
    )
    text = _BEARER_PATTERN.sub("Bearer [REDACTED]", text)
    return _JWT_PATTERN.sub("[REDACTED]", text)


def normalize_refresh_token(value):
    0                                                                      
    text = "" if value is None else str(value).strip()
    if len(text) >= 2 and text[0] == text[-1] and text[0] in "\"'":
        text = text[1:-1].strip()
    return text


def hardware_id():
    0                                                               
    return str(uuid.uuid4())


def normalize_hardware_id(value):
    0                                                                    
    text = str(value or "").strip()
    if not text:
        return ""
    compact = text.replace("-", "")
    if re.fullmatch(r"[0-9a-fA-F]{32}", compact):
        return str(uuid.UUID(hex=compact))
    return text


def _decode_json(raw):
    0                                                               
    if not raw:
        return {}
    try:
        return json.loads(raw.decode("utf-8"))
    except ValueError:
        raise TolinoApiError(
            "Ungültige Antwort von tolino (kein JSON).", code="N02",
            short="tolino hat eine ungültige Antwort geliefert.")


def _http_error_detail(raw_detail):
    0                                                                    
    detail = raw_detail
    try:
        payload = json.loads(raw_detail)
    except ValueError:
        payload = None
    if isinstance(payload, dict):
        detail = {key: payload[key] for key in
                  ("error", "error_description", "message")
                  if key in payload}
        response_info = payload.get("ResponseInfo")
        if isinstance(response_info, dict) and response_info.get("message"):
            detail.setdefault("message",
                              str(response_info["message"])[:300])
        detail = json.dumps(detail, ensure_ascii=False, sort_keys=True)
    return detail


class TolinoClient:
    0                                                                      

    def __init__(self, partner_id, hardware, refresh=None, timeout=45,
                 token_callback=None, hardware_callback=None,
                 token_rejected_callback=None):
        try:
            partner_id = int(partner_id)
        except (TypeError, ValueError):
            raise TolinoError("Unbekannter tolino-Partner: %s" % partner_id)
        if partner_id not in PARTNERS:
            raise TolinoError("Unbekannter tolino-Partner: %s" % partner_id)
        self.partner_id = partner_id
        self.partner = PARTNERS[self.partner_id]
        self.hardware = normalize_hardware_id(hardware) or hardware_id()
        self.refresh = normalize_refresh_token(refresh)
        self.timeout = timeout
        self.access = None
        self.expires_at = 0
        self.last_error_text = None
        self.token_callback = token_callback
        self.hardware_callback = hardware_callback
        self.token_rejected_callback = token_rejected_callback
        self.token_vault = None
        self._in_device_recovery = False
        self._hw_registered_now = False
        self._login_lock = threading.Lock()


        self._sync_cache = None

    def login(self):

        if self.access and time.time() < self.expires_at:
            return self.refresh
        with self._login_lock:
            if self.access and time.time() < self.expires_at:
                return self.refresh
            if self.token_vault is None:
                return self._login()


            return self.token_vault.relogin(self)

    def _apply_token_response(self, data):
        0                                                                   
        if not data.get("access_token"):
            raise TolinoAuthError("Ungültige Anmelde-Antwort.", code="A01", detail="kein access_token")
        previous_refresh = self.refresh
        self.access = data["access_token"]
        new_refresh = data.get("refresh_token", self.refresh)

        self.refresh = new_refresh
        if new_refresh != previous_refresh and self.token_callback:
            try:
                self.token_callback(self.refresh)
            except Exception as exc:
                detail = sanitize_error(exc, (previous_refresh, new_refresh, self.access))
                self.access = None
                raise TolinoAuthError(
                    "Der erneuerte Zugang konnte nicht gespeichert werden. " + RELOGIN,
                    code="A01", detail=detail) from None

        self.expires_at = time.time() + max(0, int(data.get("expires_in", 3600)) - 60)
        return self.refresh

    def _login(self):
        if not self.refresh:
            raise TolinoAuthError("Noch nicht angemeldet. " + RELOGIN, code="A01")
        payload = {
            "client_id": self.partner["client_id"],
            "grant_type": "refresh_token",
            "refresh_token": self.refresh,
            "scope": self.partner["scope"],
        }
        try:
            data = self._request(self.partner["token_url"], "POST", payload,
                                 form=True, authenticated=False)
        except (TolinoApiError, TolinoAuthError) as exc:
            detail = str(exc)
            folded = detail.casefold()
            session_ended = "not active" in folded
            token_rejected = ("invalid_grant" in folded
                              or "reuse exceeded" in folded)
            if session_ended or token_rejected:

                self.refresh = self.access = None
                self.expires_at = 0
                self._notify_token_rejected()
            if session_ended:
                raise TolinoAuthError(
                    "Die tolino-Sitzung ist beendet. " + RELOGIN,
                    code="A01", detail=detail) from exc
            if token_rejected:
                raise TolinoAuthError(
                    "tolino hat die gespeicherte Anmeldung abgelehnt. " + RELOGIN,
                    code="A01", detail=detail) from exc
            raise TolinoAuthError(
                "Anmeldung bei tolino fehlgeschlagen: %s" % exc, code="A01",
                short="Die Anmeldung bei tolino ist fehlgeschlagen.")

        return self._apply_token_response(data)

    def _notify_token_rejected(self):
        0                                                         
        callback = self.token_rejected_callback
        if callback:
            try:
                callback()
            except Exception as exc:
                log_warning("Abgelehnter Token konnte nicht geloescht "
                            "werden: %s" % sanitize_error(exc))

    def _request(self, url, method="GET", data=None, form=False,
                 authenticated=True, content_type=None, _extra_headers=None):
        retry = {"auth": True, "hardware": True, "waf": 0}
        while True:
            if authenticated and (not self.access
                                  or time.time() >= self.expires_at):
                self.login()
            request = self._build_request(url, method, data, form,
                                          authenticated, content_type,
                                          _extra_headers)
            try:
                with urlopen(request, timeout=self.timeout) as response:
                    self.last_error_text = None
                    raw = response.read()
            except HTTPError as exc:

                self._handle_http_error(exc,
                                        exc.read().decode("utf-8", "replace"),
                                        url, authenticated, retry)
                continue
            except OSError as exc:
                _raise_transport_error(exc, (self.refresh, self.access))
            return _decode_json(raw)

    def _build_request(self, url, method, data, form, authenticated,
                       content_type, extra_headers):
        0                                                                  
        headers = {"User-Agent": BROWSER_USER_AGENT}
        if authenticated:
            headers.update({
                "t_auth_token": self.access,
                "hardware_id": self.hardware,
                "reseller_id": self.partner["reseller_id"],
                "client_type": WEBREADER_CLIENT_TYPE,
                "client_version": WEBREADER_CLIENT_VERSION,
            })
        elif url == self.partner.get("token_url"):
            headers.update(_browser_sec_headers())
            headers.update(WEBREADER_TOKEN_HEADERS)
        if extra_headers:
            headers.update(extra_headers)

        body = None
        if data is not None:
            if form:
                body = urlencode(data).encode("utf-8")
                headers["Content-Type"] = "application/x-www-form-urlencoded"
            elif isinstance(data, bytes):
                body = data
                headers["Content-Type"] = (content_type
                                           or "application/octet-stream")
            else:
                body = json.dumps(data).encode("utf-8")
                headers["Content-Type"] = content_type or "application/json"
        return Request(url, data=body, headers=headers, method=method)

    def _handle_http_error(self, exc, raw_detail, url, authenticated, retry):
        0                                                                 

                                                                
                                                                 
           
        self.last_error_text = sanitize_error(
            _http_error_detail(raw_detail),
            (self.refresh, self.access))[:500]

        if (exc.code == 401 and authenticated and self.refresh
                and retry["auth"]
                and "invalid_grant" not in self.last_error_text.casefold()
                and "reuse exceeded" not in self.last_error_text.casefold()):
            retry["auth"] = False
            self.access = None
            self.login()
            return

        if (exc.code == 400 and authenticated
                and url != self.partner.get("token_url")):
            if retry["hardware"]:
                self._hw_registered_now = False
                if self._recover_device_registration():
                    retry["hardware"] = False
                    if self._hw_registered_now:
                        time.sleep(_REGISTER_SETTLE_SECONDS)
                    return
            elif self._hw_registered_now:
                self._hw_registered_now = False
                time.sleep(_REGISTER_SETTLE_SECONDS)
                return




        if exc.code == 403 and url != self.partner.get("token_url"):
            raise TolinoApiError(
                "tolino-Fehler (HTTP 403): %s" % self.last_error_text,
                code="N03",
                short="tolino meldet einen Fehler (HTTP 403).")

        if exc.code in (401, 403):
            if (exc.code == 403
                    and url == self.partner.get("token_url")
                    and retry["waf"] < len(_WAF_RETRY_SECONDS)
                    and any(marker in self.last_error_text.casefold()
                            for marker in _BOT_CHECK_MARKERS)):
                time.sleep(_WAF_RETRY_SECONDS[retry["waf"]])
                retry["waf"] += 1
                return

            self.access = None

            message = re.sub(
                r"\s+", " ", re.sub(
                    r"<[^>]+>", " ", self.last_error_text or "")).strip()
            message = message or "no response detail"
            raise TolinoAuthError(
                "tolino hat die Anmeldung abgelehnt (%s): %s"
                % (exc.code, message), code="A01",
                short="tolino hat die Anmeldung abgelehnt.")
        raise TolinoApiError(
            "tolino-Fehler (HTTP %s): %s"
            % (exc.code, self.last_error_text), code="N03",
            short="tolino meldet einen Fehler (HTTP %s)." % exc.code)


    def inventory(self):
        0                                                         

                                                                           
                                                                            
           
        records, problems, ok = parse_inventory(
            self._request(BASE_URL + "/inventory/delta?strip=true"))
        if problems:
            log_warning("Tolino-Inventar: %s" % "; ".join(problems))
        if not ok:
            raise TolinoApiError(
                "Die Cloud-Antwort enthält kein PublicationInventory.",
                code="N02")
        return records

    @staticmethod
    def _multipart(fields, payload, filename, field="file"):
        0                                             

                                                                           
                                                                           
                                                                    
                                                   
           
        boundary = ("----CalibreTolino%s" % uuid.uuid4().hex).encode("ascii")
        chunks = []
        for key, value in fields.items():
            chunks.extend([b"--" + boundary + b"\r\n",
                           ("Content-Disposition: form-data; name=\"%s\"\r\n\r\n" % key).encode(),
                           str(value).encode(), b"\r\n"])
        name = os.path.basename(str(filename)).replace("\\", "_")
        name = re.sub(r'["\r\n]', "_", name)
        suffix = os.path.splitext(name)[1].casefold()
        guessed_type = mimetypes.guess_type(name)
        mime = (_FIXED_MIME_TYPES.get(suffix)
                or next(iter(guessed_type), None)
                or "application/octet-stream")
        chunks.extend([b"--" + boundary + b"\r\n",
                       ('Content-Disposition: form-data; name="%s"; filename="%s"\r\n' % (field, name)).encode(),
                       ("Content-Type: %s\r\n\r\n" % mime).encode(),
                       payload, b"\r\n",
                       b"--" + boundary + b"--\r\n"])
        return b"".join(chunks), "multipart/form-data; boundary=%s" % boundary.decode()

    def upload(self, file_path):
        with open(file_path, "rb") as source:
            payload = source.read()
        body, content_type = self._multipart({}, payload, file_path)
        data = self._request(BASE_URL + "/upload", "POST", body,
                             content_type=content_type)
        deliverable = (data.get("metadata") or {}).get("deliverableId")
        if not deliverable:
            raise TolinoApiError("Upload ohne deliverableId in der Antwort.", code="N02", short="tolino hat den Upload nicht bestätigt.")
        return str(deliverable)

    def upload_cover(self, deliverable_id, data, suffix=".jpg"):
        body, content_type = self._multipart(
            {"deliverableId": deliverable_id}, data,
            "cover" + str(suffix or ""))
        self._request(BASE_URL + "/cover", "POST", body,
                      content_type=content_type)

    def delete(self, deliverable_id):
        self._request(BASE_URL + "/deletecontent?deliverableId="
                      + _url_quote(str(deliverable_id)))

    META_URL = BASE_URL + "/meta"

    def update_metadata(self, deliverable_id, fields):
        0                                                        
                              

                                                                        
                                                                         
           
        if not isinstance(fields, dict) or not fields:
            raise TolinoApiError("Metadaten-Update ohne Felder.", code="E99", short="Es gibt nichts zu aktualisieren.")
        url = self.META_URL + "/?deliverableId=" + _url_quote(str(deliverable_id))
        book = self._request(url)
        metadata = book.get("metadata") if isinstance(book, dict) else None
        if not isinstance(metadata, dict):
            raise TolinoApiError(
                "Tolino hat keine Metadaten zu %s geliefert." % deliverable_id,
                code="N02", short="tolino hat keine Daten zu diesem Buch geliefert.")
        metadata.update(fields)
        self._request(url, "PUT", {"uploadMetaData": metadata},
                      content_type="application/json")



        verified = self._request(url)
        verified_metadata = (verified.get("metadata")
                             if isinstance(verified, dict) else None)
        if not isinstance(verified_metadata, dict) or any(
                verified_metadata.get(key) != value
                for key, value in fields.items()):
            raise TolinoApiError(
                "tolino hat das Metadaten-Update nicht bestaetigt.",
                code="N02",
                short="tolino hat die Metadaten nicht übernommen.")
        return verified_metadata


    DEVICES_URL = "https://bosh.pageplace.de/bosh/rest/handshake/devices/list"

    def fetch_hardware_id(self):
        0                                                                         
        payload = {
            "deviceListRequest": {
                "accounts": [{
                    "auth_token": self.access,
                    "reseller_id": self.partner["reseller_id"],
                }],
            },
        }
        data = self._request(self.DEVICES_URL, "POST", payload,
                             content_type="application/json")
        devices = (data.get("deviceListResponse") or {}).get("devices") or []
        devices = [item for item in devices if isinstance(item, dict)]
        if not devices:
            raise TolinoApiError("Geräteliste leer.", code="N02", short="tolino meldet kein registriertes Gerät.")
        devices.sort(key=lambda item: str(item.get("deviceLastUsage", "")))
        hardware = devices[-1].get("deviceId")
        if not hardware:
            raise TolinoApiError("Gerät ohne deviceId.", code="N02", short="Die Geräteliste von tolino ist unvollständig.")
        return str(hardware)

    def _notify_hardware(self):
        0                                                           
        callback = getattr(self, "hardware_callback", None)
        if callback:
            try:
                callback(self.hardware)
            except Exception as exc:
                log_warning("Geräte-ID konnte nicht gespeichert werden: %s"
                            % sanitize_error(exc, (self.refresh, self.access)))

    def _register_hardware(self):
        0                                                                   
        payload = {"hardware_name": "other"}
        extra = {
            "hardware_type": "HTML5",
            "client_type": WEBREADER_CLIENT_TYPE,
            "client_version": WEBREADER_CLIENT_VERSION,
        }
        for url in (BASE_URL + "/v2/registerhw", BASE_URL + "/registerhw"):
            try:
                self._request(url, "POST", payload,
                              content_type="application/json",
                              _extra_headers=extra)
                return True
            except TolinoError:
                continue
        return False

    def _recover_device_registration(self):
        0                                                             
        if self._in_device_recovery:
            return False
        self._in_device_recovery = True
        try:
            try:
                registered = normalize_hardware_id(self.fetch_hardware_id())
            except TolinoError:
                registered = ""
            if registered:
                if registered == normalize_hardware_id(self.hardware):


                    return False
                self.hardware = registered
                self._notify_hardware()
                return True
            registered_ok = self._register_hardware()
            self._hw_registered_now = bool(registered_ok)
            return registered_ok
        finally:
            self._in_device_recovery = False


    def download(self, deliverable_id):
        0                                              
        token = _download_token(deliverable_id)
        info_url = (BASE_URL + "/cloud/downloadinfo/%s/%s/type/external-download"
                    % (token, token))
        info = self._request(info_url)
        content_url = (info.get("DownloadInfo") or {}).get("contentUrl")
        if not content_url:
            raise TolinoApiError("Kein Download-Link in der Antwort.", code="N02", short="tolino hat keinen Download-Link geliefert.")
        try:
            parsed_content_url = urlsplit(str(content_url))
        except (TypeError, ValueError) as exc:
            raise TolinoApiError("Ungültiger Download-Link.", code="N02",
                                 short="tolino hat einen ungültigen Download-Link geliefert.") from exc
        if parsed_content_url.scheme.casefold() != "https" or not parsed_content_url.hostname:
            raise TolinoApiError("Unsicherer Download-Link.", code="N02",
                                 short="Der Download-Link verwendet keine sichere HTTPS-Verbindung.")
        headers = {"User-Agent": BROWSER_USER_AGENT}
        host = parsed_content_url.hostname.casefold().rstrip(".")
        authenticated_host = (
            host == "pageplace.de" or host.endswith(".pageplace.de"))
        request = Request(content_url, headers=headers)
        if authenticated_host:



            request.add_unredirected_header("t_auth_token", self.access)
            request.add_unredirected_header("hardware_id", self.hardware)
            request.add_unredirected_header(
                "reseller_id", self.partner["reseller_id"])
        try:
            with urlopen(request, timeout=self.timeout) as response:
                get_final_url = getattr(response, "geturl", None)
                final_url = urlsplit(get_final_url() if callable(get_final_url)
                                     else content_url)
                if final_url.scheme.casefold() != "https" or not final_url.hostname:
                    raise TolinoApiError(
                        "Der Download wurde auf eine unsichere URL umgeleitet.",
                        code="N02",
                        short="tolino hat einen unsicheren Download-Link geliefert.")
                content = response.read()
        except OSError as exc:
            raise TolinoApiError("Download von Tolino fehlgeschlagen: %s" %
                                 sanitize_error(exc, (self.refresh, self.access)),
                                 code="N02", short="Der Download von Tolino ist fehlgeschlagen.")
        return content


    SYNC_DATA_URL = BASE_URL + "/sync-data?paths=publications"

    def _sync_patch(self, payload):

        self._sync_cache = None
        data = self._request(self.SYNC_DATA_URL, "PATCH", payload,
                             content_type="application/json")
        return data if isinstance(data, dict) else {}

    def sync_snapshot(self):
        0                                                             

                                                                       
                                                                        
                                                                 
           
        if self._sync_cache is None:
            data = self._sync_patch({"revision": None, "patches": []})
            self._sync_cache = (data.get("revision"),
                                data.get("patches") or [])
        return self._sync_cache

    def read_ids(self):
        0                                                

                                                                   
                                                                    
                                    
           
        _revision, patches = self.sync_snapshot()
        return _sync_data.read_ids(patches)

    def progress_by_id(self):
        0                                                            

                                                                            
                                                                      
           
        _revision, patches = self.sync_snapshot()
        return _sync_data.reading_progress(patches)

    def _current_revision(self, revision):
        0                                                            

                                                                       
                                                                       
                                                           
           
        if revision is not None:
            return revision
        revision, _patches = self.sync_snapshot()
        return revision

    def add_to_collection(self, book_id, collection_name, revision=None):
        0                                                      

                                                                           
                                                                      
           
        patch = _sync_data.tag_patch(
            "add", book_id, collection_name, "collection")
        data = self._sync_patch({
            "revision": self._current_revision(revision), "patches": [patch]})
        return data.get("revision")

    def mark_read_many(self, book_ids, finished=True):
        0                                                            

                                                                           
                                                                         
                                    
           
        ids = [str(book_id) for book_id in book_ids or []
               if str(book_id or "").strip()]
        if not ids:
            raise TolinoApiError(
                "Gelesen-Markierung ohne Buch.", code="E99",
                short="Es wurde kein Buch ausgewählt.")
        revision, patches = self.sync_snapshot()
        active = _sync_data.active_read_tags(patches)
        updates = []
        for book_id in ids:
            existing = active.get((str(book_id), _sync_data.READ_TAG))
            if finished:
                if existing is None:
                    updates.append(_sync_data.tag_patch(
                        "add", book_id, _sync_data.READ_TAG, "system"))
            elif existing is not None:
                category = str(
                    (existing.get("value") or {}).get("category") or "system")
                updates.append(_sync_data.tag_patch(
                    "remove", book_id, _sync_data.READ_TAG, category,
                    revision=existing["value"].get("revision"),
                    tag_id=_sync_data.tag_id_from_patch(existing)))
        if not updates:
            return revision
        data = self._sync_patch({"revision": revision, "patches": updates})
        return data.get("revision")

    def collection_pairs(self):
        0                                                               

                                                                
                                            
           
        _revision, patches = self.sync_snapshot()
        return _sync_data.collection_pairs(patches)
