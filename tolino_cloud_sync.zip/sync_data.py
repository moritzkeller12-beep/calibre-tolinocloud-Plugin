0

import time

from .errors import TolinoApiError

READ_TAG = "collection_finished_readings_name"


READ_TAG_CATEGORIES = ("system", "collection")


def tag_patch(op, book_id, name, category, revision=None, tag_id=None):
    0
    value = {"modified": int(time.time() * 1000),
             "name": name, "category": category}
    if revision is not None:
        value["revision"] = revision
    path = "/publications/%s/tags" % book_id
    if op == "remove":
        if not str(tag_id or "").strip():
            raise TolinoApiError(
                "Marken-ID fehlt (%s / %s)." % (book_id, name),
                code="N02", short="Die Marke ist in der Cloud nicht auffindbar.")
        path = "%s/%s" % (path, tag_id)
    return {"op": op, "value": value, "path": path}


def _publication_path_parts(path, kind):
    parts = str(path or "").split("/")
    if (len(parts) < 4 or parts[1] != "publications"
            or parts[3] != kind or not parts[2]):
        return None
    return str(parts[2]), str(parts[4] if len(parts) > 4 else "")


def _is_removal(item):
    0
    return str((item or {}).get("op") or "add") == "remove"


def tag_path_parts(path):
    0
    return _publication_path_parts(path, "tags")


def tag_id_from_patch(item):
    parts = tag_path_parts((item or {}).get("path"))
    return parts[1] if parts else ""


def active_tags(patches, category, name=None):
    0
    active = {}
    for item in patches:
        if not isinstance(item, dict):
            continue
        value = item.get("value")
        if not isinstance(value, dict) or value.get("category") != category:
            continue
        if name is not None and value.get("name") != name:
            continue
        parts = tag_path_parts(item.get("path"))
        if parts is None:
            continue
        key = (parts[0], str(value.get("name") or ""))
        if _is_removal(item):
            active.pop(key, None)
        else:
            active[key] = item
    return active


def read_tag_patches(patches):
    0




    return {(book_id, category): item
            for category in READ_TAG_CATEGORIES
            for (book_id, _name), item
            in active_tags(patches, category, READ_TAG).items()}


def read_ids(patches):
    0
    return {book_id for book_id, _category in read_tag_patches(patches)}


def bookmark_path_parts(path):
    0
    return _publication_path_parts(path, "bookmark")


def _position_text(value):
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def _progress_percent(value, current, last):
    0
    percent = None
    try:
        raw = float(value)
    except (TypeError, ValueError):
        raw = None
    if raw is not None:
        if 0 <= raw <= 1:
            percent = round(raw * 100)
        elif 0 < raw <= 100:
            percent = round(raw)
    if percent is None:
        try:
            current_number, last_number = int(current), int(last)
        except (TypeError, ValueError):
            current_number = last_number = 0
        if last_number > 0:
            percent = round(current_number / last_number * 100)
    if percent is None:
        return None
    return max(0, min(100, int(percent)))


def _bookmark_entry(value):
    if not isinstance(value, dict):
        return None
    current = _position_text(value.get("currentPosition"))
    last = _position_text(value.get("lastPosition"))
    percent = _progress_percent(value.get("progress"), current, last)
    if percent is None and not current and not last:
        return None
    try:
        modified = int(value.get("modified") or 0)
    except (TypeError, ValueError):
        modified = 0
    return {
        "percent": percent,
        "current": current,
        "last": last,
        "position": str(value.get("position") or "").strip(),
        "modified": modified,
    }


def reading_progress(patches):
    0





    active, order, newest = {}, 0, {}
    for item in patches:
        if not isinstance(item, dict):
            continue
        parts = bookmark_path_parts(item.get("path"))
        if parts is None:
            continue
        key = (parts[0], parts[1])
        if _is_removal(item):
            active.pop(key, None)
            continue
        entry = _bookmark_entry(item.get("value"))
        if entry is None:
            continue
        order += 1
        previous = active.get(key)
        if previous is None or entry["modified"] >= previous[0]["modified"]:
            active[key] = (entry, order)
    for (book_id, _bookmark_id), candidate in active.items():
        newest[book_id] = max(
            newest.get(book_id, candidate), candidate,
            key=lambda pair: (pair[0]["modified"], pair[1]))
    return {book_id: entry for book_id, (entry, _sequence) in newest.items()}


def collection_pairs(patches):
    return set(active_tags(patches, "collection"))
