0                                                                 
import base64
import hashlib







def _evp_bytes_to_key(password, salt):
    0                                                     
    derived = b""
    previous = b""
    while len(derived) < 48:
        previous = hashlib.md5(previous + password + salt).digest()
        derived += previous
    return derived[:32], derived[32:48]


def _pkcs7_unpad(data):
    if not data or len(data) % 16:
        return None
    pad = data[-1]
    if not 1 <= pad <= 16 or data[-pad:] != bytes([pad]) * pad:
        return None
    return data[:-pad]


def cryptojs_decrypt(b64_text):
    0                                                                          



    try:
        from Crypto.Cipher import AES
    except ImportError:
        return ""
    try:
        raw = base64.b64decode("".join(str(b64_text or "").split()), validate=False)
    except ValueError:
        return ""
    if len(raw) < 32 or raw[:8] != b"Salted__":
        return ""
    salt = raw[8:16]
    ciphertext = raw[16:]
    if not ciphertext or len(ciphertext) % 16:
        return ""
    key, iv = _evp_bytes_to_key(b"", salt)
    try:
        plain = AES.new(key, AES.MODE_CBC, iv).decrypt(ciphertext)
    except ValueError:
        return ""
    plain = _pkcs7_unpad(plain)
    if plain is None:
        return ""
    try:
        return plain.decode("utf-8")
    except UnicodeDecodeError:
        return ""
