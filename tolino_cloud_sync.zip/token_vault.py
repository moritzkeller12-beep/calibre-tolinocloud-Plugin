





import contextlib
import threading
import time

from .config import (account_secrets, account_tokens,
                     clear_refresh_token_if_unchanged, save_access_token,
                     save_hardware_id, save_refresh_token, settings,
                     settings_write_lock, settings_writable)
from .jwt import lifetime_seconds
from .tolino import (BUSY_MESSAGE, RELOGIN, TolinoAuthError, TolinoClient,
                     TolinoError, log_info, log_warning,
                     normalize_refresh_token, sanitize_error)



KEEPALIVE_MIN_DELAY = 5 * 60
REFRESH_MARGIN_MIN = 120
REFRESH_MARGIN_FRACTION = 0.2


def _lock_busy(exc):
    0
    return isinstance(exc, TolinoAuthError) and exc.code == "S91"


def _seconds(value):
    0
    try:
        return max(0.0, float(value or 0))
    except (TypeError, ValueError):
        return 0.0


def _require_savable_rotation():
    0
    if settings_writable():
        return
    raise TolinoError(
        "Die Einstellungen sind nicht beschreibbar; der Zugang "
        "wird nicht erneuert.",
        short="Die Einstellungen konnten nicht gespeichert werden. " + RELOGIN,
        detail="Token-Tausch ohne speicherbare Rotation abgelehnt.")


class TokenVault:
    0

    def __init__(self):
        self._lock = threading.Lock()

    def login(self, account_name, partner_id=None, lock_timeout=5):
        0





        with self._held_lock(lock_timeout), settings_write_lock():
            values = self._stored_credentials(account_name)
            client = TolinoClient(
                partner_id or values["partner_id"], values["hardware_id"],
                values["refresh_token"],
                token_callback=lambda token: save_refresh_token(
                    account_name, token),
                hardware_callback=lambda hardware: save_hardware_id(
                    account_name, hardware),


                access=values["access_token"],
                access_expires_at=values["access_expires_at"],
                access_callback=lambda token, expires: save_access_token(
                    account_name, token, expires),




                stored_token_callback=lambda: account_tokens(
                    account_name).get("refresh_token"))
            client.rotation_guard = _require_savable_rotation



            client.token_rejected_callback = (
                lambda rejected: clear_refresh_token_if_unchanged(
                    account_name, rejected))
            if not values["hardware_id"] and not save_hardware_id(
                    account_name, client.hardware):


                raise TolinoError(
                    "Die Geräte-ID konnte nicht gespeichert werden. Ohne sie "
                    "gilt jeder Lauf als neues Gerät; bitte die "
                    "Einstellungsdatei prüfen und erneut anmelden.",
                    short="Die Geräte-ID konnte nicht gespeichert werden.",
                    detail="Einstellungen konnten nicht geschrieben werden.")


            client.login()
            client.account_name = account_name
            client.token_vault = self
        return client

    @contextlib.contextmanager
    def _held_lock(self, timeout):
        0
        if not self._lock.acquire(timeout=max(0, timeout)):
            raise TolinoAuthError(BUSY_MESSAGE, code="S91")
        try:
            yield
        finally:
            self._lock.release()

    @staticmethod
    def _stored_credentials(account_name):
        0
        account = account_tokens(account_name) or {}
        refresh = normalize_refresh_token(account.get("refresh_token"))
        if not refresh:
            raise TolinoAuthError("Noch nicht angemeldet. " + RELOGIN,
                                  code="A01")
        partner = account.get("partner_id")
        try:
            partner = 1 if partner is None else int(partner)
        except (TypeError, ValueError):
            partner = 0
        return {"refresh_token": refresh,
                "hardware_id": str(account.get("hardware_id") or ""),
                "partner_id": partner,
                "access_token": str(account.get("access_token") or ""),
                "access_expires_at": _seconds(account.get("access_expires_at"))}

    def relogin(self, client, timeout=30):
        0






        with self._held_lock(timeout), settings_write_lock():
            values = self._stored_credentials(client.account_name)
            if values["partner_id"] != client.partner_id:




                raise TolinoAuthError(
                    "Das gespeicherte Konto gehoert zu einem anderen "
                    "Buchhändler (Partner %s statt %s). "
                    % (values["partner_id"], client.partner_id) + RELOGIN,
                    code="A01",
                    short="Die Anmeldung gehört zu einem anderen Buchhändler.",
                    detail="Bitte mit dem hinterlegten Buchhändler anmelden.")
            client.refresh = values["refresh_token"]
            client.hardware = values["hardware_id"] or client.hardware
            client.rotation_guard = _require_savable_rotation


            return client._login()

    def due_in(self, account_name):
        0





        values = account_tokens(account_name)
        if not normalize_refresh_token(values.get("refresh_token")):
            return None
        now, deadlines = time.time(), []
        lifetime = lifetime_seconds(values["refresh_token"])
        rotated = _seconds(values.get("refresh_rotated_at"))
        if lifetime and rotated:
            margin = max(REFRESH_MARGIN_MIN,
                         lifetime * REFRESH_MARGIN_FRACTION)
            deadlines.append(rotated + lifetime - margin)
        access_expires = _seconds(values.get("access_expires_at"))
        if access_expires:
            deadlines.append(access_expires)
        if not deadlines:
            return None
        return max(0.0, min(deadlines) - now)

    def next_delay(self, default):
        0
        try:
            accounts = settings()["accounts"]
        except Exception:
            return default
        delays = []
        for account in accounts:
            if not normalize_refresh_token(account.get("refresh_token")):
                continue
            due = self.due_in(str(account.get("name") or ""))
            if due is not None:
                delays.append(due)
        if not delays:
            return default
        return max(KEEPALIVE_MIN_DELAY, min(default, min(delays)))

    def keepalive_refresh(self, only_due=False):
        0





        if not settings_writable():


            log_warning("Tolino-Keep-alive: Einstellungen sind nicht "
                        "speicherbar; es wird nichts erneuert.")
            return 0
        try:
            accounts = settings()["accounts"]
        except Exception:
            log_warning("Tolino-Keep-alive: Einstellungen konnten nicht "
                        "gelesen werden.")
            return 0
        rotated = 0
        for account in accounts:
            name = str(account.get("name") or "")


            if not name or not normalize_refresh_token(
                    account.get("refresh_token")):
                continue
            if only_due:
                due = self.due_in(name)
                if due is not None and due > 0:
                    continue
            try:
                self.login(name, lock_timeout=0)
                rotated += 1
            except Exception as exc:

                if _lock_busy(exc):
                    continue
                log_warning("Tolino-Keep-alive fehlgeschlagen (%s): %s"
                            % (name, sanitize_error(
                                exc, account_secrets(name))))
        if rotated:
            log_info("Tolino-Keep-alive: %d %s erneuert."
                     % (rotated, "Konto" if rotated == 1 else "Konten"))


        return rotated

TOKEN_VAULT = TokenVault()
_KEEPALIVE_THREAD = None
_KEEPALIVE_STOP = None
_KEEPALIVE_LOCK = threading.Lock()


def start_token_keepalive(interval=45 * 60):
    0





    global _KEEPALIVE_THREAD, _KEEPALIVE_STOP
    cap = max(60, interval)
    with _KEEPALIVE_LOCK:
        if _KEEPALIVE_THREAD is not None and _KEEPALIVE_THREAD.is_alive():
            return None


        stop = threading.Event()

        def loop():
            TOKEN_VAULT.keepalive_refresh(only_due=True)
            while not stop.wait(TOKEN_VAULT.next_delay(cap)):
                TOKEN_VAULT.keepalive_refresh(only_due=True)

        thread = threading.Thread(
            target=loop, name="tolino-token-keepalive", daemon=True)
        _KEEPALIVE_THREAD, _KEEPALIVE_STOP = thread, stop
        thread.start()
    log_info("Tolino-Keep-alive gestartet: nächste Runde nach der Laufzeit "
             "des Tokens (spätestens alle %d Minuten)." % (cap // 60))
    return thread


def stop_token_keepalive(timeout=2):
    0




    global _KEEPALIVE_THREAD, _KEEPALIVE_STOP
    with _KEEPALIVE_LOCK:
        thread, stop = _KEEPALIVE_THREAD, _KEEPALIVE_STOP
        if thread is None:
            return True
        stop.set()
        if thread.is_alive():
            thread.join(timeout=max(0.1, timeout))
        if thread.is_alive():
            return False
        _KEEPALIVE_THREAD = _KEEPALIVE_STOP = None
        return True


def check_stored_login(account_name, partner_id=None, lock_timeout=5):
    0
    try:
        TOKEN_VAULT.login(account_name, partner_id, lock_timeout)
        return "valid", ""
    except Exception as exc:
        if _lock_busy(exc):
            return "busy", ""
        return "invalid", sanitize_error(exc, account_secrets(account_name))
