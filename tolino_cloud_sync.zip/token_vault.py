0                                                                    

                                                                        
                                                                    
                                                      
   
import contextlib
import threading

from .config import (account_secrets, account_summary, clear_refresh_token,
                     save_hardware_id, save_refresh_token, settings)
from .tolino import (BUSY_MESSAGE, RELOGIN, TolinoAuthError, TolinoClient,
                     log_info, log_warning, normalize_refresh_token,
                     sanitize_error)


class TokenVault:
    0                                                                  

    def __init__(self):
        self._lock = threading.Lock()

    def login(self, account_name, partner_id, lock_timeout=5):
        0                                                                    
        with self._held_lock(lock_timeout):
            values = self._stored_credentials(account_name)
            client = TolinoClient(
                partner_id, values["hardware_id"], values["refresh_token"],
                token_callback=lambda token: save_refresh_token(
                    account_name, token),
                hardware_callback=lambda hardware: save_hardware_id(
                    account_name, hardware))
            client.token_rejected_callback = lambda: clear_refresh_token(
                account_name)
            if not values["hardware_id"]:

                save_hardware_id(account_name, client.hardware)


            client.login()
            client.account_name = account_name
            client.token_vault = self
        return client

    @contextlib.contextmanager
    def _held_lock(self, timeout):
        0                                                             
        if not self._lock.acquire(timeout=max(0, timeout)):
            raise TolinoAuthError(BUSY_MESSAGE, code="S91")
        try:
            yield
        finally:
            self._lock.release()

    @staticmethod
    def _stored_credentials(account_name):
        0                                                                    
        account = account_summary(account_name) or {}
        refresh = normalize_refresh_token(account.get("refresh_token"))
        if not refresh:
            raise TolinoAuthError("Noch nicht angemeldet. " + RELOGIN,
                                  code="A01")
        return {"refresh_token": refresh,
                "hardware_id": str(account.get("hardware_id") or "")}

    def relogin(self, client, timeout=30):
        0                                                                   

                                                                     
                                                                           
                                                     
           
        with self._held_lock(timeout):
            values = self._stored_credentials(client.account_name)
            client.refresh = values["refresh_token"]
            client.hardware = values["hardware_id"] or client.hardware


            return client._login()

    def keepalive_refresh(self):
        0                                                                
        rotated = 0
        for account in settings()["accounts"]:
            name = str(account.get("name") or "")
            if not name or not str(account.get("refresh_token") or "").strip():
                continue
            try:
                self.login(name, account.get("partner_id"), lock_timeout=0)
                rotated += 1
            except Exception as exc:

                if isinstance(exc, TolinoAuthError) and exc.code == "S91":
                    continue
                log_warning("Tolino-Keep-alive fehlgeschlagen (%s): %s"
                            % (name, sanitize_error(
                                exc, account_secrets(name))))
        if rotated:
            log_info("Tolino-Keep-alive: %d %s erneuert."
                     % (rotated, "Konto" if rotated == 1 else "Konten"))


        return rotated

TOKEN_VAULT = TokenVault()
_KEEPALIVE_THREAD = None
_KEEPALIVE_STOP = None
_KEEPALIVE_LOCK = threading.Lock()


def start_token_keepalive(interval=45 * 60):
    0                                                                  
    global _KEEPALIVE_THREAD, _KEEPALIVE_STOP
    wait = max(60, interval)
    with _KEEPALIVE_LOCK:
        if _KEEPALIVE_THREAD is not None and _KEEPALIVE_THREAD.is_alive():
            return None


        stop = threading.Event()

        def loop():
            while not stop.wait(wait):
                TOKEN_VAULT.keepalive_refresh()

        thread = threading.Thread(
            target=loop, name="tolino-token-keepalive", daemon=True)
        _KEEPALIVE_THREAD, _KEEPALIVE_STOP = thread, stop
        thread.start()
    log_info("Tolino-Keep-alive gestartet: alle %d Minuten." % (wait // 60))
    return thread


def stop_token_keepalive(timeout=2):
    0                                                              

                                                                            
                                                                          
       
    global _KEEPALIVE_THREAD, _KEEPALIVE_STOP
    with _KEEPALIVE_LOCK:
        thread, stop = _KEEPALIVE_THREAD, _KEEPALIVE_STOP
        if thread is None:
            return True
        stop.set()
        if thread.is_alive():
            thread.join(timeout=max(0.1, timeout))
        if thread.is_alive():
            return False
        _KEEPALIVE_THREAD = _KEEPALIVE_STOP = None
        return True


def check_stored_login(account_name, partner_id, lock_timeout=5):
    0                                                                  
    try:
        TOKEN_VAULT.login(account_name, partner_id, lock_timeout)
        return "valid", ""
    except Exception as exc:
        if isinstance(exc, TolinoAuthError) and exc.code == "S91":
            return "busy", ""
        return "invalid", sanitize_error(exc, account_secrets(account_name))
