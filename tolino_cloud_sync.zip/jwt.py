




import base64
import json


def payload(token):
    0
    try:
        parts = str(token or "").split(".")
        if len(parts) != 3 or not parts[1]:
            return None
        segment = parts[1]
        segment += "=" * (-len(segment) % 4)
        data = json.loads(base64.urlsafe_b64decode(segment.encode("ascii")))
        return data if isinstance(data, dict) else None
    except ValueError:
        return None


def _claim_time(token, name):
    0
    value = (payload(token) or {}).get(name)
    try:
        value = float(value)
    except (TypeError, ValueError):
        return None
    return value if value > 0 else None


def issued_at(token):
    0
    return _claim_time(token, "iat")


def expires_at(token):
    0
    return _claim_time(token, "exp")


def lifetime_seconds(token):
    0




    expires, issued = expires_at(token), issued_at(token)
    if expires is None or issued is None or expires <= issued:
        return None
    return expires - issued
