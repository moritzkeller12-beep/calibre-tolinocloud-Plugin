0
import hashlib
import json
import re
from collections.abc import Iterable

TOLINO_COLUMN = "#tolino_id"


TOLINO_IGNORE_COLUMN = "#tolino_ignore"
TOLINO_READ_COLUMN = "#tolino_read"

TOLINO_PROGRESS_COLUMN = "#tolino_progress"


_TRUE_VALUES = frozenset(("true", "yes", "ja", "1"))
_FALSE_VALUES = frozenset(("false", "no", "nein", "0"))


DEFAULT_LIBRARY_SCOPE = hashlib.sha256(
    b"tolino-cloud-sync-default-library").hexdigest()[:12]


def library_scope(database):
    0






    text = str(getattr(database, "library_id", "") or "").strip()
    if not text:
        return DEFAULT_LIBRARY_SCOPE
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:12]


def _column_value(metadata):
    0
    return metadata.get(TOLINO_COLUMN, "") or ""


def _decode_tolino_ids(value):
    0
    if isinstance(value, dict):
        decoded = value
    elif isinstance(value, str) and value.strip().startswith("{"):
        try:
            decoded = json.loads(value)
        except (TypeError, ValueError):
            return {}
    else:
        return {}
    if not isinstance(decoded, dict):
        return {}
    return {str(name): str(book_id).strip()
            for name, book_id in decoded.items()
            if name and isinstance(book_id, (str, int)) and str(book_id).strip()}


def _encode_tolino_ids(ids):
    return json.dumps(ids, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":")) if ids else ""


def metadata_tolino_id(metadata, account_name=None):
    0
    account_ids = _decode_tolino_ids(_column_value(metadata))
    return str(account_ids.get(str(account_name), "") or "").strip()


def _column_available(database, column, datatypes):
    fields = database.field_metadata
    return column in fields and fields[column].get("datatype") in datatypes


def bool_column_available(database, column):
    0




    return _column_available(database, column, ("bool",))


def bool_column_value(metadata, column):
    0
    value = metadata.get(column, None)
    if isinstance(value, bool):
        return value
    text = str(value if value is not None else "").strip().casefold()
    if text in _TRUE_VALUES:
        return True
    if text in _FALSE_VALUES:
        return False
    return None


def metadata_ignored(metadata):
    0





    return bool_column_value(metadata, TOLINO_IGNORE_COLUMN) is True



CUSTOM_COLUMNS = (
    ("tolino_id", "tolino-ID", "text"),
    ("tolino_read", "Gelesen (tolino)", "bool"),
    ("tolino_progress", "tolino gelesen %", "int"),
    ("tolino_ignore", "Ignoriert (tolino)", "bool"),
)


COLUMN_KIND_NAMES = {"text": "Text", "bool": "Ja/Nein",
                     "int": "Zahl", "float": "Zahl"}






CREATED_COLUMNS = {}


def _library_key(database):
    0
    for holder in (database, getattr(database, "new_api", None)):
        dbpath = getattr(holder, "dbpath", None)
        if isinstance(dbpath, str) and dbpath:
            return dbpath
    return id(database)


def _column_present(database, label):
    0
    if label in CREATED_COLUMNS.get(_library_key(database), ()):
        return True
    return ("#" + label) in database.field_metadata


def _live_field_metadata(database):
    0
    views = []
    for holder in (getattr(database, "new_api", None), database):
        fields = getattr(holder, "field_metadata", None)
        if fields is not None and all(fields is not seen for seen in views):
            views.append(fields)
    return views


def _assign_record_index(fields, label):
    0





    key = "#" + label
    setter = getattr(fields, "set_field_record_index", None)
    if not callable(setter) or key not in fields:
        return
    if fields[key].get("rec_index") is not None:
        return
    used = 0
    try:
        for name in fields:
            index = fields[name].get("rec_index")
            if isinstance(index, int) and index > used:
                used = index
    except (KeyError, TypeError):
        return
    try:
        setter(label, used + 1, prefer_custom=True)
    except (KeyError, TypeError, ValueError):
        return


def _register_session_columns(database, labels):
    0









    api = getattr(database, "new_api", None)
    backend = getattr(api, "backend", None)
    execute = getattr(backend, "execute", None)
    table_names = getattr(backend, "custom_table_names", None)
    if not callable(execute) or not callable(table_names):
        return
    try:
        tristate = backend.prefs["bools_are_tristate"]
    except (AttributeError, KeyError, TypeError):
        tristate = True
    tables = getattr(backend, "tables", None)
    field_objects = getattr(api, "fields", None)
    for label in labels:
        row = execute("SELECT id, name, datatype, is_multiple, editable, "
                      "display, normalized FROM custom_columns "
                      "WHERE label = ?", (label,)).fetchone()
        if not row:
            continue
        num, name, datatype, _is_multiple, editable, display, normalized = row
        if isinstance(display, str):
            try:
                display = json.loads(display)
            except (TypeError, ValueError):
                display = None
        key = "#" + label
        table_name = table_names(num)[0]
        for fields in _live_field_metadata(database):
            add = getattr(fields, "add_custom_field", None)
            if key not in fields:
                if not callable(add):
                    continue
                try:
                    add(label=label, table=table_name, column="value",
                        datatype=datatype, colnum=num, name=name or label,
                        display=display if isinstance(display, dict) else {},
                        is_editable=bool(editable), is_multiple={},
                        is_category=datatype in ("text", "comments", "series",
                                                 "enumeration"))
                except (KeyError, TypeError, ValueError):
                    continue
            _assign_record_index(fields, label)
        if not isinstance(tables, dict) or not isinstance(field_objects, dict):
            continue
        if key in tables:
            continue
        try:
            from calibre.db.fields import create_field
            from calibre.db.tables import ManyToOneTable, OneToOneTable
        except ImportError:
            continue
        try:
            metadata = dict(api.field_metadata[key])
            if normalized:
                table = ManyToOneTable(key, metadata,
                                       link_table=table_names(num)[1])
            else:
                table = OneToOneTable(key, metadata)
            table.read(backend)
            tables[key] = table
            field_objects[key] = create_field(
                key, table, tristate, backend.get_template_functions,
                api.database_instance)
        except Exception:


            tables.pop(key, None)
            field_objects.pop(key, None)


def create_custom_columns(database, labels=None):
    0













    wanted = None if labels is None else set(labels)
    selected = (CUSTOM_COLUMNS if wanted is None else
                tuple(spec for spec in CUSTOM_COLUMNS if spec[0] in wanted))
    missing = [spec for spec in selected
               if not _column_present(database, spec[0])]
    if not missing:
        return []
    create = getattr(database, "create_custom_column", None)
    if not callable(create):
        create = getattr(getattr(database, "new_api", None),
                         "create_custom_column", None)
    if not callable(create):
        raise RuntimeError(
            "Diese Calibre-Version kennt create_custom_column nicht. Lege "
            "die Spalten bitte von Hand an: %s."
            % ", ".join("#" + label for label, _name, _datatype
                        in missing))
    created = []
    for label, name, datatype in missing:
        create(label, name, datatype, False, editable=True, display={})
        CREATED_COLUMNS.setdefault(
            _library_key(database), set()).add(label)
        created.append(label)
    _register_session_columns(database, created)
    return created


def column_state(database):
    0





    return {"id": TOLINO_COLUMN in database.field_metadata,
            "read": bool_column_available(database, TOLINO_READ_COLUMN),
            "progress": _column_available(
                database, TOLINO_PROGRESS_COLUMN, ("int", "float"))}


_SKIP = object()


def _progress_value(value):
    if value is None:
        return None
    try:
        value = round(float(value))
    except (TypeError, ValueError, OverflowError):
        return _SKIP
    return value if 0 <= value <= 100 else _SKIP


def _update_column(database, column, updates, convert, datatypes):
    0
    if not updates or not _column_available(database, column, datatypes):
        return 0
    api = database.new_api
    field_for = getattr(api, "field_for", None)
    values = {}
    for book_id, raw in updates:
        if book_id is None or not api.has_id(book_id):
            continue
        value = None if raw is None else convert(raw)
        if value is _SKIP:
            continue


        if callable(field_for) and field_for(column, book_id) == value:
            continue
        values[book_id] = value
    if values:
        api.set_field(column, values)
    return len(values)


def update_read_status(database, updates):
    0





    return _update_column(database, TOLINO_READ_COLUMN, updates, bool,
                          ("bool",))


def update_progress_status(database, updates):
    0





    return _update_column(database, TOLINO_PROGRESS_COLUMN, updates,
                          _progress_value, ("int", "float"))


def update_tolino_ids(database, updates, account_name=None):
    0




    if not updates or TOLINO_COLUMN not in database.field_metadata:
        return 0
    account_name = str(account_name or "").strip()
    if not account_name:
        return 0
    api = database.new_api
    values = {}
    for book_id, tolino_id in updates:
        if book_id is None or not api.has_id(book_id):
            continue
        new_id = str(tolino_id or "").strip()
        account_ids = _decode_tolino_ids(
            api.field_for(TOLINO_COLUMN, book_id))
        if new_id:
            account_ids[account_name] = new_id
        else:
            account_ids.pop(account_name, None)
        values[book_id] = _encode_tolino_ids(account_ids)
    if not values:
        return 0
    api.set_field(TOLINO_COLUMN, values)
    return len(values)


def normalize_formats(value):
    0
    if isinstance(value, str):
        values = value.split(",")
    elif isinstance(value, Iterable) and not isinstance(value, (bytes, bytearray)):
        values = value
    else:
        return []
    cleaned = ("" if part is None else str(part).strip().lstrip(".").upper()
               for part in values)
    return list(dict.fromkeys(text for text in cleaned if text))



def safe_format_path(database, book_id, format_name):
    0
    if not isinstance(format_name, str):
        raise ValueError("Invalid format name: %r" % (format_name,))
    format_name = format_name.strip().lstrip(".").upper()
    if not format_name or not re.match(r"^[A-Z0-9][A-Z0-9._-]*$", format_name):
        raise ValueError("Invalid format name: %r" % (format_name,))
    api = database.new_api
    if not api.has_id(book_id):
        raise ValueError("Calibre database has no book with id %r." % (book_id,))
    try:
        path = api.format_abspath(book_id, format_name)
    except (ValueError, IndexError, KeyError, OSError) as exc:
        raise ValueError("Calibre returned no path for book %r format %s" %
                         (book_id, format_name)) from exc
    if not isinstance(path, str) or not path:
        raise ValueError("Calibre returned no path for book %r format %s" %
                         (book_id, format_name))
    return path


def cover_bytes(database, book_id):
    0
    api = database.new_api
    if not api.has_id(book_id):
        raise ValueError("Calibre database has no book with id %r." % (book_id,))
    return api.cover(book_id, as_file=False)


def image_suffix(data):
    0
    if not isinstance(data, bytes) or not data:
        return ""
    if data.startswith(b"\xff\xd8\xff"):
        return ".jpg"
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return ".png"
    if data.startswith((b"GIF87a", b"GIF89a")):
        return ".gif"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return ".webp"
    return ""

