0                                                                
import json
import re
from collections.abc import Iterable

TOLINO_COLUMN = "#tolino_id"


TOLINO_IGNORE_COLUMN = "#tolino_ignore"
TOLINO_READ_COLUMN = "#tolino_read"

TOLINO_PROGRESS_COLUMN = "#tolino_progress"


_TRUE_VALUES = frozenset(("true", "yes", "ja", "1"))
_FALSE_VALUES = frozenset(("false", "no", "nein", "0"))


def _column_value(metadata):
    0                                             
    getter = getattr(metadata, "get", None)
    if callable(getter):
        return getter(TOLINO_COLUMN, "") or getter("tolino_id", "") or ""
    return ""


def _decode_tolino_ids(value):
    0                                                                     
    if isinstance(value, dict):
        decoded = value
    elif isinstance(value, str) and value.strip().startswith("{"):
        try:
            decoded = json.loads(value)
        except (TypeError, ValueError):
            return None
    else:
        return None
    if not isinstance(decoded, dict):
        return None
    return {str(name): str(book_id).strip()
            for name, book_id in decoded.items()
            if name and isinstance(book_id, (str, int)) and str(book_id).strip()}


def _encode_tolino_ids(ids):
    return json.dumps(ids, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":")) if ids else ""


def metadata_tolino_id(metadata, account_name=None):
    0                                                       
    value = _column_value(metadata)
    account_ids = _decode_tolino_ids(value)
    if account_ids is not None:
        return str(account_ids.get(str(account_name), "") or "").strip()
    return str(value or "").strip()


def _column_available(database, column, datatypes):
    fields = database.field_metadata
    return column in fields and fields[column].get("datatype") in datatypes


def bool_column_available(database, column):
    0                                                      

                                                                         
                                                          
       
    return _column_available(database, column, ("bool",))


def integer_column_available(database, column):
    0                                                             
    return _column_available(database, column, ("int", "float"))


def bool_column_value(metadata, column):
    0                                                                      
    getter = getattr(metadata, "get", None)
    value = getter(column, None) if callable(getter) else None
    if isinstance(value, bool):
        return value
    text = str(value if value is not None else "").strip().casefold()
    if text in _TRUE_VALUES:
        return True
    if text in _FALSE_VALUES:
        return False
    return None


def metadata_ignored(metadata):
    0                                                     

                                                                        
                                                                          
                      
       
    return bool_column_value(metadata, TOLINO_IGNORE_COLUMN) is True



CUSTOM_COLUMNS = (
    ("tolino_id", "tolino-ID", "text"),
    ("tolino_read", "Gelesen (tolino)", "bool"),
    ("tolino_progress", "tolino gelesen %", "int"),
    ("tolino_ignore", "Ignoriert (tolino)", "bool"),
)


COLUMN_KIND_NAMES = {"text": "Text", "bool": "Ja/Nein"}




CREATED_COLUMNS = set()


def _column_present(database, label):
    0                                                                            
    return label in CREATED_COLUMNS or ("#" + label) in database.field_metadata


def create_custom_columns(database, labels=None):
    0                                                                     

                                                                      
                                                                    
                                                                         
                                           

                                                                          
                                                                       
                                                 

                                                                        
                                       
       
    wanted = None if labels is None else set(labels)
    selected = (CUSTOM_COLUMNS if wanted is None else
                tuple(spec for spec in CUSTOM_COLUMNS if spec[0] in wanted))
    missing = [spec for spec in selected
               if not _column_present(database, spec[0])]
    if not missing:
        return []
    create = getattr(database, "create_custom_column", None)
    if not callable(create):
        create = getattr(getattr(database, "new_api", None),
                         "create_custom_column", None)
    if not callable(create):
        raise RuntimeError(
            "Diese Calibre-Version kennt create_custom_column nicht. Lege "
            "die Spalten bitte von Hand an: %s."
            % ", ".join("#" + label for label, _name, _datatype
                        in missing))
    created = []
    for label, name, datatype in missing:
        create(label, name, datatype, False, editable=True, display={})
        CREATED_COLUMNS.add(label)
        created.append(label)
    return created


def column_state(database):
    0                                                         

                                                                       
                                                                      
            
       
    return {"id": TOLINO_COLUMN in database.field_metadata,
            "read": bool_column_available(database, TOLINO_READ_COLUMN),
            "progress": integer_column_available(
                database, TOLINO_PROGRESS_COLUMN)}


_SKIP = object()


def _progress_value(value):
    if value is None:
        return None
    try:
        value = int(round(float(value)))
    except (TypeError, ValueError, OverflowError):
        return _SKIP
    return value if 0 <= value <= 100 else _SKIP


def _update_column(database, column, updates, convert, datatypes):
    0                                                         
    if not updates or not _column_available(database, column, datatypes):
        return 0
    api = database.new_api
    values = {}
    for book_id, raw in updates:
        if book_id is not None and api.has_id(book_id):
            value = convert(raw)
            if value is not _SKIP:
                values[book_id] = value
    if values:
        api.set_field(column, values)
    return len(values)


def update_read_status(database, updates):
    0                                                           

                                                                             
                                                                  
       
    return _update_column(database, TOLINO_READ_COLUMN, updates, bool,
                          ("bool",))


def update_progress_status(database, updates):
    0                                                            

                                                                          
                                                                         
                                                 
       
    return _update_column(database, TOLINO_PROGRESS_COLUMN, updates,
                          _progress_value, ("int", "float"))


def update_tolino_ids(database, updates, account_name=None):
    0                                                                   
    if not updates or TOLINO_COLUMN not in database.field_metadata:
        return 0
    api = database.new_api
    account_name = str(account_name or "").strip()
    values = {}
    for book_id, tolino_id in updates:
        if book_id is None or not api.has_id(book_id):
            continue
        new_id = str(tolino_id or "").strip()
        if not account_name:
            values[book_id] = new_id
            continue
        raw = api.field_for(TOLINO_COLUMN, book_id)
        account_ids = _decode_tolino_ids(raw)
        if account_ids is None:


            legacy = str(raw or "").strip()
            account_ids = {}
            if legacy:
                account_ids[account_name] = legacy
        if new_id:
            account_ids[account_name] = new_id
        else:
            account_ids.pop(account_name, None)
        values[book_id] = _encode_tolino_ids(account_ids)
    if not values:
        return 0
    api.set_field(TOLINO_COLUMN, values)
    return len(values)


def normalize_formats(value):
    0                                                                         
    if isinstance(value, str):
        values = value.split(",")
    elif isinstance(value, Iterable) and not isinstance(value, (bytes, bytearray)):
        values = value
    else:
        return []
    formats = []
    for part in values:
        if part is None:
            continue
        text = str(part).strip().lstrip(".").upper()
        if text and text not in formats:
            formats.append(text)
    return formats



def safe_format_path(database, book_id, format_name):
    0                                                                           
    if not isinstance(format_name, str):
        raise ValueError("Invalid format name: %r" % (format_name,))
    format_name = format_name.strip().lstrip(".").upper()
    if not format_name or not re.match(r"^[A-Z0-9][A-Z0-9._-]*$", format_name):
        raise ValueError("Invalid format name: %r" % (format_name,))
    api = database.new_api
    if not api.has_id(book_id):
        raise ValueError("Calibre database has no book with id %r." % (book_id,))
    try:
        path = api.format_abspath(book_id, format_name)
    except (ValueError, IndexError, KeyError, OSError) as exc:
        raise ValueError("Calibre returned no path for book %r format %s" %
                         (book_id, format_name)) from exc
    if not isinstance(path, str) or not path:
        raise ValueError("Calibre returned no path for book %r format %s" %
                         (book_id, format_name))
    return path


def cover_bytes(database, book_id):
    0                                                                        
    api = database.new_api
    if not api.has_id(book_id):
        raise ValueError("Calibre database has no book with id %r." % (book_id,))
    return api.cover(book_id, as_file=False)


def image_suffix(data):
    0                                                                    
    if not isinstance(data, bytes) or not data:
        return ""
    if data.startswith(b"\xff\xd8\xff"):
        return ".jpg"
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return ".png"
    if data.startswith((b"GIF87a", b"GIF89a")):
        return ".gif"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return ".webp"
    return ""

