
import copy
from collections import Counter
from functools import partial

from qt.core import QObject, pyqtSignal
from .ui_common import (CANCEL_MESSAGE, OP_FAILED, OP_NOT_STARTED, OP_SKIPPED,
                        OP_SUCCEEDED)
from .token_vault import TOKEN_VAULT
from .config import (account_by_name, account_secrets, load_state, save_state)
from .errors import SETTINGS_WRITE_DETAIL
from .planning import (local_metadata, plan_collection_updates,
                       remember_collection)
from .comparison import (compare_inventory, content_fingerprint,
                         metadata_fingerprint, reading_state,
                         reset_copy_state, store_reading_state)
from .identifiers import display_title, state_entry, valid_book_uuid
from .library import image_suffix
from .tolino import (TolinoApiError, TolinoAuthError, TolinoError, log_warning,
                     report_error, sanitize_error)


class _CancellableWorker(QObject):
    0

    cancelled = False

    def cancel(self):
        self.cancelled = True


class SyncWorker(_CancellableWorker):
    progress = pyqtSignal(int, int, str)
    completed = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, context, jobs, removals, meta_updates=None,
                 series_map=None, read_changes=None, titles=None,
                 metadata=None, state=None):
        _CancellableWorker.__init__(self)

        self.context = context
        self.account_name = self.context.account_name
        self.jobs = list(jobs or ())
        self.removals = list(removals or ())
        self.meta_updates = list(meta_updates or ())
        self.series_map = dict(series_map or {})


        self.read_changes = [
            (tolino_id, change[1], bool(change[2]),
             valid_book_uuid(change[3]) if len(change) > 3 else "")
            for change in (read_changes or ())
            if isinstance(change, (tuple, list)) and len(change) >= 3
            and (tolino_id := str(change[0] or "").strip())
        ]
        self.titles = {str(key): str(value)
                       for key, value in (titles or {}).items()
                       if value}
        self.metadata_by_uuid = {
            str(item["uuid"]): item
            for item in (metadata or {}).values()
            if isinstance(item, dict) and item.get("uuid")
        }


        snapshot = state if isinstance(state, dict) else {}
        self.state = copy.deepcopy(snapshot)
        self._state_base = copy.deepcopy(snapshot)
        self.updates = []


        self.read_updates = []

        self.progress_updates = []
        self.operations = []

        self._client = None
        self._done = 0
        self._total = 0
        self.outcome = {
            "uploaded": 0, "deleted": 0,
            "metadata": 0, "read_marked": 0, "read_unmarked": 0,
            "collections": 0, "skipped": 0, "failed": 0,
            "cancelled": False, "operations": self.operations,
        }



    @property
    def read_marks(self):
        return [change[0] for change in self.read_changes if change[2]]

    @property
    def read_unmarks(self):
        return [change[0] for change in self.read_changes if not change[2]]

    def _label(self, book_uuid, book_id=None, title=""):
        0




        text = (str(title or "").strip()
                or self.titles.get(str(book_uuid), ""))
        entry = (self.state.get(str(book_uuid))
                 if isinstance(self.state, dict) else None)
        if book_id is None and isinstance(entry, dict):
            book_id = entry.get("calibre_id")
        return display_title(text, book_id)

    def _add_operation(self, kind, label, status=OP_NOT_STARTED, **extra):
        operation = dict(extra, kind=kind, label=label, status=status)
        self.operations.append(operation)
        return operation

    def _finish_operation(self, operation, status, **extra):
        0
        if operation is not None:
            operation.update(extra, status=status)

    def _refresh_counts(self):
        0
        kinds, states = Counter(), Counter()
        for operation in self.operations:
            states[operation["status"]] += 1
            if operation["status"] == OP_SUCCEEDED:
                kinds[operation["kind"]] += int(operation.get("count") or 1)
        self.outcome.update(
            uploaded=kinds["upload"],
            deleted=kinds["delete"],
            metadata=kinds["metadata"],
            read_marked=kinds["read"],
            read_unmarked=kinds["unread"],
            collections=kinds["collection"],
            skipped=states[OP_SKIPPED],
            failed=states[OP_FAILED],
            cancelled=bool(self.cancelled))

    def _fail(self, operation, exc, fatal=False):
        0







        detail = sanitize_error(exc, account_secrets(self.account_name) + (
            self._client.access if self._client else None,))
        self._finish_operation(operation, OP_FAILED, error=detail)
        log_warning("Schritt gescheitert (%s): %s"
                    % ((operation or {}).get("label") or "?", detail))
        if fatal and isinstance(exc, TolinoAuthError):
            raise exc

    def _checkpoint(self):
        0
        if self.cancelled:
            raise _SyncCancelled()

    def _advance(self, text=None):
        0
        self._done += 1
        if text is not None:
            self.progress.emit(self._done, self._total, text)

    def _step(self, operation, text, action, finish=None):
        0







        self._checkpoint()
        self.progress.emit(self._done, self._total, text)
        try:
            result = action()
        except Exception as exc:
            self._fail(operation, exc, fatal=True)
            return False, None
        if finish is None:
            self._finish_operation(operation, OP_SUCCEEDED)
        else:
            finish(result)
        return True, result

    def _persist_state(self):
        0






        if not self.account_name:
            return
        try:
            stored = save_state(self.account_name, self.state,
                                self._state_base)
            detail = ""
        except Exception as exc:
            stored, detail = False, sanitize_error(
                exc, account_secrets(self.account_name))
        if not stored:
            raise TolinoError(
                "Der Sync-Zwischenstand konnte nicht gespeichert werden. "
                "Bereits durchgeführte Cloud-Änderungen bleiben bestehen; "
                "bitte vor einem erneuten Lauf den Cloud-Bestand prüfen.",
                short=("Der Sync-Zwischenstand konnte nicht gespeichert werden. "
                       "Cloud-Änderungen bleiben bestehen; bitte den Bestand "
                       "vor einem erneuten Lauf prüfen."),
                detail=detail or SETTINGS_WRITE_DETAIL)



        self._state_base = copy.deepcopy(self.state)

    def _copy_is_gone(self, deliverable_id):
        0






        try:
            cloud_ids = {
                str(record.get("tolino_id"))
                for record in self._client.inventory()
                if isinstance(record, dict)}
        except TolinoAuthError:


            raise
        except TolinoError:
            return False
        return str(deliverable_id) not in cloud_ids

    def _delete_or_skip(self, deliverable_id):
        0





        try:
            self._client.delete(deliverable_id)
        except TolinoApiError as exc:
            text = (str(exc) + " " + str(exc.detail)).casefold()
            if exc.code != "N03":
                raise
            if "http 404" in text or self._copy_is_gone(deliverable_id):
                return False
            raise
        return True

    def _finish_delete(self, operation, deleted):
        0
        self._finish_operation(
            operation, OP_SUCCEEDED if deleted else OP_SKIPPED,
            **({} if deleted else {"reason": "nicht mehr in der Cloud"}))

    def _plan_operations(self):
        0
        self.meta_ops = []
        for update in self.meta_updates:
            fields = update.fields or {}
            self.meta_ops.append((update, self._add_operation(
                "metadata", "Metadaten: %s"
                % self._label(update.book_uuid, update.book_id,
                              fields.get("title")),
                book_uuid=update.book_uuid)))
        self.upload_ops = []
        for job in self.jobs:
            self.upload_ops.append((job, self._add_operation(
                "upload", "Hochladen: %s (%s)" %
                (job.label(), job.format_name),
                book_uuid=job.book_uuid, format=job.format_name)))
        self.delete_ops = []
        for book_uuid, tolino_id in self.removals:
            self.delete_ops.append((
                book_uuid, tolino_id, self._add_operation(
                    "delete", "Aus tolino löschen: %s"
                    % self._label(book_uuid, None,
                                  self.titles.get(str(tolino_id), "")),
                    book_uuid=book_uuid, tolino_id=str(tolino_id))))
        self.read_op = (self._add_operation(
            "read", "Als gelesen markieren", count=len(self.read_marks))
            if self.read_marks else None)
        self.unread_op = (self._add_operation(
            "unread", "Als ungelesen markieren",
            count=len(self.read_unmarks)) if self.read_unmarks else None)
        self._total = sum(map(len, (self.meta_ops, self.upload_ops,
                                    self.delete_ops)))
        self._total += bool(self.read_op) + bool(self.unread_op)

    def _remove_replaced_copy(self, job):
        0
        if not job.old_id:
            return
        operation = self._add_operation(
            "delete", "Alte Kopie löschen: %s" % job.label(),
            book_uuid=job.book_uuid)
        try:
            deleted = self._delete_or_skip(job.old_id)
        except Exception as exc:
            self._fail(operation, exc, fatal=True)
        else:
            self._finish_delete(operation, deleted)

    def _run_deletions(self):
        0
        for book_uuid, tolino_id, operation in self.delete_ops:
            label = self._label(book_uuid, None,
                                self.titles.get(str(tolino_id), ""))
            ok, deleted = self._step(
                operation, "Lösche aus tolino: %s" % label,
                partial(self._delete_or_skip, tolino_id),
                finish=partial(self._finish_delete, operation))
            if not ok:
                self._advance()
                continue
            entry = self.state.get(book_uuid)
            recorded = (str(entry.get("tolino_id") or "")
                        if isinstance(entry, dict) else "")
            if not recorded or recorded == str(tolino_id):
                if isinstance(entry, dict) and entry.get("calibre_id") is not None:
                    self.updates.append((entry.get("calibre_id"), ""))
                self.state.pop(book_uuid, None)
                self._persist_state()
            self._advance("Erledigt: %s" % label if deleted else None)

    def _drop_replaced_read_changes(self):
        0





        kept = []
        for change in self.read_changes:
            tolino_id, _book_id, _wanted, book_uuid = change
            if book_uuid:
                entry = self.state.get(book_uuid)
                recorded = (str(entry.get("tolino_id") or "").strip()
                            if isinstance(entry, dict) else "")
                if recorded != tolino_id:
                    continue
            kept.append(change)
        self.read_changes = kept

    def _run_read_marks(self, read_op, unread_op):
        0
        self._drop_replaced_read_changes()
        actions = (
            (read_op, self.read_marks, True, "Als gelesen markiert"),
            (unread_op, self.read_unmarks, False, "Als ungelesen markiert"),
        )
        for operation, book_ids, finished, done_text in actions:
            if operation is None:
                continue
            operation["count"] = len(book_ids)
            if not book_ids:

                self._finish_operation(operation, OP_SKIPPED,
                                       reason="Kopie ersetzt oder gelöscht")
                self._advance()
                continue
            ok, _result = self._step(
                operation, operation["label"],
                partial(self._client.mark_read_many, book_ids,
                        finished=finished))
            if ok:
                stored = False
                for _tolino, book_id, wanted, book_uuid in self.read_changes:
                    if wanted is not finished:
                        continue
                    if book_id is not None:
                        self.read_updates.append((book_id, finished))
                    stored = self._store_read_state(book_uuid, finished) or stored
                if stored:
                    self._persist_state()
                self.progress.emit(self._done, self._total, done_text)
            self._advance()

    def _store_read_state(self, book_uuid, finished):
        0
        key = valid_book_uuid(book_uuid)
        if not key:
            return False
        entry = state_entry(self.state, key, create=True)
        reading = reading_state(entry)
        if reading.get("read") is bool(finished):
            return False
        reading["read"] = bool(finished)
        return True

    def _load_collection_pairs(self, collection_ops):
        0
        try:
            return self._client.collection_pairs()
        except Exception as exc:


            for _book, _tolino, _series, operation in collection_ops:
                self._fail(operation, exc, fatal=True)


                self._advance("Fehlgeschlagen: %s"
                              % (operation.get("label") or "Sammlung"))
            return None

    def _plan_collection_operations(self):
        0
        self.collection_ops = []
        for book_uuid, tolino_id, series in plan_collection_updates(
                self.series_map, self.state):
            self.collection_ops.append((
                book_uuid, tolino_id, series,
                self._add_operation(
                    "collection", "Serie in tolino: %s" % series,
                    book_uuid=book_uuid, series=series)))
        self._total += len(self.collection_ops)

    def _run_collections(self):
        0
        if not self.collection_ops:
            return
        known = self._load_collection_pairs(self.collection_ops)
        revision = None
        changed = False


        try:
            for book_uuid, tolino_id, series, operation in (
                    self.collection_ops if known is not None else ()):
                if (tolino_id, series) in known:
                    self._checkpoint()
                    remember_collection(self.state, book_uuid, series)
                    self._finish_operation(operation, OP_SKIPPED,
                                           reason="schon in der Cloud")
                    changed = True
                    self._advance()
                    continue

                ok, new_revision = self._step(
                    operation, "Serie in der Cloud: %s" % series,
                    partial(self._client.add_to_collection, tolino_id, series,
                            revision=revision))
                if not ok:

                    revision = None
                    self._advance()
                    continue

                revision = new_revision
                known.add((tolino_id, series))
                remember_collection(self.state, book_uuid, series)
                changed = True
                self._advance()
        finally:


            if changed:
                self._persist_state()
        self.progress.emit(self._done, self._total, "Serien geprüft")

    def _run_metadata_updates(self, operations):
        0
        changed = False
        try:
            for record, operation in operations:
                ok, _result = self._step(
                    operation,
                    "Metadaten: %s" % self._label(
                        record.book_uuid, record.book_id,
                        (record.fields or {}).get("title")),
                    partial(self._client.update_metadata, record.tolino_id,
                            record.fields))
                if not ok:
                    self._advance()
                    continue
                entry = self.state.get(record.book_uuid)
                metadata = self.metadata_by_uuid.get(record.book_uuid)
                if isinstance(entry, dict) and metadata:
                    entry["meta_verified_fp"] = metadata_fingerprint(metadata)
                self.updates.append((record.book_id, record.tolino_id))
                changed = True
                self._advance()
        finally:


            if changed:
                self._persist_state()

    def _run_uploads(self, operations):
        0
        for job, operation in operations:
            ok, new_id = self._step(
                operation,
                "Lade hoch: %s (%s)" % (job.label(), job.format_name),
                partial(self._client.upload, job.path))
            if not ok:
                self._advance("Fehlgeschlagen: %s" % job.label())
                continue


            entry = reset_copy_state(
                dict(state_entry(self.state, job.book_uuid)))
            entry.update({"tolino_id": new_id, "calibre_id": job.book_id})
            self.state[job.book_uuid] = entry
            metadata = self.metadata_by_uuid.get(job.book_uuid)
            if metadata:
                entry["content_fp"] = content_fingerprint(
                    metadata, job.format_name)
            self.updates.append((job.book_id, new_id))


            self.read_updates.append((job.book_id, None))
            self.progress_updates.append((job.book_id, None))


            self._persist_state()
            replaced = bool(job.old_id) and str(job.old_id) != str(new_id)
            if job.cover:
                try:
                    self._client.upload_cover(new_id, job.cover,
                                              image_suffix(job.cover))
                except Exception as exc:
                    cover_op = self._add_operation(
                        "cover", "Buchcover: %s" % job.label(),
                        book_uuid=job.book_uuid)
                    self._fail(cover_op, exc, fatal=True)


            if replaced:
                self._remove_replaced_copy(job)
            self._advance("Hochgeladen: %s" % job.label())

    def run(self):
        try:
            self._client = TOKEN_VAULT.login(self.account_name)
            self._plan_operations()
            self._run_metadata_updates(self.meta_ops)
            self._run_uploads(self.upload_ops)
            self._run_deletions()
            self._run_read_marks(self.read_op, self.unread_op)
            self._plan_collection_operations()
            self._run_collections()
            self._refresh_counts()
            self.completed.emit(self.updates)
        except _SyncCancelled:

            self._refresh_counts()
            self.completed.emit(self.updates)
        except Exception as exc:

            self._refresh_counts()
            message = (CANCEL_MESSAGE if str(exc) == CANCEL_MESSAGE
                       else report_error(exc, "Sync", (
                           account_secrets(self.account_name)
                           + (self._client.access
                              if self._client else None,))))
            self.failed.emit(message)
        finally:

            self._client = None


class _SyncCancelled(Exception):
    0


class LocalMetadataWorker(_CancellableWorker):
    0





    ready = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, database, context, state=None):
        _CancellableWorker.__init__(self)
        self.database = database
        self.context = context
        self.state = state

    def run(self):
        try:
            metadata = local_metadata(self.database, self.context)
        except Exception as exc:
            self.failed.emit(
                CANCEL_MESSAGE if self.cancelled else report_error(
                    exc, "Bibliothek", self.context.secrets()))
            return
        if self.cancelled:
            self.failed.emit(CANCEL_MESSAGE)
            return
        self.ready.emit({"context": self.context, "metadata": metadata,
                         "state": self.state})


class PrepareWorker(_CancellableWorker):
    0





    ready = pyqtSignal(object)
    failed = pyqtSignal(str)
    progress = pyqtSignal(str)

    def __init__(self, context, metadata, state=None, lock_timeout=5):
        _CancellableWorker.__init__(self)
        self.context = context
        self.metadata = metadata


        self.state = state
        self.lock_timeout = lock_timeout
        self.account_name = self.context.account_name

    def _stop_requested(self):
        0
        if not self.cancelled:
            return False
        self.failed.emit(CANCEL_MESSAGE)
        return True

    def _load_comparison_state(self):
        0




        original = load_state(self.state)
        working = copy.deepcopy(original)
        return working, original

    def _load_optional(self, label, loader):
        0






        try:
            return loader(), True
        except TolinoAuthError:
            raise
        except Exception as exc:
            log_warning("%s konnte nicht geladen werden: %s"
                        % (label, sanitize_error(
                            exc, self.context.secrets())))
            return None, False

    def _load_inventory(self, client):
        0
        inventory = client.inventory()
        read_ids, read_known = self._load_optional(
            "Lesestatus", client.read_ids)
        progress_by_id, progress_known = None, False
        if read_known:
            progress_by_id, progress_known = self._load_optional(
                "Lesefortschritt", client.progress_by_id)
        return inventory, read_ids, read_known, progress_by_id, progress_known

    def _build_comparison(self, state, inventory, read_ids, progress_by_id):
        0
        columns = self.context.columns
        comparison = compare_inventory(
            self.metadata, state, inventory, self.context.preferred_formats,
            read_ids=read_ids,
            read_column=bool(columns.get("read")),
            progress_by_id=progress_by_id)
        for row in comparison:
            stale_id = str(row.get("stale_cloud_id") or "").strip()
            book_uuid = str(row.get("uuid") or "").strip()
            if stale_id and book_uuid:
                entry = state.get(book_uuid)
                if isinstance(entry, dict) and str(
                        entry.get("tolino_id") or "").strip() == stale_id:



                    entry.pop("tolino_id", None)
                    reset_copy_state(entry)
        return comparison

    def run(self):
        0
        client = None
        try:
            state, original_state = self._load_comparison_state()
            self.progress.emit("Verbinde mit tolino …")
            client = TOKEN_VAULT.login(self.account_name,
                                       lock_timeout=self.lock_timeout)
            if self._stop_requested():
                return
            self.progress.emit("Lade Cloud-Bestand …")
            (inventory, read_ids, read_known,
             progress_by_id, progress_known) = self._load_inventory(client)
            if self._stop_requested():
                return
            self.progress.emit("Vergleiche Bibliothek …")
            comparison = self._build_comparison(
                state, inventory, read_ids, progress_by_id)
            if self._stop_requested():
                return
            store_reading_state(state, comparison)
            if state != original_state:



                try:
                    stored = save_state(self.account_name, state,
                                        original_state)
                except Exception:
                    stored = False
                if not stored and account_by_name(self.account_name):
                    raise TolinoError(
                        "Der Zustand des Vergleichs konnte nicht gespeichert "
                        "werden.",
                        short="Der Vergleich konnte nicht gespeichert werden.",
                        detail=SETTINGS_WRITE_DETAIL)
            self.ready.emit({
                "context": self.context,
                "metadata": self.metadata,
                "state": state,
                "comparison": comparison,
                "read_status_known": read_known,
                "progress_status_known": progress_known,
                "hardware": client.hardware,
            })
        except Exception as exc:
            if self.cancelled:
                self.failed.emit(CANCEL_MESSAGE)
                return
            self.failed.emit(report_error(
                exc, "Vorbereitung",
                self.context.secrets()
                + (client.access if client else None,)))
