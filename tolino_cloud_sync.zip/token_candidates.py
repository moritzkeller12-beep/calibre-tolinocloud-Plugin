
import json
import re
import time

from .browser_crypto import cryptojs_decrypt
from .errors import TolinoAuthError
from .jwt import issued_at as _refresh_token_iat, payload


TOKEN_VALUE_KEYS = ("refresh_token", "t_auth_token", "refreshToken", "refresh-token")
HARDWARE_VALUE_KEYS = ("hardware_id", "hardwareId", "device_id", "deviceId")


def _jwt_shaped(text):
    0
    text = str(text or "")
    parts = text.split(".")
    if len(parts) != 3 or len(text) < 80:
        return False
    return all(part and re.fullmatch(r"[A-Za-z0-9_\-]+", part)
               for part in parts)


def _candidate_age_note(candidates):
    0
    tokens = list(candidates or ())
    issued = max((_refresh_token_iat(token) or 0 for token in tokens),
                 default=0)
    if issued:
        return "Der gefundene Zugang war %d Sekunden alt." % max(
            0, int(time.time() - issued))
    if not tokens:
        return ""

    text = str(tokens[0] or "")
    parts = text.split(".")
    shape = "%d %s, %d Zeichen" % (
        len(parts), "Teil" if len(parts) == 1 else "Teile", len(text))
    if len(parts) == 3:
        shape += (", Payload ohne iat" if payload(text)
                  else ", Payload unlesbar")
    return "Alter des gefundenen Zugangs unbekannt (%s)" % shape


def _refresh_token_iat_sort_key(value):
    issued = _refresh_token_iat(value)
    return issued if issued is not None else 0.0


def _filter_live_candidates(candidates, max_age_seconds=1800):
    0
    now = time.time()
    kept = []
    for token in candidates or ():
        issued = _refresh_token_iat(token)
        if issued is None or now - issued <= max_age_seconds:
            kept.append(token)
    return kept


def _decrypt_reader_blob(value):
    0
    text = str(value or "")
    if not text or not text.lstrip().startswith("U2FsdGVk"):
        return ""
    return cryptojs_decrypt(text).strip()


def _json_field_text(value, names):
    0
    try:
        parsed = json.loads(value)
    except ValueError:
        return ""
    if not isinstance(parsed, dict):
        return ""
    for name in names:
        nested = parsed.get(name)
        if isinstance(nested, str) and nested.strip():
            return nested.strip()
    return ""


def _hardware_from_reader_blob(value):
    0
    plain = _decrypt_reader_blob(value)
    return _json_field_text(plain, HARDWARE_VALUE_KEYS) if plain else ""


def _unwrap_refresh_candidate(token, max_depth=3):
    0
    text = str(token or "")
    if not text or _jwt_shaped(text):
        return text
    current = text
    for _depth in range(max_depth):
        plain = _decrypt_reader_blob(current)
        if not plain:
            break
        if plain.startswith("{"):

            plain = _json_field_text(plain, ("refresh",) + TOKEN_VALUE_KEYS)
        if _jwt_shaped(plain):
            return plain
        if plain.startswith("U2FsdGVk"):
            current = plain
            continue
        if (len(plain) > 20 and plain.isprintable()
                and not plain.startswith(("{", "["))):
            return plain
        break
    return text


def _normalize_live_grab(grabbed):
    0






    if not isinstance(grabbed, dict):
        return grabbed
    refresh = []
    decrypt_error = None
    for token in grabbed.get("refresh") or ():
        try:
            unwrapped = _unwrap_refresh_candidate(token)
        except TolinoAuthError as exc:
            decrypt_error = decrypt_error or exc
            continue
        if unwrapped and unwrapped not in refresh:
            refresh.append(unwrapped)
    if decrypt_error is not None and not refresh:
        raise decrypt_error
    hardware = []
    for value in grabbed.get("hardware") or ():
        value = str(value or "").strip()
        if value.startswith("U2FsdGVk"):
            try:
                value = _hardware_from_reader_blob(value)
            except TolinoAuthError:

                continue
        if value and value not in hardware:
            hardware.append(value)
    if grabbed.get("refresh") == refresh and grabbed.get("hardware") == hardware:
        return grabbed
    return dict(grabbed, refresh=refresh, hardware=hardware)
