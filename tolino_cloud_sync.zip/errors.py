0                                              

                                                                    
                                        
   


class TolinoError(Exception):
    0                                                                    

                                                                        
                                                                         
                                                                          
       
    code = "E99"

    def __init__(self, message="", *args, code=None, short=None, detail=""):
        super().__init__(message, *args)
        if code:
            self.code = code
        self.short = short
        self.detail = detail


class TolinoAuthError(TolinoError):
    pass


class TolinoApiError(TolinoError):
    pass
