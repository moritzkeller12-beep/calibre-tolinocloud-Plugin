0






class TolinoError(Exception):
    0





    code = "E99"

    def __init__(self, message="", *args, code=None, short=None, detail=""):
        super().__init__(message, *args)
        if code:
            self.code = code
        self.short = short
        self.detail = detail



RELOGIN_CODES = ("A01", "B01", "B02")


def needs_new_login(message):
    0
    text = str(message or "")
    return any("(Code %s)" % code in text for code in RELOGIN_CODES)


class TolinoAuthError(TolinoError):
    pass


class TolinoApiError(TolinoError):
    pass
