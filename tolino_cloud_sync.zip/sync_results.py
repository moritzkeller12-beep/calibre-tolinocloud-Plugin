






from qt.core import QMessageBox

from calibre.gui2 import error_dialog, info_dialog
from .comparison import comparison_progress_updates, comparison_read_updates
from .config import account_by_name, load_state
from .identifiers import book_uuid, calibre_key
from .library import (library_scope, update_progress_status,
                      update_read_status, update_tolino_ids)
from .tolino import log_warning, sanitize_error
from .ui_common import (CANCEL_MESSAGE, sync_result_detail,
                        sync_result_text)


def window_gone(dialog):
    0










    visible = getattr(dialog, "isVisible", None)
    return visible is not None and not visible()


def book_key_index(dashboard):
    0





    database = getattr(getattr(dashboard, "gui", None), "current_db", None)
    api = getattr(database, "new_api", None)
    if api is None:
        return [], {}
    book_ids = list(api.all_book_ids())
    uuids = api.all_field_for("uuid", book_ids) or {}
    scope = library_scope(database)
    mapping = {}
    for book_id in book_ids:
        key = book_uuid(uuids.get(book_id))
        if key:
            mapping[key] = book_id
        else:
            mapping.setdefault(calibre_key(book_id, scope), book_id)
    return book_ids, mapping


def refresh_library_view(dashboard, book_ids):
    0
    view = getattr(getattr(dashboard, "gui", None), "library_view", None)
    model = getattr(view, "model", None)
    if callable(model):
        model = model()
    refresh = getattr(model, "refresh_ids", None)
    if callable(refresh):
        try:
            refresh(tuple(book_ids))
        except Exception as exc:
            log_warning("Calibre-Ansicht konnte nicht aktualisiert werden: %s"
                        % sanitize_error(exc))


def write_reading_updates(dashboard, read_updates, progress_updates,
                          error_label):
    0




    if not (read_updates or progress_updates):
        return 0
    try:
        database = dashboard.gui.current_db
    except Exception as exc:
        log_warning("%s: %s" % (error_label, sanitize_error(exc)))
        return 0
    written = 0
    for write, updates in ((update_read_status, read_updates),
                           (update_progress_status, progress_updates)):
        if not updates:
            continue
        try:
            written += write(database, updates)
        except Exception as exc:
            log_warning("%s: %s" % (error_label, sanitize_error(exc)))
    if written:
        book_ids = {book_id for book_id, _value
                    in read_updates + progress_updates}
        refresh_library_view(dashboard, book_ids)
    return written


def mirror_account_reading(dashboard, account_name=None):
    0
    try:
        account = account_by_name(
            account_name or getattr(dashboard, "account_name", "")) or {}
        state = load_state(account.get("state"))
        book_ids, book_ids_by_key = book_key_index(dashboard)
        if not book_ids:
            return 0


        read_updates = dict.fromkeys(book_ids)
        progress_updates = dict.fromkeys(book_ids)
        for key, entry in state.items():
            if not isinstance(entry, dict):
                continue
            book_id = book_ids_by_key.get(str(key))
            reading = entry.get("reading")
            if book_id is None or not isinstance(reading, dict):
                continue
            if isinstance(reading.get("read"), bool):
                read_updates[book_id] = reading["read"]
            progress = reading.get("progress")
            if isinstance(progress, dict) and "percent" in progress:
                progress_updates[book_id] = progress.get("percent")
        return write_reading_updates(
            dashboard, list(read_updates.items()),
            list(progress_updates.items()),
            "Lese-Spalten konnten nicht aktualisiert werden")
    except Exception as exc:
        log_warning("Lese-Spalten konnten nicht aktualisiert werden: %s"
                    % sanitize_error(exc))
        return 0


def mirror_comparison_reading(dashboard, comparison):
    0





    return write_reading_updates(
        dashboard, comparison_read_updates(comparison),
        comparison_progress_updates(comparison),
        "Lesewerte konnten nicht nach Calibre gespiegelt werden")


def _stored_id_updates(dialog, updates, account_name):
    0






    if not account_name or not updates:
        return []
    state = load_state((account_by_name(account_name) or {}).get("state"))
    _book_ids, book_ids_by_key = book_key_index(dialog)
    key_of = {}
    for key, book_id in book_ids_by_key.items():
        key_of.setdefault(book_id, key)
    found = []
    for book_id, _tolino_id in updates:
        entry = state.get(str(key_of.get(book_id)))


        found.append((book_id, entry.get("tolino_id")
                      if isinstance(entry, dict) else ""))
    return found


def persist_sync_result(dialog, updates, worker=None):
    0






    worker = worker if worker is not None else getattr(dialog, "worker", None)
    dialog_account = str(getattr(dialog, "account_name", "") or "")
    account_name = str(getattr(worker, "account_name", None) or dialog_account)
    columns = getattr(getattr(worker, "context", None), "columns", {}) or {}


    start_scope = str(getattr(getattr(worker, "context", None),
                             "library_scope", "") or "")
    if start_scope:
        try:
            current_scope = library_scope(dialog.gui.current_db)
        except Exception as exc:
            current_scope = ""
            log_warning("Bibliothek konnte nicht bestimmt werden: %s"
                        % sanitize_error(exc))
        if current_scope != start_scope:
            log_warning("Bibliothek gewechselt: Sync-Lauf abgebrochen, es "
                        "wurde nichts gespeichert.")
            return ["Bibliothek gewechselt – Lauf abgebrochen"]
    failures = []
    id_updates = _stored_id_updates(dialog, updates, account_name)
    writers = [
        ("id", "tolino-IDs",
         lambda db: update_tolino_ids(
             db, id_updates, account_name=account_name)),
    ]
    if account_name and account_name == dialog_account:
        writers.extend([
            ("read", "Lesestatus",
             lambda db: update_read_status(
                 db, list(getattr(worker, "read_updates", ()) or ()))),
            ("progress", "Lesefortschritt",
             lambda db: update_progress_status(
                 db, list(getattr(worker, "progress_updates", ()) or ()))),
        ])
    for key, label, write in writers:
        if not columns.get(key):
            continue
        try:
            write(dialog.gui.current_db)
        except Exception as exc:
            failures.append(label)
            log_warning("%s: Schreiben in Calibre fehlgeschlagen: %s"
                        % (label, sanitize_error(exc)))
    return failures


def finish_sync(dialog, updates, worker=None):
    0
    worker = worker if worker is not None else getattr(dialog, "worker", None)
    outcome = dict(getattr(worker, "outcome", None) or {})
    try:
        return outcome, persist_sync_result(dialog, updates, worker)
    finally:


        dialog.finish_thread()


def sync_cancelled_text(outcome):
    0
    result = sync_result_text(outcome, "")
    if result:
        return "Abgebrochen. " + result
    return "Abgebrochen. Es wurde nichts übertragen."


def sync_failure_heading(outcome):
    0




    succeeded = sum(int(outcome.get(key) or 0) for key in (
        "uploaded", "metadata", "read_marked", "read_unmarked",
        "collections", "deleted"))
    if succeeded:
        return "Teilweise fehlgeschlagen", "Teilweise abgeschlossen: "
    return "Fehlgeschlagen", "Fehlgeschlagen: "


def report(dialog, kind, title, text, log, detail=""):
    0




    if window_gone(dialog):
        log_warning("Fenster geschlossen; %s: %s"
                    % (log, sanitize_error(text)))
        return False
    if kind == "info":
        info_dialog(dialog, title, text, show=True, show_copy_button=False)
    elif kind == "warnung":
        QMessageBox.warning(dialog, title, text)
    else:
        error_dialog(dialog, title, text, det_msg=detail, show=True)
    return True


def report_sync(dialog, outcome, failures, message="", cancelled=False):
    0




    outcome = outcome if isinstance(outcome, dict) else {}
    detail = sync_result_detail(outcome)
    result = sync_result_text(outcome, "")
    text_message = str(message or "")


    error_message = bool(text_message) and text_message != CANCEL_MESSAGE
    cancellation = (bool(cancelled) or bool(outcome.get("cancelled"))
                    or text_message == CANCEL_MESSAGE)
    if failures:
        text = ("Nicht gespeichert: %s. Cloud-Änderungen bleiben bestehen; "
                "bitte den Bestand prüfen." % ", ".join(failures))
        if text_message:
            text = text_message + "\n\n" + text
        elif result:
            text += "\n\n" + result
        report(dialog, "fehler", "Speichern fehlgeschlagen", text,
               "Speichern fehlgeschlagen", detail)
    elif cancellation and not error_message:
        report(dialog, "info", "Abgebrochen", sync_cancelled_text(outcome),
               "Lauf abgebrochen")
    elif text_message:
        text = text_message
        if outcome.get("failed") and result:
            text += "\n\n" + result
        report(dialog, "fehler", sync_failure_heading(outcome)[0], text,
               "Sync fehlgeschlagen", detail)
    elif outcome.get("failed"):
        title, prefix = sync_failure_heading(outcome)
        report(dialog, "fehler", title, prefix + result, "Lauf fehlgeschlagen",
               detail)
    else:
        report(dialog, "info", "Fertig", sync_result_text(outcome, "Fertig"),
               "Lauf beendet")
