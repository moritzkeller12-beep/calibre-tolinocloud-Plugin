0                                               
import copy
import threading

from calibre.utils.config import JSONConfig



PREFERENCES = JSONConfig("plugins/Tolino Cloud Sync Lite")
DEFAULT_ACCOUNT_NAME = "default"
ACCOUNT_KEYS = ("partner_id", "hardware_id", "refresh_token", "state")
PREFERRED_FORMATS = "preferred_formats"
DEFAULT_ACCOUNT = {
    "name": DEFAULT_ACCOUNT_NAME,
    "partner_id": 1,
    "hardware_id": "",
    "refresh_token": "",
    "state": {},
}
_SETTINGS_LOCK = threading.RLock()


def load_state(raw):
    0                                                                       
    return raw if isinstance(raw, dict) else {}




def _account(value, fallback_name=DEFAULT_ACCOUNT_NAME, copy_state=True):
    0                                                                      
    source = value if isinstance(value, dict) else {}
    result = dict(DEFAULT_ACCOUNT)
    result.update({key: source[key] for key in ACCOUNT_KEYS if key in source})
    result["name"] = str(source.get("name") or fallback_name).strip() or fallback_name
    state = source.get("state")
    state = state if isinstance(state, dict) else {}
    result["state"] = copy.deepcopy(state) if copy_state else state
    return result


def _named_accounts(raw):
    0                                                                      
    if not isinstance(raw, list) or not raw:

        yield DEFAULT_ACCOUNT_NAME, {}
        return
    names = set()
    for index, value in enumerate(raw):
        source = value if isinstance(value, dict) else {}
        fallback = "account-%d" % (index + 1)
        base = str(source.get("name") or fallback).strip() or fallback
        name, number = base, index + 1
        while name in names:
            name, number = "%s-%d" % (base, number), number + 1
        names.add(name)
        yield name, source


def _account_summaries(raw):
    0                                                                    
    return [{"name": name,
             "partner_id": source.get("partner_id", 1),
             "hardware_id": source.get("hardware_id", ""),
             "refresh_token": source.get("refresh_token", "")}
            for name, source in _named_accounts(raw)]


def account_summary(name):
    0                                                                   
    with _SETTINGS_LOCK:
        return next((item for item in _account_summaries(
            PREFERENCES.get("accounts", None))
            if item["name"] == name), {})


def _active_name(accounts):
    0                                                                   
    names = {item["name"] for item in accounts}
    active = str(PREFERENCES.get("active_account", "") or "")
    return active if active in names else accounts[0]["name"]


def settings():
    0                                                                   
    with _SETTINGS_LOCK:
        accounts = _account_summaries(PREFERENCES.get("accounts", None))
        active = _active_name(accounts)
        current = next(item for item in accounts if item["name"] == active)
        return {
            PREFERRED_FORMATS: list(PREFERENCES.get(PREFERRED_FORMATS,
                                                    ["EPUB"])),
            "partner_id": current["partner_id"],
            "hardware_id": current["hardware_id"],
            "accounts": accounts,
            "active_account": active,
        }


def _write_account(name, values, active=None, set_active=False,
                   preferred_formats=None, create=True, allow_default=False):
    0                                                                       
    name = str(name or "").strip()
    if not name:
        return False
    values = values if isinstance(values, dict) else {}
    raw = PREFERENCES.get("accounts", None)
    records = list(raw) if isinstance(raw, list) else []
    named = list(_named_accounts(records))
    target = next((index for index, (stored, _source) in enumerate(named)
                   if records and stored == name), None)
    if target is not None:
        record = dict(named[target][1])
        record.update({key: values[key] for key in ACCOUNT_KEYS
                       if key in values})
        records[target] = _account(record, name,
                                   copy_state="state" in values)
    else:
        virtual_default = not records and name == DEFAULT_ACCOUNT_NAME
        if not (create or (allow_default and virtual_default)):
            return False
        records.append(_account(dict(values, name=name), name))
    PREFERENCES["accounts"] = records
    if set_active:
        current = _active_name([{"name": stored} for stored, _ in named])
        chosen = str(active or current or "")
        names = {stored for stored, _ in _named_accounts(records)}
        PREFERENCES["active_account"] = chosen if chosen in names else name
    elif not PREFERENCES.get("active_account"):
        PREFERENCES["active_account"] = name
    if preferred_formats is not None:
        PREFERENCES[PREFERRED_FORMATS] = list(preferred_formats)
    PREFERENCES.commit()
    return True


def save_account(name, values, active=None, preferred_formats=None,
                 create=True):
    0                                                                

                                                                           
                                                              
                                                                   
                                                                     
                   
       
    with _SETTINGS_LOCK:
        return _write_account(
            name, values, active=active, set_active=True,
            preferred_formats=preferred_formats, create=create,
            allow_default=True)


def account_by_name(name):
    0                                                                   
    with _SETTINGS_LOCK:
        for stored, value in _named_accounts(
                PREFERENCES.get("accounts", None)):
            if stored == name:
                return _account(dict(value, name=stored), stored)
    return {}


def _update_account(name, values, allow_default=False):
    0                                                                           
    with _SETTINGS_LOCK:
        return _write_account(
            name, values, create=False, allow_default=allow_default)


def set_active_account(name):
    0                                                                 
    with _SETTINGS_LOCK:
        names = [stored for stored, _ in _named_accounts(
            PREFERENCES.get("accounts", None))]
        if name not in names:
            return False
        PREFERENCES["active_account"] = name
        PREFERENCES.commit()
        return True


def save_credentials(account_name, refresh_token, hardware):
    0                                                                 

                                                                          
                                                                 
       
    return _update_account(account_name, {
        "refresh_token": refresh_token,
        "hardware_id": hardware,
    }, allow_default=True)


def save_refresh_token(account_name, token):
    0                                                             

                                                                
                                                                      
                                                                         
                                                      
       
    token = str(token or "").strip()
    if token:
        return _update_account(account_name, {"refresh_token": token},
                               allow_default=True)
    return False


def clear_refresh_token(account_name):
    0                                                                     
    return _update_account(account_name, {"refresh_token": ""})


def save_hardware_id(account_name, hardware):
    0                                                                          
    return _update_account(account_name,
                           {"hardware_id": str(hardware or "")},
                           allow_default=True)


def account_secrets(account_name):
    0                                                             
    token = str(account_summary(account_name).get("refresh_token") or "").strip()
    return (token,) if token else ()


def remove_account(name):
    0                                                            
    with _SETTINGS_LOCK:
        raw = PREFERENCES.get("accounts", None)
        named = list(_named_accounts(raw))
        remaining = [(stored, source) for stored, source in named
                     if stored != name]
        if not remaining or len(remaining) == len(named):
            return False
        active = _active_name([{"name": stored} for stored, _ in named])
        PREFERENCES["accounts"] = [source for _stored, source in remaining]
        PREFERENCES["active_account"] = (
            active if active != name else remaining[0][0])
        PREFERENCES.commit()
        return True
