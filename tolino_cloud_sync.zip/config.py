0                                               
import copy
import threading

from calibre.utils.config import JSONConfig



PREFERENCES = JSONConfig("plugins/Tolino Cloud Sync Lite")
DEFAULT_ACCOUNT_NAME = "default"
ACCOUNT_KEYS = ("partner_id", "hardware_id", "refresh_token", "state")
PREFERRED_FORMATS = "preferred_formats"
DEFAULT_ACCOUNT = {
    "name": DEFAULT_ACCOUNT_NAME,
    "partner_id": 1,
    "hardware_id": "",
    "refresh_token": "",
    "state": {},
}
_SETTINGS_LOCK = threading.RLock()


def load_state(raw):
    0                                                                       
    return raw if isinstance(raw, dict) else {}




def _account(value, fallback_name=DEFAULT_ACCOUNT_NAME):
    0                                                                      
    source = value if isinstance(value, dict) else {}
    result = dict(DEFAULT_ACCOUNT)
    result.update({key: source[key] for key in ACCOUNT_KEYS if key in source})
    result["name"] = str(source.get("name") or fallback_name).strip() or fallback_name
    state = source.get("state")
    result["state"] = copy.deepcopy(state) if isinstance(state, dict) else {}
    return result


def _account_list(raw):
    0                                                                               
    if not isinstance(raw, list) or not raw:
        return [_account({}, DEFAULT_ACCOUNT_NAME)]
    accounts = [_account(item, "account-%d" % (index + 1))
                for index, item in enumerate(raw)]
    names = set()
    for index, item in enumerate(accounts):
        base, number = item["name"], index + 1
        while item["name"] in names:
            item["name"] = "%s-%d" % (base, number)
            number += 1
        names.add(item["name"])
    return accounts


def _accounts_and_active():
    0                                                                

                                                                        
                                                                      
                                                                          
       
    accounts = _account_list(PREFERENCES.get("accounts", None))
    names = {item["name"] for item in accounts}
    active = str(PREFERENCES.get("active_account", "") or "")
    if active not in names:
        active = accounts[0]["name"]
    return accounts, active


def settings():
    0                                                                    
    with _SETTINGS_LOCK:
        accounts, active = _accounts_and_active()
        current = next(item for item in accounts if item["name"] == active)

        return {
            PREFERRED_FORMATS: copy.deepcopy(
                PREFERENCES.get(PREFERRED_FORMATS, ["EPUB"])),
            "partner_id": copy.deepcopy(current["partner_id"]),
            "hardware_id": copy.deepcopy(current["hardware_id"]),
            "accounts": accounts,
            "active_account": active,
        }


def save_account(name, values, active=None, preferred_formats=None):
    0                                                                

                                                                           
                                                          
       
    with _SETTINGS_LOCK:
        accounts, current_active = _accounts_and_active()
        existing = next((item for item in accounts if item["name"] == name), {})
        merged = dict(existing)
        merged.update(values)
        normalized = _account(dict(merged, name=name), name)
        for index, item in enumerate(accounts):
            if item["name"] == name:
                accounts[index] = normalized
                break
        else:
            accounts.append(normalized)
        chosen = active or current_active
        if chosen not in {item["name"] for item in accounts}:
            chosen = normalized["name"]
        PREFERENCES["accounts"] = accounts
        PREFERENCES["active_account"] = chosen
        if preferred_formats is not None:
            PREFERENCES[PREFERRED_FORMATS] = copy.deepcopy(
                list(preferred_formats))
        PREFERENCES.commit()


def account_by_name(name):
    0                                                                         
    return next((item for item in settings()["accounts"]
                 if item["name"] == name), {})


def set_active_account(name):
    0                                                                 
    if not account_by_name(name):
        return
    save_account(name, {}, active=name)


def save_credentials(account_name, refresh_token, hardware):
    0                                                                 

                                                                          
                                                                 
       
    if not account_name:
        return
    save_account(account_name, {
        "refresh_token": refresh_token,
        "hardware_id": hardware,
    })


def save_refresh_token(account_name, token):
    0                                                             

                                                                
                                                                      
                                                                         
                                                      
       
    token = str(token or "").strip()
    if account_name and token and account_by_name(account_name):
        save_account(account_name, {"refresh_token": token})


def clear_refresh_token(account_name):
    0                                                                     
    if not account_name or not account_by_name(account_name):
        return False
    save_account(account_name, {"refresh_token": ""})
    return True


def save_hardware_id(account_name, hardware):
    0                                                                          
    if account_name:
        save_account(account_name, {"hardware_id": str(hardware or "")})


def account_secrets(account_name):
    0                                                             
    account = account_by_name(account_name) or {}
    token = str(account.get("refresh_token") or "").strip()
    return (token,) if token else ()


def remove_account(name):
    0                                                            
    with _SETTINGS_LOCK:
        accounts, active = _accounts_and_active()
        remaining = [item for item in accounts if item["name"] != name]
        if not remaining or len(remaining) == len(accounts):
            return False
        PREFERENCES["accounts"] = remaining
        PREFERENCES["active_account"] = (
            active if active != name else remaining[0]["name"])
        PREFERENCES.commit()
        return True
