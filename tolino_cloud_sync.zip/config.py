
import contextlib
import copy
import json
import os
import threading

from calibre.utils.config import JSONConfig

from .comparison import COPY_BOUND_FIELDS



PREFERENCE_NAMESPACE = "plugins/Tolino Cloud Sync Lite"
PREFERENCES = JSONConfig(PREFERENCE_NAMESPACE)
DEFAULT_ACCOUNT_NAME = "default"
ACCOUNT_KEYS = ("partner_id", "hardware_id", "refresh_token", "state")
PREFERRED_FORMATS = "preferred_formats"
DEFAULT_ACCOUNT = {
    "name": DEFAULT_ACCOUNT_NAME,
    "partner_id": 1,
    "hardware_id": "",
    "refresh_token": "",
    "state": {},
}
_SETTINGS_LOCK = threading.RLock()
_UNSET = object()



_LOCK_STATE = threading.local()


def _lock_handle(handle):
    0




    try:
        if os.name == "nt":
            import msvcrt
            handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
    except ImportError:
        pass


@contextlib.contextmanager
def _settings_file_lock():
    0






    depth = getattr(_LOCK_STATE, "depth", 0)
    if depth:
        _LOCK_STATE.depth = depth + 1
        try:
            yield
        finally:
            _LOCK_STATE.depth = depth
        return
    handle, path = None, getattr(PREFERENCES, "file_path", None)
    if path:
        try:
            handle = open(str(path) + ".lock", "a+b")
            if os.fstat(handle.fileno()).st_size == 0:


                handle.write(b"\0")
                handle.flush()
        except OSError:
            if handle is not None:
                handle.close()
            handle = None
    try:
        if handle is not None:
            _lock_handle(handle)
        _LOCK_STATE.depth = 1
        yield
    finally:
        _LOCK_STATE.depth = 0
        if handle is not None:
            handle.close()


@contextlib.contextmanager
def settings_write_lock():
    0
    with _SETTINGS_LOCK, _settings_file_lock():
        yield


def _reload():
    0














    with _SETTINGS_LOCK:
        path = getattr(PREFERENCES, "file_path", None)
        if not path:
            return True
        try:
            with open(path, "rb") as handle:
                raw = handle.read()
        except FileNotFoundError:


            return True
        except OSError:



            return False
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            data = None
        if not isinstance(data, dict):



            return False


        dict.clear(PREFERENCES)
        dict.update(PREFERENCES, data)
        return True


def _commit():
    0
    PREFERENCES.commit()


def load_state(raw):
    0
    return raw if isinstance(raw, dict) else {}




def _account(value, fallback_name=DEFAULT_ACCOUNT_NAME, copy_state=True):
    0
    source = value if isinstance(value, dict) else {}
    result = dict(DEFAULT_ACCOUNT)
    result.update({key: source[key] for key in ACCOUNT_KEYS if key in source})
    result["name"] = str(source.get("name") or fallback_name).strip() or fallback_name
    state = source.get("state")
    state = state if isinstance(state, dict) else {}
    result["state"] = copy.deepcopy(state) if copy_state else state
    return result


def _named_accounts(raw):
    0
    if not isinstance(raw, list) or not raw:

        yield DEFAULT_ACCOUNT_NAME, {}
        return
    names = set()
    for index, value in enumerate(raw):
        source = value if isinstance(value, dict) else {}
        fallback = "account-%d" % (index + 1)
        base = str(source.get("name") or fallback).strip() or fallback
        name, number = base, index + 1
        while name in names:
            name, number = "%s-%d" % (base, number), number + 1
        names.add(name)
        yield name, source


def _account_summaries(raw):
    0
    return [{"name": name,
             "partner_id": source.get("partner_id", 1),
             "hardware_id": source.get("hardware_id", ""),
             "refresh_token": source.get("refresh_token", "")}
            for name, source in _named_accounts(raw)]


def account_summary(name):
    0
    with _SETTINGS_LOCK:
        _reload()
        return next((item for item in _account_summaries(
            PREFERENCES.get("accounts", None))
            if item["name"] == name), {})


def _active_name(accounts):
    0
    names = {item["name"] for item in accounts}
    active = str(PREFERENCES.get("active_account", "") or "")
    return active if active in names else accounts[0]["name"]


def settings_readable():
    0




    with _SETTINGS_LOCK:
        return _reload()


def settings():
    0
    with _SETTINGS_LOCK:
        _reload()
        accounts = _account_summaries(PREFERENCES.get("accounts", None))
        active = _active_name(accounts)
        current = next(item for item in accounts if item["name"] == active)
        return {
            PREFERRED_FORMATS: list(PREFERENCES.get(PREFERRED_FORMATS,
                                                    ["EPUB"])),
            "partner_id": current["partner_id"],
            "hardware_id": current["hardware_id"],
            "accounts": accounts,
            "active_account": active,
        }


def _write_account(name, values, *, active=_UNSET, preferred_formats=None,
                   create=True, allow_virtual_default=False, reload=True):
    0









    with _SETTINGS_LOCK, _settings_file_lock():
        name = str(name or "").strip()
        if not name or not isinstance(values, dict):
            return False




        if reload and not _reload():
            return False
        raw = PREFERENCES.get("accounts", None)
        records = list(raw) if isinstance(raw, list) else []
        index = None
        if records:
            for position, (stored, _source) in enumerate(
                    _named_accounts(records)):
                if stored == name:
                    index = position
                    break
        previous_active = ""
        if active is not _UNSET:
            previous_active = _active_name(
                [{"name": stored}
                 for stored, _source in _named_accounts(records)])
        if index is None:
            if not (create or (allow_virtual_default and not records
                               and name == DEFAULT_ACCOUNT_NAME)):
                return False
            records.append(_account(dict(values, name=name), name))
        else:
            record = dict(records[index])
            record.update({key: values[key] for key in ACCOUNT_KEYS
                           if key in values})
            records[index] = _account(record, name,
                                      copy_state="state" in values)
        changes = {"accounts": records}
        if active is not _UNSET:
            names = {stored for stored, _source in _named_accounts(records)}
            chosen = str(active or previous_active or "").strip()
            changes["active_account"] = chosen if chosen in names else name
        elif not PREFERENCES.get("active_account"):
            changes["active_account"] = name
        if preferred_formats is not None:
            changes[PREFERRED_FORMATS] = list(preferred_formats)



        PREFERENCES.update(changes)
        _commit()
        return True


def save_account(name, values, active=None, preferred_formats=None,
                 create=True):
    0







    with _SETTINGS_LOCK:
        return _write_account(
            name, values, active=active,
            preferred_formats=preferred_formats, create=create,
            allow_virtual_default=True)


def _copy_changed(before, entry):
    0
    old = str(before.get("tolino_id") or "").strip()
    new = str(entry.get("tolino_id") or "").strip()
    return old != new


def _merged_entry(before, entry, current):
    0



    merged = dict(current) if isinstance(current, dict) else {}
    changes = (set(entry) if not isinstance(before, dict) else
               {field for field in set(before) | set(entry)
                if before.get(field) != entry.get(field)})
    if "tolino_id" in changes:
        result_copy = entry
    else:
        result_copy = merged
    if _copy_changed(merged, result_copy):
        for field in COPY_BOUND_FIELDS:
            merged.pop(field, None)
    local_matches = not _copy_changed(entry, result_copy)
    local_replaced = isinstance(before, dict) and _copy_changed(before, entry)
    for field in changes:
        if field in COPY_BOUND_FIELDS and (
                not local_matches or (local_replaced and field not in entry)):

            continue
        if field in entry:
            merged[field] = entry[field]
        else:
            merged.pop(field, None)
    return merged


def _merge_state(stored, base, state):
    0





    merged = dict(stored)
    for key in set(base) - set(state):
        merged.pop(key, None)
    for key, entry in state.items():
        current = merged.get(key)
        if isinstance(entry, dict):
            entry = _merged_entry(base.get(key), entry, current)
            if current is None and not entry:
                continue
        merged[key] = entry
    return merged


def save_state(account_name, state, base):
    0






    with _SETTINGS_LOCK, _settings_file_lock():
        if not _reload():
            return False
        source = _account_record(account_name)
        if source is None:
            return False
        stored = source.get("state")
        stored = stored if isinstance(stored, dict) else {}
        merged = _merge_state(stored, base, state)
        if merged == stored:

            return True


        return _write_account(account_name, {"state": merged}, create=False,
                              allow_virtual_default=True, reload=False)


def _account_record(name):
    0
    for stored, source in _named_accounts(PREFERENCES.get("accounts", None)):
        if stored == name:
            return source
    return None


def account_by_name(name):
    0
    with _SETTINGS_LOCK:
        _reload()
        source = _account_record(name)
    return _account(dict(source, name=name), name) if source is not None else {}


def _update_account(name, values, allow_virtual_default=True):
    0




    with _SETTINGS_LOCK:
        return _write_account(
            name, values, create=False,
            allow_virtual_default=allow_virtual_default)


def _stored_token(account_name):
    0
    return str(
        account_summary(account_name).get("refresh_token") or "").strip()


def set_active_account(name):
    0
    with _SETTINGS_LOCK, _settings_file_lock():


        if not _reload():
            return False
        names = [stored for stored, _ in _named_accounts(
            PREFERENCES.get("accounts", None))]
        if name not in names:
            return False
        PREFERENCES["active_account"] = name
        _commit()
        return True


def save_credentials(account_name, refresh_token, hardware, partner_id=None):
    0




    values = {"refresh_token": refresh_token, "hardware_id": hardware}
    if partner_id:
        values["partner_id"] = partner_id
    return _update_account(account_name, values)


def save_refresh_token(account_name, token):
    0






    token = str(token or "").strip()
    if token:
        return _update_account(account_name, {"refresh_token": token})
    return False


def clear_refresh_token_if_unchanged(account_name, rejected_token):
    0








    rejected = str(rejected_token or "").strip()



    with _SETTINGS_LOCK, _settings_file_lock():
        current = _stored_token(account_name)
        if rejected and current and current != rejected:
            return False

        return _update_account(account_name, {"refresh_token": ""},
                               allow_virtual_default=False)


def save_hardware_id(account_name, hardware):
    0
    return _update_account(account_name, {"hardware_id": str(hardware or "")})


def account_secrets(account_name):
    0
    token = _stored_token(account_name)
    return (token,) if token else ()


def remove_account(name):
    0
    with _SETTINGS_LOCK, _settings_file_lock():
        if not _reload():
            return False
        raw = PREFERENCES.get("accounts", None)
        named = list(_named_accounts(raw))
        remaining = [(stored, source) for stored, source in named
                     if stored != name]
        if not remaining or len(remaining) == len(named):
            return False
        active = _active_name([{"name": stored} for stored, _ in named])
        PREFERENCES.update({
            "accounts": [source for _stored, source in remaining],
            "active_account": (active if active != name else remaining[0][0]),
        })
        _commit()
        return True
