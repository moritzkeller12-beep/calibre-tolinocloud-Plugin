# Änderungen

## Unveröffentlicht

- Token-Erneuerungen laufen bei normalem Login und bei Relogin unter derselben prozessübergreifenden Dateisperre wie das Speichern der Rotation. Die Schreibbarkeitsprüfung erwirbt diesen Lock selbst und blockiert nur noch dann, wenn tatsächlich ein Refresh-Token getauscht werden muss — ein noch gültiger Access-Token funktioniert auch bei nicht beschreibbaren Einstellungen.
- Unter Windows wartet die Sperrdatei jetzt auch dann weiter, wenn eine andere Instanz sie länger als zehn Sekunden hält, statt die Anmeldung mit einem Sperrfehler abzubrechen.
- Anmeldung bleibt länger gültig: der Keep-alive richtet sich nach der Laufzeit des gespeicherten Refresh-Tokens (ein Fünftel Vorlauf, höchstens alle 45, mindestens alle 5 Minuten) und beginnt mit einer sofortigen Prüfung statt nach einer vollen Wartezeit; Konten mit noch gültigem Access-Token werden übersprungen.
- Ein gültiger Access-Token wird mit Ablaufzeit gespeichert. Ein Start innerhalb dieser Zeit tauscht nicht und verbraucht damit keine Rotation des Einmal-Tokens.
- Die Gültigkeit wird gegen `expires_in` **und** die `iat`/`exp`-Claims gerechnet; weicht die lokale Uhr stark ab, gilt die relative Laufzeit (Warnung im Log) statt eines scheinbar ewig gültigen oder sofort abgelaufenen Tokens.
- Beim Erneuern wird kein hartkodierter Scope mehr mitgeschickt, sondern der Scope des ausgestellten Tokens (RFC 6749, §6); ein abweichender Wert konnte die Erneuerung mit `invalid_scope` scheitern lassen.
- Nach `invalid_grant`/`reuse exceeded` wird einmal der inzwischen gespeicherte Token versucht, bevor die Ablehnung gilt; gelöscht wird weiterhin nur der wirklich abgelehnte Token. Ein per 401 oder Ablehnung verworfener Access-Token verschwindet auch aus den Einstellungen.
- Einstellungsdatei und Sperrdatei werden auf `0600` gesetzt (POSIX).
- Neu: `tools/token_refresh.py` erneuert fällige Konten ohne geöffnetes Calibre (systemd-Timer, Cron, Aufgabenplanung) — siehe README.

## 0.1.09

- Esc schliesst das Dashboard wie das Fensterkreuz über `closeEvent`: ein laufender Worker wird abgebrochen, die sichtbaren Einstellungen werden noch gesichert. Schlägt das Sichern fehl, bleibt das Fenster offen und meldet den Fehler, statt die Eingaben zu verlieren.
- Reine Straffung ohne Verhaltensänderung: tote Status- und Gruppenvergleiche sowie ein unerreichbarer Sondenstatus im Browser-Finder entfernt, doppelte Sortierschlüssel zusammengefasst und ein doppelter Test gestrichen (363 → 362 Tests bei gleicher Abdeckung). Die CI prüft zusätzlich Python 3.10.

## 0.1.08

- Nach einem abgelehnten Zugang (A01/B01/B02) steht in der Statuszeile «Anmeldung abgelehnt – bitte neu anmelden.» statt weiter «Angemeldet.»; dasselbe gilt, wenn beim optionalen Lesestatus die Anmeldung abgelehnt wird. Gewöhnliche Fehler dieser Abrufe bleiben «unbekannt».
- «Speichern und schliessen» übernimmt einen eingetippten Token; Enter speichert, statt die Browser-Anmeldung zu starten. Ist kein Buchhändler erkennbar, bleibt das Fenster offen, damit die Eingabe nicht verloren geht.
- Jeder Spalten-Knopf prüft und meldet nur seine eigene Calibre-Spalte. Neue Spalten entstehen ausschliesslich über Calibres `create_custom_column`; danach fordert die Oberfläche zum Neustart auf, und ein zweiter Klick legt nichts doppelt an. `library_scope()` unterscheidet Bibliotheken ohne `library_id` über den `dbpath`, und `#tolino_id` bleibt eine rein informative Spiegelspalte.
- Nach einem Upload werden Lesestatus und Fortschritt der ersetzten Kopie geleert; ein gleichzeitig gewählter Lesestatus geht nicht mehr an die alte, dabei gelöschte Kopie. Beide Spalten werden getrennt geschrieben, damit ein Fehler den anderen nicht blockiert.
- Ein nicht gespeicherter Zwischenstand bricht den Sync ab, statt die ersetzte Cloud-Kopie zu löschen; ein nicht gespeicherter Token, eine nicht gespeicherte Anmeldung, nicht gespeicherte Einstellungen, ein fehlgeschlagener Sync-Zustand, eine nicht gespeicherte Geräte-ID, ein nicht gespeicherter Buchhändler, eine nicht gespeicherte Abmeldung und ein nicht angelegtes oder nicht umschaltbares Konto melden jetzt einen Fehler, statt Erfolg vorzutäuschen. Ein eingetippter Token bleibt bei einem Schreibfehler im Feld stehen, und ein nicht gesicherter Stand hält das Einstellungsfenster offen.
- Bricht ein Lauf mitten in den Metadaten- oder Serienänderungen ab (Abbruch oder abgelehnter Zugang), sind die bereits bestätigten Änderungen trotzdem gesichert; das Buch steht beim nächsten Vergleich nicht wieder auf «changed».
- Alte `#tolino_id`- und `dbpath`-Migrationspfade entfallen; Config-Speicher, Konten und Tokens bleiben unverändert.
- Änderungen an der Einstellungsdatei (zweites Calibre-Fenster, anderes Konto) sind im laufenden Programm sofort sichtbar; halb geschriebene oder nicht lesbare Stände werden nie übernommen, und ein Schreibvorgang bricht dann ab, statt Daten zu verlieren. Gleichzeitige Schreibvorgänge zweier Calibre-Prozesse serialisiert eine Sperrdatei neben der Einstellungsdatei; scheitert das Sperren selbst, bricht der Schreibvorgang ab, statt ungesperrt fortzufahren. Lässt sich die Sperrdatei nicht anlegen, bleibt es beim prozesslokalen Lock.
- Endet der Flatpak-/Snap-Wrapper eines Anmeldefensters vor seinem Browserkind, gilt der DevTools-Port weiterhin als belegt, bis er nicht mehr antwortet. Der DevTools-WebSocket prüft beim Verbindungsaufbau `Sec-WebSocket-Accept` sowie `Upgrade`/`Connection`; eine fremde HTTP-Antwort gilt nicht mehr als offene Verbindung.
- Datenkonsistenz: Aufeinanderfolgende Läufe überschreiben keine fremden Zuordnungen mehr — Vorbereitung und Sync sichern über dieselbe Regel feldweise nur ihre eigenen Änderungen gegen den gespeicherten Stand (ein Lesevorgang je Sicherung), und der Worker sichert danach seinen neuen Ausgangsstand; den Abschlusszustand schreiben sie selbst, statt ihn am Ende zu wiederholen. Ein unvollständiger Cloud-Bestand oder eine unvollständige Markierungs-Antwort bricht mit einem Hinweis ab, statt Zuordnungen zu löschen oder alles als ungelesen zu werten; ein Abbruch meldet genau ein Ergebnis; ein Kontowechsel räumt den Fortschritt des vorherigen Kontos; eine neue Cloud-ID erbt weder Lesestatus noch Sammlungen noch Metadatenbestätigung der alten Kopie — auch dann nicht, wenn diese zuerst aus der Cloud verschwunden war. Beim Download überschreibt eine nachträglich angepasste Dateiendung keine vorhandene Datei ohne Rückfrage.
- Der Code ist gebündelt und gestrafft: eine Planungsdatei statt drei, zwei UUID-Helfer statt vier, ein Job-Typ statt zweier, ein eigenes `jwt.py` statt einer privaten Funktion über Modulgrenzen und direkte `qt.core`-Importe statt einer Re-Export-Liste. Verhalten unverändert.
- Weiter gestrafft ohne Verhaltensänderung: drei statt fünf Kennungs-Helfer im Bestand, eine Funktion statt drei für die Einstellungsdatei, eine Endpunkt-Prüfung statt zweier Warteschleifen, benannte statt indizierte Aktionsspalten, abgeleitete statt doppelt gepflegte Lesestatus-Listen, ein gemeinsamer Dialog-Mitschnitt in den Berichtstests. Die Zeitgrenzen im Anmeldefenster laufen jetzt über die monotone Uhr; ein Uhrsprung verfälscht die Wartezeiten nicht mehr.

## 0.1.07

- Fehlerbehebungen und Härtung für Anmeldung, Cloud-Sync, Lesestatus und UI; keine Legacy-Pfade entfernt.

## 0.1.06

- Lesestatus und Lesefortschritt werden kontobezogen gespeichert; `#tolino_read` und `#tolino_progress` zeigen nur den Stand des aktiven Kontos, fehlende Werte bleiben leer. Die neue Spalte `#tolino_progress` (0–100, optional mit Position) zeigt auch Cloud-Lesestände und Gelesen-Marken; unbekannte Abrufe lassen sie unverändert, ein erfolgreicher Abruf ohne Bookmark leert sie.
- Der Vergleich extrahiert ISBNs aus tolino-Produktkennungen, ordnet unsichere Treffer konservativ zu und entfernt veraltete Cloud-IDs samt altem Lesestand.
- Der Prepare-Zustand wird vor der Migration gesichert und nur bei Änderung einmal geschrieben. Parallele Konto-Wechsel bleiben getrennt; Token-Rotation und Keep-alive sind abgesichert.
- Der Release-Build entfernt Kommentare und Docstrings; Download-, Browser- und Qt6-Randfälle sind gehärtet.
- Behebt doppelt gezeichnete Auswahlkästchen im Vergleichsfenster; der Indikator wird einmal mittig gezeichnet.

## 0.1.05

- Der Build entfernt Kommentare, behält aber Code, Kodierung und Zeilennummern.
- Zustands-, Speicher- und Anmeldefehler werden sauber gemeldet; beschädigte Zustandseinträge stoppen den Sync nicht.
- Browser-/Token-Verwaltung, Qt6-Enums, Transport und Konto-Kontext wurden gestrafft.

## 0.1.04

- `#tolino_read` ist nur noch informativ; Lesestatusänderungen werden ausschliesslich im Vergleichsfenster ausgewählt.
- Behebt Qt6-Probleme mit Spaltenbreiten und Dialogcodes; ergänzt einen PyQt6-Offscreen-Test.

## 0.1.03

- Neue Ignorieren-Spalte `#tolino_ignore` und je Calibre-Spalte ein eigener Anlegen-Knopf.
- Zugangsdaten liegen nur noch im Konto; das Token-Feld zeigt keine gespeicherten Werte an.

## 0.1.02

- Mehrkonten-Unterstützung für `#tolino_id`, gestraffte Browser-/Token-Verwaltung und Serien-Sammlungen.

## 0.1.01

- Buchdownloads im Hintergrund, zuverlässigeres Füllen von `#tolino_id` und gehärtete Download-Weiterleitungen.

## 0.1.00

- Erste Version: Abgleich von Büchern, Metadaten, Lesestatus und Serien sowie kontobezogene Anmeldung und Cloud-Downloads.
