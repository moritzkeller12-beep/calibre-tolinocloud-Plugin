0                                                                     

                                                                  
                                                                     
                                                                      
                                                                
   
from dataclasses import dataclass, field

from .config import account_secrets

DEFAULT_PREFERRED_FORMATS = ("EPUB",)


@dataclass(frozen=True)
class RunContext:
    0                                    

    account_name: str = ""
    partner_id: object = 1
    preferred_formats: tuple = DEFAULT_PREFERRED_FORMATS
    columns: dict = field(default_factory=dict)
    library_scope: str = ""

    def __post_init__(self):
        object.__setattr__(self, "account_name", str(self.account_name or ""))
        object.__setattr__(self, "partner_id", self.partner_id or 1)
        object.__setattr__(self, "preferred_formats", tuple(
            self.preferred_formats or DEFAULT_PREFERRED_FORMATS))
        object.__setattr__(self, "columns", dict(self.columns or {}))
        object.__setattr__(self, "library_scope",
                           str(self.library_scope or ""))

    @classmethod
    def from_values(cls, values, columns=None, library_scope=""):
        0                                               
        values = values if isinstance(values, dict) else {}
        return cls(
            account_name=values.get("account_name") or "",
            partner_id=values.get("partner_id", 1),
            preferred_formats=(values.get("preferred_formats")
                               or DEFAULT_PREFERRED_FORMATS),
            columns=columns or {},
            library_scope=library_scope,
        )

    def secrets(self):
        0                                                                
        return account_secrets(self.account_name)
