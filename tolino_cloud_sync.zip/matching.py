0                                                                   
import re
import unicodedata


def _text_value(value):
    0                                                                             
    if isinstance(value, (list, tuple)):
        return " ".join(_text_value(item) for item in value)
    return str(value or "")


def normalize_match_text(value):
    0                                                                             
    value = unicodedata.normalize("NFKC", _text_value(value)).casefold()
    parts = []
    for character in value:
        category = unicodedata.category(character)
        if character.isspace() or category[0] in ("P", "S"):
            parts.append(" ")
        else:
            parts.append(character)
    return re.sub(r"\s+", " ", "".join(parts)).strip()


def normalize_title(value):
    0                                                                         
    title = unicodedata.normalize("NFKC", _text_value(value)).strip()
    title = re.sub(r"\.(?:epub|pdf|mobi|azw3|azw|fb2|txt|html?)\s*$",
                   "", title, flags=re.IGNORECASE)
    return normalize_match_text(title)


def normalize_isbn(value):
    0                                                                        
    return re.sub(r"[^0-9x]+", "", _text_value(value).casefold())


def is_valid_isbn(value):
    0                                                         

                                                                         
                                           
       
    digits = normalize_isbn(value).upper()
    if len(digits) == 10:
        total = 0
        for index, character in enumerate(digits):
            if character == "X":
                if index != 9:
                    return False
                digit = 10
            elif character.isdigit():
                digit = int(character)
            else:
                return False
            total += digit * (10 - index)
        return total % 11 == 0
    if len(digits) == 13 and digits.isdigit():
        total = sum((1 if index % 2 == 0 else 3) * int(character)
                    for index, character in enumerate(digits))
        return total % 10 == 0
    return False


def isbn_from_identifier(value):
    0                                                        
                                       

                                                                           
                                                                        
                                                                   
                   
       
    text = str(value or "")
    for match in re.finditer(
            r"(?<!\d)[0-9Xx][0-9Xx\s-]{8,20}[0-9Xx](?!\d)", text):
        candidate = normalize_isbn(match.group(0))
        if len(candidate) == 13 and not candidate.startswith(("978", "979")):
            continue
        if is_valid_isbn(candidate):
            return candidate
    return ""


_AUTHOR_SEPARATORS = re.compile(r"[\W_]+")
_AUTHOR_FILLER = {"and", "und", "et", "y", "with", "mit"}


def _has_umlaut(value):
    0                                                                  
    text = str(value or "").casefold()
    return any(character in text for character in ("ä", "ö", "ü"))


def author_tokens(value, transliterate=True):
    0                                                                    

                                                                          
                                                                           
                                                                        
       
    text = str(value or "").casefold()
    for umlaut, plain in (("\u00df", "ss"), ("\u00e4", "a"), ("\u00f6", "o"),
                          ("\u00fc", "u"), ("\u0142", "l"), ("\u00f8", "o")):
        text = text.replace(umlaut, plain)
    text = unicodedata.normalize("NFKD", text)
    text = "".join(character for character in text
                   if not unicodedata.combining(character))
    if transliterate:
        text = text.replace("ae", "a").replace("oe", "o").replace("ue", "u")
    tokens = [token for token in _AUTHOR_SEPARATORS.split(text) if token]
    return tuple(sorted({token for token in tokens
                         if token not in _AUTHOR_FILLER}))


def _tokens_match(left_tokens, right_tokens):
    0                                                           
    if left_tokens == right_tokens:
        return True

    def consistent(extra, other):
        for token in extra:
            if len(token) == 1:
                if any(item.startswith(token) for item in other):
                    continue
                return False
            if any(len(item) == 1 and token.startswith(item) for item in other):
                continue
            return False
        return True

    return (consistent(set(left_tokens) - set(right_tokens), set(right_tokens))
            and consistent(set(right_tokens) - set(left_tokens),
                           set(left_tokens)))


def authors_match(left, right):
    0                                                                     

                                                                         
                                                                           
                           
       
    left_tokens = author_tokens(left, transliterate=False)
    right_tokens = author_tokens(right, transliterate=False)
    if not left_tokens or not right_tokens:
        return False
    if _tokens_match(left_tokens, right_tokens):
        return True
    if _has_umlaut(left) or _has_umlaut(right):
        return _tokens_match(author_tokens(left), author_tokens(right))
    return False


def normalized_authors(value):
    0                                       
    return " ".join(author_tokens(value))
