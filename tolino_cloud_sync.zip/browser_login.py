0                                                                  
import time

from . import cdp as cdp_module
from .tolino import (RELOGIN, RELOGIN_THEN, TolinoAuthError,
                     TolinoClient, log_info, log_warning,
                     normalize_hardware_id, sanitize_error)
from .token_candidates import (
    _candidate_age_note, _filter_live_candidates, _jwt_payload,
    _refresh_token_iat_sort_key, _normalize_live_grab,
)

LOGIN_TIMEOUT = 300


def _exchange_grabbed_token(partner_id, hardware, grabbed, fresh):
    0                                                                         




    def _is_refresh_typ(token):
        payload = _jwt_payload(token) or {}
        return str(payload.get("typ", "")).casefold() == "refresh"

    candidate = min(
        fresh,
        key=lambda token: (not _is_refresh_typ(token),
                           -_refresh_token_iat_sort_key(token)))
    hardware_candidates = [normalize_hardware_id(value)
                           for value in (grabbed.get("hardware") or ())]
    hardware_candidates = [value for value in hardware_candidates if value]
    hardware_id = hardware_candidates[0] if hardware_candidates else hardware
    client = TolinoClient(partner_id, hardware_id or "")
    client.refresh = candidate
    try:
        client._login()
    except TolinoAuthError as exc:
        raise TolinoAuthError(
            "Tolino hat den Zugang aus dem Anmeldefenster abgelehnt. "
            + RELOGIN, code="A01", detail=str(exc)) from exc
    log_info("Tolino-Token-Tausch: HTTP (Plugin).")
    return client.refresh or candidate, client.hardware or hardware_id



_NEW_TOKEN_INTERVAL = 3
_CLOSED_WINDOW_MISSES = 3
_WINDOW_CHECK_INTERVAL = 5.0


def _close_window_after_grab(progress=None):
    0                                               

                                                                        
                                                               
                                                                           
                                                             
       
    for timeout in (2, 5):
        try:
            if cdp_module.close_grabber_window(timeout=timeout):
                return True
        except Exception as exc:
            log_warning("Anmeldefenster konnte nicht geschlossen werden: %s"
                        % sanitize_error(exc))
    if progress:
        progress("Zugang übernommen – das Anmeldefenster liess sich nicht "
                 "automatisch schliessen. Bitte von Hand schliessen, damit "
                 "der Zugang gültig bleibt.")
    return False


def _raise_grab_failure(last_error, grabbed, rejected):
    0                                                     
    details = []
    if last_error:
        details.append("Letzter Fehler: " + sanitize_error(last_error))
    candidates = rejected or grabbed.get("refresh") or ()
    age_note = _candidate_age_note(candidates)
    if age_note:
        details.append(age_note)
    raise TolinoAuthError(
        "Das Anmeldefenster wurde geschlossen, weil kein gültiger Zugang "
        "gelesen werden konnte. " + RELOGIN,
        code="B02", detail="; ".join(details))


def _exchange_live_grab(partner_id, hardware, grabbed, rejected, progress=None):
    0                                                         
    fresh = [token for token in _filter_live_candidates(grabbed["refresh"])
             if token not in rejected]
    if not fresh:
        return None, ""
    if progress:
        progress("Prüfe den gelesenen Zugang bei Tolino …")
    try:
        result = _exchange_grabbed_token(partner_id, hardware, grabbed, fresh)
    except TolinoAuthError as exc:

        rejected.update(grabbed["refresh"])
        if progress:
            progress("Zugang abgelehnt – warte auf einen frischen "
                     "Zugang aus dem Web Reader …")
        return None, str(exc)
    if progress:
        progress("Zugang übernommen – das Anmeldefenster "
                 "wird geschlossen.")
    _close_window_after_grab(progress)
    return result, ""


def _raise_grab_end(window, saw_reader, grabbed, rejected, last_error):
    0                                                     
    login_page_open = (window and window.get("window")
                       and not window.get("reader_tab"))
    if login_page_open and saw_reader:

        raise TolinoAuthError(
            "Das Anmeldefenster ist offen, aber noch nicht angemeldet. "
            "Bitte dort anmelden, bis die Bücherliste lädt. " + RELOGIN_THEN,
            code="B02", detail=last_error)
    if not login_page_open:
        cdp_module.close_grabber_window()
        if saw_reader:
            _raise_grab_failure(last_error, grabbed, rejected)
    raise TolinoAuthError(
        "Zeitüberschreitung: Die Anmeldung wurde nicht abgeschlossen. "
        + RELOGIN, code="B02", detail="kein Web-Reader-Tab")


def grab_live_refresh(partner_id, hardware, timeout=300, progress=None):
    0                                                                   

                                                                          
                                                                    
                                                                      
                                                     
       
    deadline = time.monotonic() + max(0, timeout)
    cdp_module.launch_reader_window()
    if progress:
        progress("Anmeldefenster geöffnet – bitte anmelden und warten, "
                 "bis die Bücherliste lädt.")

    grabbed = {"refresh": [], "hardware": []}
    rejected = set()
    last_error = ""
    window = None
    endpoint_misses = 0
    last_window_check = -_WINDOW_CHECK_INTERVAL
    saw_reader = False

    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        more = _normalize_live_grab(cdp_module.grab_once_from_grabber(
            timeout=max(0.1, min(12, remaining))))
        if more and more.get("refresh"):
            grabbed = more
            saw_reader = True
            endpoint_misses = 0
            result, error = _exchange_live_grab(
                partner_id, hardware, grabbed, rejected, progress)
            if result is not None:
                return result
            if error:
                last_error = error

        now = time.monotonic()
        if now - last_window_check >= _WINDOW_CHECK_INTERVAL:
            last_window_check = now
            window = cdp_module.grabber_window_state()
            if window.get("window"):
                endpoint_misses = 0
                saw_reader = saw_reader or bool(window.get("reader_tab"))
            else:
                endpoint_misses += 1
                if endpoint_misses >= _CLOSED_WINDOW_MISSES:



                    if saw_reader:
                        break
                    if progress:
                        progress("Anmeldefenster geschlossen – abgebrochen.")
                    raise TolinoAuthError(
                        "Das Anmeldefenster wurde geschlossen, bevor die "
                        "Übernahme fertig war. Bitte erneut versuchen und "
                        "es offen lassen.", code="B02")

        if (progress and window and window.get("window")
                and not window.get("reader_tab")):
            progress("Im Anmeldefenster anmelden, bis die Bücherliste "
                     "lädt – der Zugang wird automatisch übernommen …")
        elif progress and not saw_reader:
            progress("Der Web Reader wird geladen …")

        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        time.sleep(min(_NEW_TOKEN_INTERVAL, remaining))

    if not window:
        window = cdp_module.grabber_window_state()
    _raise_grab_end(window, saw_reader, grabbed, rejected, last_error)
