0                                                                         

from .matching import isbn_from_identifier


_INVENTORY_CONTAINERS = ("edata", "ebook")




_INVENTORY_ID_KEYS = ("deliverableId", "deliverable_id")

_INVENTORY_ID_CONTAINERS = ("epubMetaData", "deliverable", "metadata",
                            "ebook", "edata")
def _nested_inventory_value(value, names, depth=0):
    0                                                                      

                                                                         
                                                                          
                                                                  
                                                          
       
    if isinstance(value, (list, tuple)):
        if depth >= 4:
            return ""
        for entry in value:
            found = _nested_inventory_value(entry, names, depth + 1)
            if found not in (None, "", [], {}):
                return found
        return ""
    if not isinstance(value, dict):
        return ""
    for name in names:
        found = value.get(name)
        if found not in (None, "", [], {}):
            return found
    if depth >= 4:
        return ""
    for container in _INVENTORY_ID_CONTAINERS:
        found = _nested_inventory_value(value.get(container), names, depth + 1)
        if found not in (None, "", [], {}):
            return found
    return ""


def _inventory_id_in(value, keys):
    0                                                                      
    found = _nested_inventory_value(value, keys)
    if isinstance(found, (list, tuple, dict)):
        return ""
    return str(found).strip()


def _inventory_author(value):
    if isinstance(value, dict):
        return str(value.get("name") or value.get("displayName") or "").strip()
    if isinstance(value, (list, tuple)):
        names = [_inventory_author(item) for item in value]
        return ", ".join(name for name in names if name)
    return str(value or "").strip()


def normalize_inventory_record(item):
    0                                                         

               

                                                    
                                                   

                                                                       
                                                        
                                                                     
                                        
       
    deliverable = _inventory_id_in(item, _INVENTORY_ID_KEYS)
    title = _nested_inventory_value(item, ("title", "bookTitle", "name"))
    author = _nested_inventory_value(item, ("authors", "author", "creator"))
    isbn = _nested_inventory_value(
        item, ("isbn", "ISBN", "isbn13", "isbn10"))
    if not str(isbn or "").strip():


        identifier = _nested_inventory_value(item, ("identifier",))
        isbn = isbn_from_identifier(identifier)
    return {
        "tolino_id": deliverable,
        "title": str(title or "").strip(),
        "authors": _inventory_author(author),
        "isbn": str(isbn or "").strip(),
    }


def _field_names(value):
    0                                                                
    if not isinstance(value, dict):
        return type(value).__name__
    return ", ".join(sorted(str(key) for key in value)[:10]) or "keine"


def _collect_inventory(value, records, problems, container=""):
    0                                                             

                                                                            
                                                                           
             
       
    if isinstance(value, dict):
        nested = [key for key in _INVENTORY_CONTAINERS if key in value]
        has_record_id = any(
            isinstance(value.get(key), (str, int)) and str(value.get(key)).strip()
            for key in _INVENTORY_ID_KEYS)
        if nested and not has_record_id:
            for key in nested:
                _collect_inventory(value[key], records, problems, key)
            return
        if nested:
            value = {key: item for key, item in value.items()
                     if key not in _INVENTORY_CONTAINERS}
        records.append(value)
        if not _inventory_id_in(value, _INVENTORY_ID_KEYS):
            problems.append("Datensatz ohne Kennung")
        return
    if isinstance(value, (list, tuple)):
        for entry in value:
            _collect_inventory(entry, records, problems, container)
        return
    if value is None:
        problems.append("Container %s ist leer" % (container or "?"))
        return
    problems.append("Eintrag vom Typ %s" % type(value).__name__)


def parse_inventory(data):
    0                                                                
    if not isinstance(data, dict):
        return [], ["Antwort ist kein Objekt"], False
    if "PublicationInventory" not in data:
        return ([], ["PublicationInventory fehlt (Felder: %s)"
                     % _field_names(data)], False)
    container = data["PublicationInventory"]
    if isinstance(container, dict) and not any(
            key in container for key in _INVENTORY_CONTAINERS):
        return ([], ["PublicationInventory ohne edata/ebook (Felder: %s)"
                     % _field_names(container)], False)
    if isinstance(container, (str, bytes, int, float, bool)) or container is None:
        return ([], ["PublicationInventory hat den Typ %s"
                     % type(container).__name__], False)
    raw, problems = [], []
    _collect_inventory(container, raw, problems)
    records = [normalize_inventory_record(item) for item in raw]
    return records, problems, True

