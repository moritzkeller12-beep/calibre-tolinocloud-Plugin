0                                                                      

                                                                        
                                                
   
import functools
import re

from qt.core import (QCheckBox, QComboBox, QDialog,
                     QFormLayout, QGroupBox, QHeaderView, QLabel,
                     QLineEdit, QMessageBox, QMenu,
                     QProgressBar, QPushButton, QThread,
                     QVBoxLayout, QHBoxLayout, QTableWidget,
                     QTableWidgetItem, QObject, QInputDialog,
                     QFileDialog, QStyledItemDelegate, QStyle,
                     QStyleOptionViewItem, QEvent, Qt, pyqtSignal)
from .tolino import TolinoError


__all__ = [
    "CANCEL_MESSAGE", "OP_FAILED", "OP_NOT_STARTED", "OP_SKIPPED",
    "OP_SUCCEEDED", "QCheckBox", "QComboBox", "QDialog",
    "QFileDialog", "QFormLayout", "QGroupBox", "QHBoxLayout", "QHeaderView",
    "QMenu", "QInputDialog", "QLabel", "QLineEdit", "QMessageBox", "QObject",
    "QProgressBar", "QPushButton", "QTableWidget", "QTableWidgetItem",
    "QThread", "QVBoxLayout", "QStyledItemDelegate", "QStyle",
    "QStyleOptionViewItem", "QEvent", "Qt",
    "_THREADS", "_apply_busy", "_dialog_busy",
    "LOGIN_NEXT_STEP", "_login_failure_guidance",
    "gui_guard",
    "start_worker", "_stop_thread",
    "_set_enabled",
    "_keep_thread_alive",
    "pyqtSignal",
    "sync_result_detail",
    "sync_result_text",
]


def _widget_deleted(widget):
    0                                                     

                                                                          
                                                                   
       
    try:
        import sip
    except ImportError:
        try:
            from PyQt6 import sip
        except ImportError:
            return False
    try:
        return bool(sip.isdeleted(widget))
    except (TypeError, RuntimeError):
        return False


def gui_guard(function):
    0                                                                    

                                                                         
                                                                          
                                                                            
                                                                   
       
    @functools.wraps(function)
    def guarded(*args, **kwargs):
        target = args[0] if args else None
        if target is not None and _widget_deleted(target):
            return None
        try:
            return function(*args, **kwargs)
        except RuntimeError:
            if target is not None and _widget_deleted(target):
                return None
            raise
    return guarded


CANCEL_MESSAGE = "Abgebrochen."




OP_SUCCEEDED = "succeeded"
OP_SKIPPED = "skipped"
OP_FAILED = "failed"
OP_NOT_STARTED = "not_started"



_THREADS = []


class CallWorker(QObject):
    0                                                       
    done = pyqtSignal(object)
    failed = pyqtSignal(object)

    def __init__(self, call):
        QObject.__init__(self)
        self.call = call

    def run(self):
        try:
            result = self.call()
        except Exception as exc:
            self.failed.emit(exc)
            return
        self.done.emit(result)


def start_worker(dialog, worker, thread, thread_name, worker_name,
                 stop_on=(), extra_slots=()):
    0                                                                
    worker.moveToThread(thread)
    thread.started.connect(worker.run)
    for signal in stop_on:
        signal.connect(thread.quit)
    for signal, slot in extra_slots:
        signal.connect(slot)
    thread.finished.connect(thread.deleteLater)
    _keep_thread_alive(thread)
    setattr(dialog, thread_name, thread)
    setattr(dialog, worker_name, worker)
    thread.start()
    return thread


def start_call(dialog, call, on_done, on_failed):
    0                                                      

                                                                      
                                                                        
                                                                          
                                              
       
    thread = QThread()
    worker = CallWorker(call)


    return start_worker(
        dialog, worker, thread, "_call_thread", "_call_worker",
        (worker.done, worker.failed),
        ((worker.done, on_done), (worker.failed, on_failed)))


def _discard_item(collection, item):
    0                                                               
    try:
        collection.remove(item)
    except ValueError:
        pass


def _keep_thread_alive(thread):
    0                                                          
    if thread not in _THREADS:
        _THREADS.append(thread)
        finished = getattr(thread, "finished", None)
        if finished is not None:
            finished.connect(lambda: _discard_item(_THREADS, thread))


def _stop_thread(thread, timeout_ms=3000):
    0                                                                    
    if thread is None:
        return True
    try:
        thread.quit()
    except Exception:
        pass
    try:
        finished = bool(thread.wait(timeout_ms))
    except Exception:
        finished = False
    if not finished:
        try:
            thread.setParent(None)
        except Exception:
            pass
        _keep_thread_alive(thread)
        try:
            if thread.isFinished():
                _discard_item(_THREADS, thread)
        except Exception:
            pass
    return finished


def _dialog_busy(dialog):
    0                                                                   
    if getattr(dialog, "thread", None) is not None:
        return True
    if getattr(dialog, "prepare_thread", None) is not None:
        return True
    login = getattr(dialog, "login_thread", None)
    return login is not None and login.isRunning()


def _set_enabled(owner, names, enabled):
    0                                                        
    for name in names:
        setter = getattr(getattr(owner, name, None), "setEnabled", None)
        if setter is None:
            continue
        setter(enabled)


def _apply_busy(dialog, busy):
    0                                                               

                                                                        
                      
       
    _set_enabled(dialog, ("account_quick", "account_select", "account_new",
                          "account_remove", "partner", "login_button",
                          "settings_button", "hardware", "refresh",
                          "formats"),
                 not busy)


LOGIN_NEXT_STEP = "Anmeldung erneut starten; Details stehen im Calibre-Log."


def _login_failure_guidance(error):
    0                                                

                                                                      
                                                                    
       
    title = error.short if isinstance(error, TolinoError) else ""
    return str(title or "").strip() or "Anmeldung nicht abgeschlossen"


def _failed_operations(outcome):
    0                                                                 
    return [item for item in (outcome.get("operations") or ())
            if isinstance(item, dict) and item.get("status") == OP_FAILED]


def sync_result_text(outcome, prefix="Fertig"):
    0                                                     
    outcome = outcome if isinstance(outcome, dict) else {}
    parts = []
    labels = (("uploaded", "hochgeladen"), ("metadata", "Metadaten"),
              ("read_marked", "als gelesen markiert"),
              ("read_unmarked", "als ungelesen markiert"),
              ("collections", "Sammlungen"), ("deleted", "gelöscht"),
              ("skipped", "übersprungen"), ("failed", "Fehler"))
    for key, label in labels:
        count = int(outcome.get(key) or 0)
        if count:
            parts.append("%d %s" % (count, label))
    text = ", ".join(parts)
    if prefix:
        text = ("%s: %s" % (prefix, text)) if text else prefix


    failed = _failed_operations(outcome)
    if failed:
        lines = [_operation_line(item) for item in failed[:5]]
        if len(failed) > 5:
            lines.append("- … und %d weitere" % (len(failed) - 5))
        text += "\n\nNicht abgeschlossen:\n" + "\n".join(lines)
    return text


def _operation_line(item):
    0                                                                 
    item = item if isinstance(item, dict) else {}

    detail = str(item.get("error") or "")
    code_match = re.search(r"\(Code ([A-Z][0-9]{2})\)", detail)
    if code_match and code_match.group(1) not in detail[-16:]:
        detail += " (Code %s)" % code_match.group(1)
    return "- %s%s" % (item.get("label") or "Schritt",
                       (": " + detail) if detail else "")


def sync_result_detail(outcome):
    0                                                                

                                                                    
                                                                           
                                                             
       
    outcome = outcome if isinstance(outcome, dict) else {}
    failed = _failed_operations(outcome)
    if len(failed) <= 5:
        return ""
    return "\n".join(_operation_line(item) for item in failed)


